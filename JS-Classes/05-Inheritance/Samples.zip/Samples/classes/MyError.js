class MyError extends Error {
  constructor(message, funcName, className, ...params) {
    // Pass any arguments to the base class
    super(message, ...params);

    // Set custom public properties
    this.name = "MyError";
    this.errorDate = new Date();
    this.funcName = funcName;
    this.className = className;

    // Ensure you capture the stack trace
    if (Error.captureStackTrace) {
      Error.captureStackTrace(this, MyError);
    }
  }

  toString() {
    return `${super.toString()}
      Error Name: ${this.name}
      Error Message: ${this.message}
      Error Date: ${this.errorDate}
      Function: ${this.funcName}
      Class: ${this.className}
      Stack: ${this.stack}`
  }
}