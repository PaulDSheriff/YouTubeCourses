// Define a Person class
class Person {
  // Define constructor
  constructor(firstName, lastName, age) {
    // Initialize properties
    this.firstName = firstName;
    this.lastName = lastName;
    this.age = age;
  }

  firstName;
  lastName;
  age;
}