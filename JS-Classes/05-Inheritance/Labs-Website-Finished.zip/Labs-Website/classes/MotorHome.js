// Define a MotorHome class
class MotorHome extends RV {
  // Define constructor
  constructor(rvid, year, make, model, listPrice, engineType, classType) {
    // Call parent's constructor
    super(rvid, year, make, model, listPrice);

    // Initialize properties
    this.engineType = engineType;
    this.class = classType;
  }

  // Public properties
  engineType;
  class;
}