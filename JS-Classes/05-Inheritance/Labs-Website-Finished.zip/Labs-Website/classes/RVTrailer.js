// Define an RVTrailer class
class RVTrailer extends RV {
  // Define constructor
  constructor(rvid, year, make, model, listPrice, hitchType) {
    // Call parent's constructor
    super(rvid, year, make, model, listPrice);

    // Initialize properties
    this.hitchType = hitchType;
  }

  // Public properties
  hitchType;
}