// Define an Employee class
class Employee extends Person {
  // Define constructor
  constructor(firstName, lastName, age, employeeId, salary) {
    // Call parent's constructor
    super(firstName, lastName, age);

    // Initialize properties
    this.employeeId = employeeId;
    this.salary = salary;
  }

  employeeId;
  salary;
}