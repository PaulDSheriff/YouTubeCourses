// Define a Supervisor class
class Supervisor extends Employee {
  // Define constructor
  constructor(firstName, lastName, age, employeeId, salary, employees) {
    // Call parent's constructor
    super(firstName, lastName, age, employeeId, salary);

    // Initialize properties
    this.employees = employees;
    this.salary = salary;
  }

  employees = [];
}