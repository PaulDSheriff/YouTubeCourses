// Define an RV class
class RV {
  // Define constructor
  constructor(rvid, year, make, model, listPrice) {
    // Initialize properties
    this.rvid = rvid;
    this.year = year;
    this.make = make;
    this.model = model;
    this.listPrice = listPrice;
  }

  // Public properties
  rvid;
  year;
  make;
  model;
  listPrice;
}