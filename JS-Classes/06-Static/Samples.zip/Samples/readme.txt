Sample Order
--------------------------
static-property.html
static-property-readonly.html

static-constructor.html
static-method.html

math-helper.html
application-settings.html