class ApplicationSettings {
  // Private Static Property Definitions
  static #apiUrl;
  static #port;

  // Public Static Property Definitions
  static get apiUrl() {
    return this.#apiUrl;
  }

  static get port() {
    return this.#port;
  }

  // Public Method Definitions
  static load() {
    // TODO: Load these from a configuration file
    this.#apiUrl = "https://www.pdsa.com/api";
    this.#port = "8080";
  }
}