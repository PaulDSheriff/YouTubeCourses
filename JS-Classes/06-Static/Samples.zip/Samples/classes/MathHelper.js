class MathHelper {
  static get PI() {
    return 3.14159;
  }
  
  static add(op1, op2) {
    return op1 + op2;
  }

  static multiply(op1, op2) {
    return op1 * op2;
  }
}
