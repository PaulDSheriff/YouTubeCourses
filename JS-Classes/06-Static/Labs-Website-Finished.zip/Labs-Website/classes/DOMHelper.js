class DOMHelper {
  static getElement(id) {
    return document.getElementById(id);
  }

  static getValue(id) {
    return DOMHelper.getElement(id).value;
  }

  static getDateValue(id) {
    return new Date(DOMHelper.getValue(id) + " ");
  }

  static setDateValue(id, dt) {
    DOMHelper.getElement(id).value = `${dt.getFullYear()}-${String(dt.getMonth() + 1).padStart(2, '0')}-${String(dt.getDate()).padStart(2, '0')}`;
  }

  static setValue(id, value) {
    DOMHelper.getElement(id).value = value;
  }

  static setText(id, value) {
    DOMHelper.getElement(id).innerText = value;
  }
}