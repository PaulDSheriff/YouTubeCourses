class NumberHelper {
  static localeCode = 'en-US';
  static isoCurrencyCode = 'USD';

  static toCurrency(value, locale, isoCode) {
    // Check parameters passed in
    locale ??= NumberHelper.localeCode;
    isoCode ??= NumberHelper.isoCurrencyCode;

    // Convert value to a currency formatted
    // according to the locale specified
    return value.toLocaleString(locale,
      {
        style: 'currency',
        currency: isoCode
      });
  }
}