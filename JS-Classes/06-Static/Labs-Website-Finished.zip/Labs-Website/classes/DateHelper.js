class DateHelper {
  static getMonthNames() {
    return ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
  }

  static getShortMonthNames() {
    return ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  }

  static createDayOptions(month, year) {
    let html = "";

    // Calculate last day of the month
    // Zero for the last day means one day less than the first day of the month
    let dt = new Date(year, month + 1, 0);

    for (let day = 1; day <= dt.getDate(); day++) {
      html += `<option value="${day}">${day}</option>`;
    }

    return html;
  }

  static createMonthOptions(useShortNames) {
    let html = "";
    let months;

    if (useShortNames) {
      months = DateHelper.getShortMonthNames();
    }
    else {
      months = DateHelper.getMonthNames();
    }

    for (let index = 0; index < months.length; index++) {
      html += `<option value="${index}">${months[index]}</option>`;
    }

    return html;
  }

  static createYearOptions(begin, end, reverse) {
    let html = "";

    if (reverse) {
      for (let year = end; year >= begin; year--) {
        html += `<option value="${year}">${year}</option>`;
      }
    }
    else {
      for (let year = begin; year <= end; year++) {
        html += `<option value="${year}">${year}</option>`;
      }
    }

    return html;
  }
}