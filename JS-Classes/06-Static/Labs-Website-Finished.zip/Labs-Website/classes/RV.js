// Define an RV class
class RV {
  // Define constructor
  constructor(rvid, year, make, model, listPrice, releaseDate) {
    // Initialize properties
    this.rvid = rvid;
    this.year = year;
    this.make = make;
    this.model = model;
    this.listPrice = listPrice;
    this.releaseDate = releaseDate;
  }

  // Static method to clone an
  // existing RV instance
  static clone(rv) {
    // Create a new instance of an RV class
    let clone = new RV();

    // Clone the original data
    Object.assign(clone, rv);

    // Return the cloned object
    return clone;
  }
}