Sample Order
--------------------------
class.html

class-let-no-name.html
class-let-name.html

class-hoisting.html

class-constructor-no-params.html
class-constructor-params.html

method.html


** OPTIONAL SAMPLE **
function-constructor.html