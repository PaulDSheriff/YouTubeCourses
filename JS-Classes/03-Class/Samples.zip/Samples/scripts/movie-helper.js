function displayMovieInfo(movie) {
  console.log(`Film ID: ${movie.filmId}`);
  console.log(`Name: ${movie.name}`);
  console.log(`Genres: ${movie.genres}`);
  console.log(`Actors: ${movie.actors}`);      
}