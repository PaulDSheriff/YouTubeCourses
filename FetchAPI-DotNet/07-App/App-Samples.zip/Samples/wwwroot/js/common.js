// *****************************************
// Global Variable for Common Functions
// *****************************************
let common = (function () {
  // ******************************
  // Private Functions
  // ******************************
  async function processResponseObject(response) {
    let text = "";
    let body = {};
    // Create custom response object
    let ret = {
      "ok": response.ok,
      "status": response.status,
      "statusText": response.statusText,
      "url": response.url,
      "message": "",
      "data": {}
    };

    try {
      // Get text first
      text = await response.text();
      // Attempt to convert to JSON
      body = JSON.parse(text);
      // Set JSON body into data property
      ret.data = body.data;
      ret.message = body.message;
      if (ret.data == null) {
        ret.data = text;
      }
    }
    catch {
      // Set text into data property
      ret.data = text;
    }

    return ret;
  }

  function handleNetworkError(error) {
    let msg = "A network error has occurred. Check the apiUrl property to ensure it is set correctly.";

    console.error(error + " - " + msg);

    return msg;
  }

  function handleError(vm) {
    let msg = "";

    switch (vm.status) {
      case 400:
        msg = JSON.stringify(vm.data);
        break;
      case 404:
        if (vm.data) {
          msg = vm.data;
        }
        else {
          msg = `${vm.statusText} - ${vm.apiUrl}`;
        }
        break;
      case 500:
        msg = JSON.parse(vm.data).message;
        break;
      default:
        msg = JSON.stringify(vm.data);
        break;
    }

    if (msg) {
      console.error(msg);
    }

    return msg;
  }

  function fixDate(dt) {
    let ret = new Date();

    // Ensure a null was not passed in
    if (dt) {
      ret = new Date(dt);
    }

    let year = ret.getFullYear();
    let month = (ret.getMonth() + 1).toString().padStart(2, '0');
    let day = (ret.getDate()).toString().padStart(2, '0');
    ret = `${year}-${month}-${day}`;

    return ret;
  }

  //*********************************
  //* Generic Display Methods
  //*********************************
  function displayList() {
    document.getElementById("list").classList.remove('d-none');
    document.getElementById("detail").classList.add('d-none');
  }

  function displayMessage(msg) {
    if (msg) {
      document.getElementById("message").textContent = msg;
      document.getElementById("message").classList.remove('d-none');
    }
    else {
      document.getElementById("message").classList.add('d-none');
    }
  }

  function displayError(msg) {
    if (msg) {
      document.getElementById("error").textContent = msg;
      document.getElementById("error").classList.remove('d-none');
    }
    else {
      document.getElementById("error").classList.add('d-none');
    }
  }

  function displayButtons() {
    document.getElementById("saveButton").classList.remove('d-none');
    document.getElementById("cancelButton").classList.remove('d-none');
  }

  function displayDetail() {
    document.getElementById("list").classList.add('d-none');
    document.getElementById("detail").classList.remove('d-none');
  }

  function hideButtons() {
    document.getElementById("saveButton").classList.add('d-none');
    document.getElementById("cancelButton").classList.add('d-none');
  }

  // ******************************
  // Public Functions
  // ******************************
  return {
    "processResponseObject": processResponseObject,
    "handleNetworkError": handleNetworkError,
    "handleError": handleError,
    "fixDate": fixDate,
    "displayList": displayList,
    "displayMessage": displayMessage,
    "displayError": displayError,
    "displayButtons": displayButtons,
    "displayDetail": displayDetail,
    "hideButtons": hideButtons
  };
})();
