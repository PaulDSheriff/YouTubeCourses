using System.Text.Json;

namespace FetchSamples.WebAPI;

/// <summary>
/// This class creates fake data for the Person table.
/// </summary>
public partial class PersonRepository : IRepository<Person>
{
  #region GetPeopleFromFile Method
  private string GetPeopleFromFile()
  {
    string ret = string.Empty;

    string fileName = Directory.GetCurrentDirectory();
    fileName += @"\Assets\people.json";

    if (File.Exists(fileName)) {
      ret = File.ReadAllText(fileName);
    }

    return ret;
  }
  #endregion

  #region SavePeopleToFile Method
  private void SavePeopleToFile(List<Person> people)
  {
    string fileName = Directory.GetCurrentDirectory();
    fileName += @"\Assets\people.json";

    JsonSerializerOptions options = new() {
      PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
      WriteIndented = true
    };
    string tmp = JsonSerializer.Serialize(people, options);
    if (!string.IsNullOrEmpty(tmp)) {
      if (File.Exists(fileName)) {
        File.WriteAllText(fileName, tmp);
      }
    }
  }
  #endregion

  #region Get Method
  /// <summary>
  /// Get all Person objects
  /// </summary>
  /// <returns>A list of People objects</returns>
  public List<Person> Get()
  {
    List<Person> ret = new();
    string people = string.Empty;

    people = GetPeopleFromFile();

    if (!string.IsNullOrEmpty(people)) {
      JsonSerializerOptions options = new() {
        PropertyNamingPolicy = JsonNamingPolicy.CamelCase
      };
      var tmp = JsonSerializer.Deserialize<List<Person>>(people, options);
      if (tmp != null) {
        ret = tmp;
      }
    }

    return ret;
  }
  #endregion

  #region Get(id) Method
  /// <summary>
  /// Get a single Person object
  /// </summary>
  /// <param name="id">The value to locate</param>
  /// <returns>A valid Person object, or null if not found</returns>
  public Person? Get(int id)
  {
    return Get().Where(row => row.PersonId == id).FirstOrDefault();
  }
  #endregion

  #region Insert Method
  /// <summary>
  /// Insert a new Person object
  /// </summary>
  /// <param name="entity">The data to insert</param>
  /// <returns>The inserted Person object</returns>
  public Person? Insert(Person entity)
  {
    List<Person> list;

    list = Get();

    // Increment the Primary Key field
    entity.PersonId = list.Max(row => row.PersonId) + 1;

    // Add to collection
    list.Add(entity);

    // Insert into data store
    SavePeopleToFile(list);

    return entity;
  }
  #endregion

  #region Update Method
  /// <summary>
  /// Update existing Person object
  /// </summary>
  /// <param name="entity">The data to update</param>
  /// <returns>The updated Person object</returns>
  public Person? Update(Person entity)
  {
    List<Person> list;

    list = Get();

    // Look up the data by the specified id
    Person? current = list.FirstOrDefault(row => row.PersonId == entity.PersonId);

    if (current != null) {
      // Update Current Data
      current.FirstName = entity.FirstName;
      current.LastName = entity.LastName;
      current.EmailAddress = entity.EmailAddress;
      current.StartDate = entity.StartDate;

      // Update File
      SavePeopleToFile(list);
    }

    return current;
  }
  #endregion

  #region Delete Method
  /// <summary>
  /// Delete a Person object
  /// </summary>
  /// <param name="entity">The data to insert</param>
  /// <returns>True if delete, false if not found</returns>
  public bool Delete(Person entity)
  {
    bool ret = false;
    List<Person> list;

    list = Get();

    // Look up the data by the specified id
    Person? current = list.FirstOrDefault(row => row.PersonId == entity.PersonId);

    if (current != null) {
      // Remove data from collection
      list.Remove(current);

      // Delete data from data store
      SavePeopleToFile(list);

      ret = true;
    }

    return ret;
  }
  #endregion
}
