namespace FetchSamples.WebAPI;

public partial class Person
{
  public int PersonId { get; set; } = 0;
  public string FirstName { get; set; } = string.Empty;
  public string LastName { get; set; } = string.Empty;
  public string? EmailAddress { get; set; } = string.Empty;
  public DateTime? StartDate { get; set; } = DateTime.Now;
  public string? StartDateForJSON
  {
    get { return StartDate?.ToString("yyyy-MM-dd"); }
  }

  #region ToString Override
  public override string ToString()
  {
    return $"{LastName}, {FirstName}";
  }
  #endregion
}
