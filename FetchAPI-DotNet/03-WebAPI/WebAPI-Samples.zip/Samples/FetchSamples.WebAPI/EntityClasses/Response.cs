﻿namespace FetchSamples.WebAPI;

public class Response
{
  public int Status { get; set; }
  public string StatusText { get; set; } = string.Empty;
  public string Message { get; set; } = string.Empty;
  public object? Data { get; set; }
}