﻿namespace FetchSamples.WebAPI;

public interface IRepository<T> where T : class
{
  List<T> Get();
  T? Get(int id);
  T? Insert(T entity);
  T? Update(T entity);
  bool Delete(T entity);
}
