using FetchSamples.WebAPI;

var builder = WebApplication.CreateBuilder(args);

// Add CORS
builder.Services.AddCors(options =>
{
  options.AddPolicy("CorsPolicy",
    builder =>
    {
      builder.AllowAnyOrigin().AllowAnyHeader().AllowAnyMethod();
    });
});

// Add Authorization Service
builder.Services.AddAuthorization();

// Add services to the container.
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment()) {
  app.UseSwagger();
  app.UseSwaggerUI();
}

app.UseHttpsRedirection();

// Enable Authorization
app.UseAuthorization();

// Enable CORS Middleware
app.UseCors("CorsPolicy");

// Create the /people API Endpoints
app.MapGet("/api/people", () =>
{
  IResult ret;
  List<Person> list;
  PersonRepository repo = new();
  list = repo.Get();

  if (list.Count > 0) {
    ret = Results.Ok(new Response() {
      Status = 200,
      StatusText = "OK",
      Message = "All People Retrieved.",
      Data = list
    });
  }
  else {
    ret = Results.NotFound(new Response() {
      Status = 404,
      StatusText = "NotFound",
      Message = "No People Available.",
      Data = null
    });
  }
  
  return ret;
});

app.MapGet("/api/people/{id}", (int id) =>
{
  IResult ret;
  Person? entity = new();
  PersonRepository repo = new();
  entity = repo.Get(id);

  if (entity != null) {
    ret = Results.Ok(new Response() {
      Status = 200,
      StatusText = "OK",
      Message = "Person Retrieved.",
      Data = entity
    });
  }
  else {
    ret = Results.NotFound(new Response() {
      Status = 404,
      StatusText = "NotFound",
      Message = $"Can't Find Person with id='{id}'.",
      Data = null
    });
  }

  return ret;
});

app.MapGet("/api/responseWithBody", () =>
{
  return Results.Ok(new Response() {
    Status = 200,
    StatusText = "OK",
    Message = "Success.",
    Data = new Person { FirstName = "Sheila", LastName = "Cleverly" }
  });
});

app.MapGet("/api/responseWithoutBody", () =>
{
  return Results.NoContent();
});

app.MapGet("/api/responseWithText", () =>
{
  return Results.Ok("Status ID=200");
});

app.MapPost("/api/people", (Person entity) =>
{
  IResult ret;
  PersonRepository repo = new();

  Person? resp = repo.Insert(entity);

  if (resp != null) {
    ret = Results.Created($"/api/people/{resp?.PersonId}", new Response() {
      Status = 201,
      StatusText = "Created",
      Message = "New Person Added.",
      Data = resp
    });
  }
  else {
    ret = Results.BadRequest(new Response() {
      Status = 400,
      StatusText = "BadRequest",
      Message = "Unable to Add New Person.",
      Data = null
    });
  }

  return ret;
});

app.MapPut("/api/people/{id}", (int id, Person entity) =>
{
  IResult ret;
  PersonRepository repo = new();
  Person? resp;

  // Check if Person Exists
  resp = repo.Get(id);
  if (resp == null) {
    ret = Results.NotFound(new Response() {
      Status = 404,
      StatusText = "NotFound",
      Message = $"Can't find Person with id='{id}' to update.",
      Data = null
    });
  }
  else {
    // Attempt to Update Person
    resp = repo.Update(entity);
    ret = Results.Ok(new Response() {
      Status = 200,
      StatusText = "OK",
      Message = $"Person Updated.",
      Data = resp
    });
  }

  return ret;
});

app.MapDelete("/api/people/{id}", (int id) =>
{
  IResult ret;
  PersonRepository repo = new();

  if (repo.Delete(repo.Get(id) ?? new())) {
    ret = Results.NoContent();
  }
  else {
    ret = Results.NotFound(new Response() {
      Status = 404,
      StatusText = "NotFound",
      Message = $"Can't find Person with id='{id}' to delete.",
      Data = null
    });
  }

  return ret;
});

app.Run();
