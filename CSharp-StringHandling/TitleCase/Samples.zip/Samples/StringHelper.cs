﻿using System.Globalization;

namespace TitleCase;

public static class StringHelper
{
  static StringHelper()
  {
    BuildLowerCaseWords();
  }

  public static List<string> LowerCaseWords { get; set; } = new();

  // Capitalize "major" words (nouns, pronouns, verbs, adjectives, adverbs)
  // Lowercase conjunctions: 'and', 'but', 'for', 'or', and 'nor'
  // Lowercase articles: 'the', 'a', and 'an'
  // Lowercase words: 'to' and 'as'
  public static void BuildLowerCaseWords()
  {
    LowerCaseWords.Add("And");
    LowerCaseWords.Add("But");
    LowerCaseWords.Add("For");
    LowerCaseWords.Add("Or");
    LowerCaseWords.Add("Nor");
    LowerCaseWords.Add("The");
    LowerCaseWords.Add("A");
    LowerCaseWords.Add("An");
    LowerCaseWords.Add("To");
    LowerCaseWords.Add("As");
  }

  public static string ToTitleCase(string str)
  {
    TextInfo ti = CultureInfo.CurrentCulture.TextInfo;

    str = ti.ToTitleCase(str);

    // Check for keywords to be lower case
    foreach (string word in LowerCaseWords) {
      str = str.Replace($" {word} ", $" {word.ToLowerInvariant()} ");
    }

    return str;
  }
}
