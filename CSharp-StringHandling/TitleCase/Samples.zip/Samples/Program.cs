﻿using TitleCase;
using System.Globalization;

string sentence;

// **************************************
// ToTitleCase Samples
// **************************************
sentence = "sENtence wIth MIxed up LettERs.";
TextInfo ti = CultureInfo.CurrentCulture.TextInfo;
Console.WriteLine(ti.ToTitleCase(sentence));
Console.WriteLine();

// **************************************
// Title Case Special Cases
// **************************************
// Upper case words are not converted
sentence = "This sENtence has UPPER CASE wORds.";
Console.WriteLine(ti.ToTitleCase(sentence));
Console.WriteLine();

// This can be good for acronyms or organizations like UNICEF
// But can be a problem if you know the sentence should not have any of these words
sentence = "ALL UPPER CASE SENTENCE.";
Console.WriteLine(ti.ToTitleCase(sentence));
// Use String.ToLowerInvariant() method
Console.WriteLine(ti.ToTitleCase(sentence.ToLowerInvariant()));
// Use TextInfo.ToLower() method
Console.WriteLine(ti.ToTitleCase(ti.ToLower(sentence)));
Console.WriteLine();

// Words with prefixes like 'Mc' are not handled
sentence = "McDougal's has some fine wines.";
Console.WriteLine(ti.ToTitleCase(sentence));
Console.WriteLine();

// 'And' and 'Or' are not handled correctly
sentence = "this and that, or another thing.";
Console.WriteLine(ti.ToTitleCase(sentence));
Console.WriteLine();

// **************************************
// Fix ToTitleCase()
// **************************************
sentence = "this and that, but not a thing, nor another thing or that thing.";
Console.WriteLine(StringHelper.ToTitleCase(sentence));
Console.WriteLine();
