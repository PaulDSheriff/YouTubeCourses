﻿namespace ToStringSamples;

public class Product
{
  public string ProductName { get; set; } = string.Empty;
  public int ProductId { get; set; }

public override string ToString()
{
  return $"{ProductName} ({ProductId})";
}
}