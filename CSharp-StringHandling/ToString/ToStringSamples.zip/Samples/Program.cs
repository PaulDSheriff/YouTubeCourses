﻿using ToStringSamples;

Product entity = new() {
  ProductId = 1,
  ProductName = "Acme Bazooka"
};

Console.WriteLine(entity);