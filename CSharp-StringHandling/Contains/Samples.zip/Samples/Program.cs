﻿string sentence = "The Quick Brown Fox";

Console.WriteLine("          1         2");
Console.WriteLine("012345678901234567890");
Console.WriteLine(sentence);
Console.WriteLine();

//**************************
//* Contains() Samples
//**************************
Console.WriteLine("*** Contains() Samples ***");
Console.WriteLine($"Contains(\"T\") = {sentence.Contains("T")}");
Console.WriteLine($"Contains(\"t\") = {sentence.Contains("t")}");
Console.WriteLine($"Contains(\"t\", StringComparison.InvariantCultureIgnoreCase) = {sentence.Contains("t", StringComparison.InvariantCultureIgnoreCase)}");
Console.WriteLine($"Contains(\"Fox\") = {sentence.Contains("Fox")}");
Console.WriteLine();

//**************************
//* StartsWith() Samples
//**************************
Console.WriteLine("*** StartsWith() Samples ***");
Console.WriteLine($"StartsWith(\"T\") = {sentence.StartsWith("T")}");
Console.WriteLine($"StartsWith(\"t\") = {sentence.StartsWith("t")}");
Console.WriteLine($"StartsWith(\"t\", StringComparison.InvariantCultureIgnoreCase) = {sentence.StartsWith("t", StringComparison.InvariantCultureIgnoreCase)}");
Console.WriteLine($"StartsWith(\"The\") = {sentence.StartsWith("The")}");
Console.WriteLine($"StartsWith(\"Fox\") = {sentence.StartsWith("Fox")}");
Console.WriteLine();

//**************************
//* EndsWith() Samples
//**************************
Console.WriteLine("*** EndsWith() Samples ***");
Console.WriteLine($"EndsWith(\"x\") = {sentence.EndsWith("x")}");
Console.WriteLine($"EndsWith(\"X\") = {sentence.EndsWith("X")}");
Console.WriteLine($"EndsWith(\"X\", StringComparison.InvariantCultureIgnoreCase) = {sentence.EndsWith("X", StringComparison.InvariantCultureIgnoreCase)}");
Console.WriteLine($"EndsWith(\"The\") = {sentence.EndsWith("The")}");
Console.WriteLine($"EndsWith(\"Fox\") = {sentence.EndsWith("Fox")}");
Console.WriteLine();