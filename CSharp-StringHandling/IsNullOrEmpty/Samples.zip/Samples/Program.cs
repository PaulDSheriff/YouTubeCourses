﻿string? value;

//*****************************************
// Simulate IsNullOrEmpty Samples
//*****************************************
Console.WriteLine("Simulate IsNullOrEmpty Samples");
value = null;
Console.Write("value = null: ");
Console.WriteLine(value == null || value == string.Empty);

value = "";
Console.Write("value = '': ");
Console.WriteLine(value == null || value == string.Empty);

value = " ";
Console.Write("value = ' ': ");
Console.WriteLine(value == null || value == string.Empty);

value = "Some Text";
Console.Write("value = 'Some Text': ");
Console.WriteLine(value == null || value == string.Empty);
Console.WriteLine();

//*****************************************
// IsNullOrEmpty Samples
// This is the same as above, but is faster
//*****************************************
Console.WriteLine("IsNullOrEmpty Samples");
value = null;
Console.Write("value = null: ");
Console.WriteLine(string.IsNullOrEmpty(value));

value = "";
Console.Write("value = '': "); 
Console.WriteLine(string.IsNullOrEmpty(value));

value = " ";
Console.Write("value = ' ': ");
Console.WriteLine(string.IsNullOrEmpty(value));

value = "Some Text";
Console.Write("value = 'Some Text': ");
Console.WriteLine(string.IsNullOrEmpty(value));
Console.WriteLine();

//*****************************************
// Simulate IsNullOrWhiteSpace Samples
//*****************************************
Console.WriteLine("Simulate IsNullOrWhiteSpace Samples");
value = null;
Console.Write("value = null: ");
Console.WriteLine(string.IsNullOrEmpty(value) || value.Trim().Length == 0);

value = "";
Console.Write("value = '': ");
Console.WriteLine(string.IsNullOrEmpty(value) || value.Trim().Length == 0);

value = " ";
Console.Write("value = ' ': ");
Console.WriteLine(string.IsNullOrEmpty(value) || value.Trim().Length == 0);

value = "Some Text";
Console.Write("value = 'Some Text': ");
Console.WriteLine(string.IsNullOrEmpty(value) || value.Trim().Length == 0);
Console.WriteLine();

//*****************************************
// IsNullOrWhiteSpace Samples
// This is the same as above, but is faster
//*****************************************
Console.WriteLine("IsNullOrWhiteSpace Samples");

value = null;
Console.Write("value = null: ");
Console.WriteLine(string.IsNullOrWhiteSpace(value));

value = "";
Console.Write("value = '': ");
Console.WriteLine(string.IsNullOrWhiteSpace(value));

value = " ";
Console.Write("value = ' ': ");
Console.WriteLine(string.IsNullOrWhiteSpace(value));

value = "Some Text";
Console.Write("value = 'Some Text': ");
Console.WriteLine(string.IsNullOrWhiteSpace(value));