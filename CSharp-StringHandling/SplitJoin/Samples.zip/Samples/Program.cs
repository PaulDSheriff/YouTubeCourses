﻿string sentence;
string[] arr;

//*****************************************
// Split() Samples
//*****************************************
sentence = "This is a normal sentence.";
// If no delimiter is passed, any white space is considered a delimiter
arr = sentence.Split();
foreach (string str in arr) {
  Console.WriteLine(str);
}
Console.WriteLine();

sentence = "This is a normal sentence.";
// Set the delimiter to split the string on
arr = sentence.Split(' ');
foreach (string str in arr) {
  Console.WriteLine(str);
}
Console.WriteLine();

sentence = "1,2,3,4";
// Splitting on commas
arr = sentence.Split(',');
foreach (string str in arr) {
  Console.WriteLine(str);
}
Console.WriteLine();

// May specify more than one delimiter
sentence = "This is sentence 1. This is sentence 2.";
arr = sentence.Split(' ', '.');
foreach (string str in arr) {
  Console.WriteLine(str);
}
Console.WriteLine();

// If you have a space between each comma
// and you specify a space as a delimiter
// You get an array element for each space
sentence = "1, 2, 3, 4";
arr = sentence.Split(' ', ',');
foreach (string str in arr) {
  Console.WriteLine(str);
}
Console.WriteLine();

//*****************************************
// Join() Samples
//*****************************************
arr = ["This", "is", "a", "sentence."];
sentence = string.Join(' ', arr);
Console.WriteLine(sentence);
Console.WriteLine();

// If a null is passed, and empty string is used
arr = ["This", "is", "a", "sentence."];
sentence = string.Join(null, arr);
Console.WriteLine(sentence);
Console.WriteLine();

List<string> list = ["A", "sentence", "from", "a List<T>."];
sentence = string.Join(' ', [.. list]);
//sentence = string.Join(' ', list.ToArray());
Console.WriteLine(sentence);
Console.WriteLine();