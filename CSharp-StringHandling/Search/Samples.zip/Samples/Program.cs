﻿string sentence = "The Quick Brown Fox";

Console.WriteLine("          1         2");
Console.WriteLine("012345678901234567890");
Console.WriteLine(sentence);
Console.WriteLine();

//**************************
//* IndexOf() Samples
//**************************
Console.WriteLine("*** IndexOf() Samples ***");
Console.WriteLine($"IndexOf(\"H\") = {sentence.IndexOf("H")}");
Console.WriteLine($"IndexOf(\"h\") = {sentence.IndexOf("h")}");
Console.WriteLine($"IndexOf(\"H\", StringComparison.InvariantCultureIgnoreCase) = {sentence.IndexOf("H", StringComparison.InvariantCultureIgnoreCase)}");
Console.WriteLine();

Console.WriteLine($"IndexOf(\"Brown\") = {sentence.IndexOf("Brown")}");
Console.WriteLine();

Console.WriteLine($"IndexOf(\"o\") = {sentence.IndexOf("o")}");
Console.WriteLine($"IndexOf(\"o\", 16) = {sentence.IndexOf("o", 16)}");
Console.WriteLine($"IndexOf(\"o\", 16, 3) = {sentence.IndexOf("o", 16, 3)}");
Console.WriteLine();

//**************************
//* LastIndexOf() Samples
//**************************
Console.WriteLine("*** LastIndexOf() Samples ***");
Console.WriteLine($"LastIndexOf(\"F\") = {sentence.LastIndexOf("F")}");
Console.WriteLine($"LastIndexOf(\"f\") = {sentence.LastIndexOf("f")}");
Console.WriteLine($"LastIndexOf(\"f\", StringComparison.InvariantCultureIgnoreCase) = {sentence.LastIndexOf("f", StringComparison.InvariantCultureIgnoreCase)}");
Console.WriteLine();

Console.WriteLine($"LastIndexOf(\"Brown\") = {sentence.LastIndexOf("Brown")}");
Console.WriteLine();

Console.WriteLine($"LastIndexOf(\"o\") = {sentence.LastIndexOf("o")}");
Console.WriteLine($"LastIndexOf(\"o\", 14) = {sentence.LastIndexOf("o", 14)}");
Console.WriteLine($"LastIndexOf(\"o\", 14, 5) = {sentence.LastIndexOf("o", 14, 5)}");
Console.WriteLine();

//**************************
//* IndexOfAny() Samples
//**************************
Console.WriteLine("*** IndexOfAny() Samples ***");
Console.WriteLine($"IndexOfAny(\"e\".ToCharArray()) = {sentence.IndexOfAny("e".ToCharArray())}");
Console.WriteLine();

Console.WriteLine($"IndexOfAny(\"he\".ToCharArray()) = {sentence.IndexOfAny("he".ToCharArray())}");
Console.WriteLine();

Console.WriteLine($"IndexOfAny(\"zQ\".ToCharArray()) = {sentence.IndexOfAny("zQ".ToCharArray())}");
Console.WriteLine();

Console.WriteLine($"IndexOfAny(\"zd\".ToCharArray()) = {sentence.IndexOfAny("zd".ToCharArray())}");
Console.WriteLine();

//**************************
//* LastIndexOfAny() Samples
//**************************
Console.WriteLine("*** LastIndexOfAny() Samples ***");
Console.WriteLine($"LastIndexOfAny(\"o\".ToCharArray()) =" +
  $" {sentence.LastIndexOfAny("o".ToCharArray())}");

Console.WriteLine($"LastIndexOfAny(\"xo\".ToCharArray()) = " +
  $"{sentence.LastIndexOfAny("xo".ToCharArray())}");

Console.WriteLine($"LastIndexOfAny(\"zw\".ToCharArray()) = " +
  $"{sentence.LastIndexOfAny("zw".ToCharArray())}");

Console.WriteLine($"LastIndexOfAny(\"zd\".ToCharArray()) = " +
  $"{sentence.LastIndexOfAny("zd".ToCharArray())}");

Console.WriteLine();