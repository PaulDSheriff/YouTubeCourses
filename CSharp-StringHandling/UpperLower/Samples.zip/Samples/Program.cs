﻿using System.Text.RegularExpressions;

string sentence;

// **************************************
// ToUpper() Samples
// **************************************
sentence = "all lower case sentence.";
Console.WriteLine(sentence.ToUpper());
// Use *Invariant when you must take into account different cultures
Console.WriteLine(sentence.ToUpperInvariant());
Console.WriteLine();

// **************************************
// ToLower() Samples
// **************************************
sentence = "ALL UPPER CASE SENTENCE.";
Console.WriteLine(sentence.ToLower());
// Use *Invariant when you must take into account different cultures
Console.WriteLine(sentence.ToLowerInvariant());
Console.WriteLine();

// **************************************
// Is All Upper Case Samples
// **************************************
sentence = "ALL Upper Case Sentence.";
Console.Write("Is sentence all upper case = ");
Console.WriteLine(String.Equals(sentence, sentence.ToUpperInvariant()));

sentence = "ALL UPPER CASE SENTENCE.";
Console.Write("Is sentence all upper case = ");
Console.WriteLine(String.Equals(sentence, sentence.ToUpperInvariant()));
Console.WriteLine();

// **************************************
// Is All Lower Case Samples
// **************************************
sentence = "ALL Lower Case Sentence.";
Console.Write("Is sentence all lower case = ");
Console.WriteLine(String.Equals(sentence, sentence.ToLowerInvariant()));

sentence = "all lower case sentence.";
Console.Write("Is sentence all lower case = ");
Console.WriteLine(String.Equals(sentence, sentence.ToLowerInvariant()));
Console.WriteLine();

// **************************************
// Regular Expression Samples
// **************************************
Console.Write("Is sentence all lower case (Regex) = ");
Regex reg = new(@"^[a-z0-9_\-]");
Console.WriteLine(reg.IsMatch(sentence));

Console.Write("Is sentence all upper case (Regex) = ");
reg = new(@"^[A-Z0-9_\-]");
Console.WriteLine(reg.IsMatch(sentence));
Console.WriteLine();