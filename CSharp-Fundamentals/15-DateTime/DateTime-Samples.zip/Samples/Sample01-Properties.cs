﻿namespace CSharpSamples;

public class Sample01 {
  public static void Properties() {
    DateTime dt = DateTime.Now;

    Console.WriteLine($"Date = {dt.Date}");
    Console.WriteLine($"Day = {dt.Day}");
    Console.WriteLine($"DayOfWeek = {dt.DayOfWeek}");
    Console.WriteLine($"DayOfYear = {dt.DayOfYear}");
    Console.WriteLine($"Month = {dt.Month}");
    Console.WriteLine($"Year = {dt.Year}");
    Console.WriteLine($"Hour = {dt.Hour}");
    Console.WriteLine($"Minute = {dt.Minute}");
    Console.WriteLine($"Second = {dt.Second}");
    Console.WriteLine($"Millisecond = {dt.Millisecond}");
    Console.WriteLine($"Kind = {dt.Kind}");
    Console.WriteLine($"Ticks = {dt.Ticks}");
    Console.WriteLine($"IsDaylightSavingTime = {dt.IsDaylightSavingTime}");
    Console.WriteLine($"TimeOfDay = {dt.TimeOfDay}");
  }
}
