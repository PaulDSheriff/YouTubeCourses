﻿namespace CSharpSamples;

public class Sample02 {
  public static void Methods() {
    DateTime dt = DateTime.Now;

    // The following two lines are equivalent
    Console.WriteLine($"ToString() = {dt.ToString()}");
    Console.WriteLine($"ToString() = {dt}");

    Console.WriteLine($"AddDays(1) = {dt.AddDays(1)}");
    Console.WriteLine($"AddDays(-1) = {dt.AddDays(-1)}");
    Console.WriteLine($"AddHours(5)() = {dt.AddHours(5)}");
    Console.WriteLine($"AddYears(2) = {dt.AddYears(2)}");
    Console.WriteLine($"ToLocalTime() = {dt.ToLocalTime()}");
    Console.WriteLine($"ToLongDateString() = {dt.ToLongDateString()}");
    Console.WriteLine($"ToLongTimeString() = {dt.ToLongTimeString()}");
    Console.WriteLine($"ToShortDateString() = {dt.ToShortDateString()}");
    Console.WriteLine($"ToShortTimeString() = {dt.ToShortTimeString()}");
    Console.WriteLine($"ToUniversalTime() = {dt.ToUniversalTime()}");
  }
}
