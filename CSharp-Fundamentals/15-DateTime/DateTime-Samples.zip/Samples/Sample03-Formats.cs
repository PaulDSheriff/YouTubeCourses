﻿namespace CSharpSamples;

public class Sample03 {
  public static void AllFormats() {
    DateTime dt = DateTime.Now;

    for (int index = 0; index < dt.GetDateTimeFormats().Length; index++) {
      Console.WriteLine($"GetDateTimeFormats()[{index}] = {dt.GetDateTimeFormats()[index]}");
    }
  }

  public static void LongFormats() {
    DateTime dt = DateTime.Now;
    Console.WriteLine("** Long Date Patterns **");
    for (int index = 0; index < dt.GetDateTimeFormats('D').Length; index++) {
      Console.WriteLine($"GetDateTimeFormats('D')[{index}] = {dt.GetDateTimeFormats('D')[index]}");
    }
  }

  public static void ShortFormats() {
    DateTime dt = DateTime.Now;
    Console.WriteLine("** Short Date Patterns **");
    for (int index = 0; index < dt.GetDateTimeFormats('d').Length; index++) {
      Console.WriteLine($"GetDateTimeFormats('d')[{index}] = {dt.GetDateTimeFormats('d')[index]}");
    }
  }
}
