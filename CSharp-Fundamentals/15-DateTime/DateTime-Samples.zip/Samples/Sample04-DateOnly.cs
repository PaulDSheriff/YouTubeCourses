﻿namespace CSharpSamples;

public class Sample04 {
  public static void DateOnlySample() {
    DateOnly dt = DateOnly.FromDateTime(DateTime.Now);

    Console.WriteLine($"ToString() = {dt}");
    Console.WriteLine($"Month = {dt.Month}");
    Console.WriteLine($"Day = {dt.Day}");
    Console.WriteLine($"Year = {dt.Year}");
  }
}
