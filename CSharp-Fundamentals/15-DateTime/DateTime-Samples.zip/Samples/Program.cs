﻿using CSharpSamples;

// Call samples
Sample01.Properties();
//Sample02.Methods();

//Sample03.AllFormats();
//Sample03.LongFormats();
//Sample03.ShortFormats();

//Sample04.DateOnlySample();
//Sample05.TimeOnlySample();

// Pause to review the results
Console.ReadKey();