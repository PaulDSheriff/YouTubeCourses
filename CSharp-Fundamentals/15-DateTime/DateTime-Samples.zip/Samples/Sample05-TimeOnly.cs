﻿namespace CSharpSamples;

public class Sample05 {
  public static void TimeOnlySample() {
    TimeOnly ti = TimeOnly.FromDateTime(DateTime.Now);

    Console.WriteLine($"ToString() = {ti}");
    Console.WriteLine($"Hour = {ti.Hour}");
    Console.WriteLine($"Minute = {ti.Minute}");
    Console.WriteLine($"Second = {ti.Second}");
  }
}
