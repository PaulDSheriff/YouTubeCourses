﻿namespace CSharpSamples;

public class Sample01 {
  public static void MathOperators() {
    //*************************
    // Addition Operator
    decimal price = 1.99M;

    price = price + 10;
    //price += 10;

    Console.WriteLine(price);

    //*************************
    // Subtraction Operator
    price = price - 10;
    //price -= 10;

    Console.WriteLine(price);

    //*************************
    // Multiplication Operator
    price = price * 2;
    //price *= 2;

    Console.WriteLine(price);

    //*************************
    // Division Operator
    price = price / 2;
    //price /= 2;

    Console.WriteLine(price);


    //*************************
    // Exponentiation Operator
    double cost = 5.99D;

    cost = Math.Pow(cost, 3);

    Console.WriteLine(price);


    //*************************
    // Integer Division
    int qty = 10;

    qty = qty / 3;

    Console.WriteLine(qty);

    //*********************
    // Integer Remainder
    qty = qty % 3;

    Console.WriteLine(qty);
  }
}
