﻿namespace CSharpSamples;

public class Sample02 {
  public static void UnaryOperators() {    
    int index = 0;

    Console.Write("Post Increment: ");
    Console.WriteLine(index++);
    Console.WriteLine(index);

    Console.Write("Pre Increment: ");
    Console.WriteLine(++index);
    Console.WriteLine(index);

    Console.Write("Post Decrement: ");
    Console.WriteLine(index--);
    Console.WriteLine(index);

    Console.Write("Pre Decrement: ");
    Console.WriteLine(--index);
    Console.WriteLine(index);
  }
}
