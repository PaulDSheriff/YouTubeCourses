﻿using CSharpSamples;

// Call samples
Sample01.MathOperators();
//Sample02.UnaryOperators();
//Sample03.RelationalOperators();
//Sample04.LogicalOperators();

// Pause to review the results
Console.ReadKey();