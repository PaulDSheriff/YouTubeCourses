﻿namespace CSharpSamples;

public class Sample03 {
  public static void RelationalOperators() {
    decimal cost = 4.99M;
    decimal price = 5.99M;

    Console.Write("Less Than: ");
    Console.WriteLine(cost < price);
    Console.Write("Greater Than: ");
    Console.WriteLine(cost > price);
    Console.Write("Less Than or Equal To: ");
    Console.WriteLine(cost <= price);
    Console.Write("Greater Than or Equal To: ");
    Console.WriteLine(cost >= price);
    Console.Write("Equal To: ");
    Console.WriteLine(cost == price);
    Console.Write("Not Equal To: ");
    Console.WriteLine(cost != price);
  }
}
