﻿namespace CSharpSamples;

public class Sample04 {
  public static void LogicalOperators() {
    decimal cost = 0.00M;
    decimal price = 5.99M;
    bool isActive = true;

    Console.Write("Not Operator: ");
    Console.WriteLine(!isActive);

    Console.Write("Logical And: ");
    Console.WriteLine(cost == 0 && price == 0);

    Console.Write("Logical Or: ");
    Console.WriteLine(cost == 0 || price == 0);
  }
}
