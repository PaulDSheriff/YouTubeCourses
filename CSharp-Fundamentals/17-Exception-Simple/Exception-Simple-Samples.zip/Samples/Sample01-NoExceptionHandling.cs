﻿namespace CSharpSamples;

public class Sample01 {
  public static void NoExceptionHandling() {
    long size;
    FileStream fs;

    fs = File.Open(@"D:\Samples\Test.txt", FileMode.Open);
    size = fs.Length;
    fs.Close();
  }
}
