﻿namespace CSharpSamples;

public class Sample05 {
  public static void SpecificExceptions() {
    long size;
    FileStream? fs = null;

    try {
      // File Not Found
      fs = File.Open(@"D:\Samples\Test.txt", FileMode.Open);
      // Argument Exception
      //fs = File.Open("", FileMode.Open);
      // Directory Not Found
      //fs = File.Open(@"D:\BadDirectory\Test.txt", FileMode.Open);
      size = fs.Length;
    }
    catch (ArgumentOutOfRangeException ex) {  // This one must go before 'ArgumentException'
      Console.WriteLine(ex.Message);
    }
    catch (ArgumentException ex) {
      Console.WriteLine(ex.Message);
    }
    catch (PathTooLongException ex) {
      Console.WriteLine(ex.Message);
    }
    catch (DirectoryNotFoundException ex) {  // This one must go before 'IOException'
      Console.WriteLine(ex.Message);
    }
    catch (FileNotFoundException ex) {  // This one must go before 'IOException'
      Console.WriteLine(ex.Message);
    }
    catch (IOException ex) {
      Console.WriteLine(ex.Message);
    }
    catch (UnauthorizedAccessException ex) {
      Console.WriteLine(ex.Message);
    }
    catch (NotSupportedException ex) {
      Console.WriteLine(ex.Message);
    }
    catch (Exception ex) {
      Console.WriteLine(ex.Message);
    }
    finally {
      fs?.Close();
      fs?.Dispose();
    }
  }
}
