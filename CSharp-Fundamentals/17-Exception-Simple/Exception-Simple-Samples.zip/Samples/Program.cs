﻿using CSharpSamples;

Sample01.NoExceptionHandling();
//Sample02.TryCatch();
//Sample03.ExceptionObject();
//Sample04.Finally();
//Sample05.SpecificExceptions();

// Pause to review the results
Console.ReadKey();