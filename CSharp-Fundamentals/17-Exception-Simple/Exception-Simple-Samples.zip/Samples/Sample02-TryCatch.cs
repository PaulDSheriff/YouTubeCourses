﻿namespace CSharpSamples;

public class Sample02 {
  public static void TryCatch() {
    long size;
    FileStream fs;

    try {
      fs = File.Open(@"D:\Samples\Test.txt", FileMode.Open);
      size = fs.Length;
      fs.Close();
    }
    catch {
      Console.WriteLine("Error Occurred");
    }
  }
}
