﻿namespace CSharpSamples;

public class Sample04 {
  public static void Finally() {
    long size;
    FileStream? fs = null;

    try {
      fs = File.Open(@"D:\Samples\Test.txt", FileMode.Open);
      size = fs.Length;
    }
    catch (Exception ex) {
      Console.WriteLine(ex.ToString());
    }
    finally {
      fs?.Close();
      fs?.Dispose();
    }
  }
}
