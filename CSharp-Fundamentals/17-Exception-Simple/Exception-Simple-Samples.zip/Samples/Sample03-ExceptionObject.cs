﻿namespace CSharpSamples;

public class Sample03 {
  public static void ExceptionObject() {
    long size;
    FileStream fs;

    try {
      fs = File.Open(@"D:\Samples\Test.txt", FileMode.Open);
      size = fs.Length;
      fs.Close();
    }
    catch (Exception ex) {
      Console.WriteLine($"Message: {ex.Message}");
      Console.WriteLine($"InnerException: {ex.InnerException}");
      Console.WriteLine($"Source: {ex.Source}");
      Console.WriteLine($"TargetSite: {ex.TargetSite}");
      Console.WriteLine();
      Console.WriteLine("*********************************************");
      Console.WriteLine(ex.ToString());
    }
  }
}
