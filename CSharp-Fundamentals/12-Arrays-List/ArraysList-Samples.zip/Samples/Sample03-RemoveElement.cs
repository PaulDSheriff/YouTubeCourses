﻿using System.Collections;

namespace CSharpSamples;

public class Sample03 {
  public static void RemoveElement() {
    ArrayList arr = new() {
      1,
      "10 Speed Bicyle",
      true,
      DateTime.Now
    };

    // Remove an element at index
    arr.RemoveAt(2);

    // Remove an element by value
    arr.Remove("10 Speed Bicyle");

    foreach (var item in arr) {
      Console.WriteLine(item);
    }
  }
}