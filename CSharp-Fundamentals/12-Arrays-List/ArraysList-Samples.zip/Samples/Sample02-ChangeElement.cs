﻿using System.Collections;

namespace CSharpSamples;

public class Sample02 {
  public static void ChangeElement() {
    ArrayList arr = new() {
      1,
      "10 Speed Bicyle",
      true,
      DateTime.Now
    };

    // Change an element
    arr[1] = "Brake Pad";

    foreach (var item in arr) {
      Console.WriteLine(item);
    }
  }
}