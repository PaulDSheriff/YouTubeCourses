﻿using System.Collections;

namespace CSharpSamples;

public class Sample01 {
  public static void CreateArrayList() {
    ArrayList arr = new();

    Console.WriteLine(arr.Count);

    Console.WriteLine();
    arr.Add(1);
    arr.Add("10 Speed Bicyle");
    arr.Add(true);
    arr.Add(DateTime.Now);

    foreach (var item in arr) {
      Console.WriteLine(item);
    }

    Console.WriteLine();
    Console.WriteLine(arr.Count);
  }

  public static void AlternateSyntaxArrayList() {
    ArrayList arr = new() {
      1,
      "10 Speed Bicyle",
      true,
      DateTime.Now
    };

    foreach (var item in arr) {
      Console.WriteLine(item);
    }
  }
}
