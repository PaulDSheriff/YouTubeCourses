﻿using CSharpSamples;
using System.Collections;

Sample01.CreateArrayList();
//Sample01.AlternateSyntaxArrayList();
//Sample02.ChangeElement();
//Sample03.RemoveElement();

// Pause to review the results
Console.ReadKey();