﻿namespace CSharpSamples;

public class Sample03 {
  public static void MultipleDimensions() {
    string[,] products = {
      { "PROD1", "PROD2", "PROD3" },
      { "Helmet", "10 Speed Bicycle", "Biking Gloves" }
    };

    Console.WriteLine(products.Length);
    Console.WriteLine(products.Rank);

    Console.WriteLine();
    Console.WriteLine(products[0, 0]);
    Console.WriteLine(products[0, 1]);
    Console.WriteLine(products[0, 2]);

    Console.WriteLine();
    Console.WriteLine(products[1, 0]);
    Console.WriteLine(products[1, 1]);
    Console.WriteLine(products[1, 2]);
  }

  public static void ForEach() {
    string[,] products = {
      { "PROD1", "PROD2", "PROD3" },
      { "Helmet", "10 Speed Bicycle", "Biking Gloves" }
    };

    Console.WriteLine(products.Length);
    Console.WriteLine(products.Rank);

    Console.WriteLine();
    foreach (string item in products) {
      Console.WriteLine(item);
    }
  }

  public static void ForLoop() {
    string[,] products = {
      { "PROD1", "PROD2", "PROD3" },
      { "Helmet", "10 Speed Bicycle", "Biking Gloves" }
    };

    Console.WriteLine(products.Length);
    Console.WriteLine(products.Rank);

    Console.WriteLine();
    for (int index = 0; index < 3; index++) {
      Console.WriteLine(products[0, index] + " - " + products[1, index]);
    }
  }
}
