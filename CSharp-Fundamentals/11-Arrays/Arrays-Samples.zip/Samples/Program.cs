﻿using CSharpSamples;

// Call samples
Sample01.IntArray();
//Sample01.StringArray();
//Sample01.ProductArray();

//Sample02.ChangeAValue();
//Sample02.AddAValue();
//Sample02.AddAValueUsingCopyTo();
//Sample02.RemoveAValue();

//Sample03.MultipleDimensions();
//Sample03.ForEach();
//Sample03.ForLoop();

// Pause to review the results
Console.ReadKey();