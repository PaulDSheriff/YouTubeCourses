﻿namespace CSharpSamples;

public class Sample02 {
  public static void ChangeAValue() {
    string[] names = { "Helmet", "10 Speed Bicycle", "Biking Gloves" };

    names[1] = "Brake Pad";

    // Display new array
    foreach (string item in names) {
      Console.WriteLine(item);
    }
  }

  public static void AddAValue() {
    string[] names = { "Helmet", "10 Speed Bicycle", "Biking Gloves" };

    // Create new array of the old size + 1
    string[] names2 = new string[names.Length + 1];

    // Copy old values to new array
    for (int index = 0; index < names.Length; index++) {
      names2[index] = names[index];
    }

    // Add item into last position
    names2[names2.Length - 1] = "Brake Pad";

    // Display new array
    foreach (string item in names2) {
      Console.WriteLine(item);
    }
  }

  public static void AddAValueUsingCopyTo() {
    string[] names = { "Helmet", "10 Speed Bicycle", "Biking Gloves" };

    // Create new array of the old size + 1
    string[] names2 = new string[names.Length + 1];

    // Copy old values to new array
    names.CopyTo(names2, 0);

    // Add item into last position
    names2[names2.Length - 1] = "Brake Pad";

    // Display new array
    foreach (string item in names2) {
      Console.WriteLine(item);
    }
  }

  public static void RemoveAValue() {
    string[] names = { "Helmet", "10 Speed Bicycle", "Biking Gloves" };

    // Create new array of the old size - 1
    string[] names2 = new string[names.Length - 1];

    // Copy old values to new array
    // Remove the 2nd element
    int originalIndex = 0;
    int newIndex = 0;
    while (originalIndex < names.Length) {
      if (originalIndex != 1) {
        names2[newIndex] = names[originalIndex];
        newIndex++;
      }
      originalIndex++;
    }

    // Display new array
    foreach (string item in names2) {
      Console.WriteLine(item);
    }
  }
}
