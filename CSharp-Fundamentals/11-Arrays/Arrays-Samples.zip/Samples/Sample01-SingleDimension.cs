﻿namespace CSharpSamples; 

public class Sample01 {
  public static void IntArray() {
    int[] ids = new int[3];

    // Alternate declaration syntaxes
    // int[] ids = { 1, 2, 3 };
    // int[] ids = new int[] { 1, 2, 3 };

    // Assign values to elements
    ids[0] = 1;
    ids[1] = 2;
    ids[2] = 3;

    Console.WriteLine("Length = " + ids.Length);

    Console.WriteLine();
    foreach (int item in ids) {
      Console.WriteLine(item);
    }
  }

  public static void StringArray() {
    string[] names = { "Helmet", "10 Speed Bicycle", "Biking Gloves" };

    foreach (string item in names) {
      Console.WriteLine(item);
    }
  }

  public static void ProductArray() {
    Product[] products = new Product[2];

    products[0] = new Product {
      ProductId = 1,
      Name = "Helmet"
    };

    products[1] = new Product {
      ProductId = 2,
      Name = "10 Speed Bicycle"
    };

    foreach (Product item in products) {
      Console.WriteLine(item.ProductId + " - " + item.Name);
    }
  }
}
