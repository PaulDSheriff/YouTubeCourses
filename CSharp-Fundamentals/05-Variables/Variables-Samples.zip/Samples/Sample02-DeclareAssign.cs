﻿namespace CSharpSamples;

public class Sample02 {
  public static void DeclareAssign() {
    // Declare and assign values
    byte data = 1;
    short index = default(short);
    long bin = 123456789;
    float qty = 359;
    double cost = 1.92;

    Console.WriteLine(data);
    Console.WriteLine(index);
    Console.WriteLine(bin);
    Console.WriteLine(qty);
    Console.WriteLine(cost);
  }
}
