﻿using CSharpSamples;

// Call samples
Sample01.DeclareVariables();
//Sample02.DeclareAssign();
//Sample03.ObjectDataType();
//Sample04.DefaultValues();
//Sample05.NullableDataTypes();

// Pause to review the results
Console.ReadKey();