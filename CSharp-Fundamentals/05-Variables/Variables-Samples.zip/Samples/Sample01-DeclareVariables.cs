﻿namespace CSharpSamples;

public class Sample01 {
  public static void DeclareVariables() {
    // Character Variable
    char rating;

    rating = 'A';

    Console.WriteLine(rating);

    //*********************
    // String Variable
    string name;

    name = "Helmet";

    Console.WriteLine(name);

    //*********************
    // Boolean Variable
    bool isActive;

    isActive = true;

    Console.WriteLine(isActive);

    //*********************
    // Integer Variable
    int id;

    id = 1;

    Console.WriteLine(id);

    //*********************
    // Decimal Variable
    decimal price;

    price = 5.99M;

    Console.WriteLine(price);

    //*********************
    // DateOnly Variable
    DateTime sellDate;

    sellDate = DateTime.Parse("11/1/2022");

    Console.WriteLine(sellDate);

    //*********************
    // DateOnly Variable
    DateOnly endDate;

    endDate = DateOnly.FromDateTime(sellDate);

    Console.WriteLine(endDate);
  }
}
