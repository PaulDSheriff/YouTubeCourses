﻿namespace CSharpSamples;

public class Sample03 {
  public static void ObjectDataType() {
    // Object data type
    object value;

    // Make the variable a numeric
    value = 10;

    Console.WriteLine(value);

    // Make the variable a string
    value = "Hi There";
    Console.WriteLine(value);
  }
}
