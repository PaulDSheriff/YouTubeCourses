﻿namespace CSharpSamples;

public class Sample04 {
  public static void DefaultValues() {
    // Numeric, DateTime and Booleans
    int id = default;
    decimal price = default;
    DateTime sellDate = default;
    bool isActive = default;

    Console.WriteLine(id);
    Console.WriteLine(price);
    Console.WriteLine(sellDate);
    Console.WriteLine(isActive);

    // String can NOT use the 'default' keyword
    //string name = default;
    //Console.WriteLine(name);
  }
}
