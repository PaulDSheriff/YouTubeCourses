﻿namespace CSharpSamples;

public class Sample05 {
  public static void NullableDataTypes() {
    // Use the ? to create nullable types
    int? id = default;
    decimal? price = default;
    DateTime? sellDate = default;

    Console.WriteLine(id);
    Console.WriteLine(price);
    Console.WriteLine(sellDate);

  }
}
