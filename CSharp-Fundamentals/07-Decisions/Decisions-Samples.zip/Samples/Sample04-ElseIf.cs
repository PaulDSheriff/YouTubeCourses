﻿namespace CSharpSamples;

public class Sample04 {
  public static void ElseIfStatement() {
    decimal price = 5.99M;

    if (price < 5) {
      Console.WriteLine("Product Is Less Than $5.00.");
    }
    else if (price < 10) {
      Console.WriteLine("Product Is Less Than $10.00.");
    }
    else if (price < 100) {
      Console.WriteLine("Product Is Less Than $100.00.");
    }
  }
}
