﻿namespace CSharpSamples;

public class Sample06 {
  public static void Ternary() {
    decimal? cost = 0.00M;

    Console.WriteLine(cost == 0 ? "Cost is Zero" : "Cost is not Zero");
  }
}
