﻿#define LANGUAGE_US

namespace CSharpSamples;

public class Sample10 {
  public static void Define() {
#if LANGUAGE_US
    Console.WriteLine("US English");
#else
  Console.WriteLine("Other Language");
#endif
  }
}
