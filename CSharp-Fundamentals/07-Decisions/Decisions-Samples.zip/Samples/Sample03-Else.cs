﻿namespace CSharpSamples;

public class Sample03 {
  public static void ElseStatement() {
    string name = "";

    if (name == "") {
      Console.WriteLine("Product Name Must Be Filled In.");
    }
    else {
      Console.WriteLine("Valid Product Name");
    }
  }
}
