﻿namespace CSharpSamples;

public class Sample08 {
  public static void NullCoalescing() {
    decimal? price = null;

    Console.WriteLine(price ?? 0);
  }
}
