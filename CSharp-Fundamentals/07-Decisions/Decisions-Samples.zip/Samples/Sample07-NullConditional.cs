﻿namespace CSharpSamples;

public class Sample07 {
  public static void NullConditional() {
    decimal? cost = 0.00M;
    decimal? price = null;

    Console.WriteLine(cost?.Equals(0));
    Console.WriteLine(price?.Equals(0));
  }
}
