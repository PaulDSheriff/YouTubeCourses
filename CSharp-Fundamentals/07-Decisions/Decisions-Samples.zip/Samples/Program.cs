﻿using CSharpSamples;

// Call samples
Sample01.SingleLineIf();
//Sample02.IfStatement();
//Sample03.ElseStatement();
//Sample04.ElseIfStatement();
//Sample05.SwitchStatement();
//Sample06.Ternary();
//Sample07.NullConditional();
//Sample08.NullCoalescing();
//Sample09.IsOperator();
//Sample10.Define();

// Pause to review the results
Console.ReadKey();