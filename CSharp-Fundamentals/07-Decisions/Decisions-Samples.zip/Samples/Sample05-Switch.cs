﻿namespace CSharpSamples;

public class Sample05 {
  public static void SwitchStatement() {
    decimal price = 5.99M;

    switch (price) {
      case < 5:
        Console.WriteLine("Product Is Less Than $5.00.");
        break;
      case < 10:
        Console.WriteLine("Product Is Less Than $10.00.");
        break;
      case < 100:
        Console.WriteLine("Product Is Less Than $100.00.");
        break;
    }
  }
}
