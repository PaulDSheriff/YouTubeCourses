﻿namespace CSharpSamples;

public class Sample02 {
  public static void IfStatement() {
    string name = "";

    if (name == "") {
      Console.WriteLine("Product Name Must Be Filled In.");
    }
  }
}
