﻿namespace CSharpSamples;

public class Sample01 {
  public static void SingleLineIf() {
    string name = "";

    if (name == "") Console.WriteLine("Product Name Must Be Filled In.");
  }
}
