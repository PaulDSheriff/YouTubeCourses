﻿namespace CSharpSamples;

public class Sample09 {
  public static void IsOperator() {
    decimal price = 5.99M;
    object value = price;

    Console.WriteLine(value is decimal);
  }
}
