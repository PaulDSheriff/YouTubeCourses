﻿namespace CSharpSamples;

public class Sample01 {
  public static void DecimalToString() {
    decimal price = 5.99M;

    Console.WriteLine(price.ToString());

    Console.WriteLine(price.ToString("c"));

    Console.WriteLine(Convert.ToString(price));
  }

  public static void IntegerToString() {
    int qty = 10;

    Console.WriteLine(qty.ToString());

    Console.WriteLine(Convert.ToString(qty));

    // DOES NOT work
    //Console.WriteLine((string)qty);
  }
}
