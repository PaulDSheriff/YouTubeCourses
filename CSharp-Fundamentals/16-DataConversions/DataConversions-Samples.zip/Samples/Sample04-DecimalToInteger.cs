﻿namespace CSharpSamples;

public class Sample04 {
  public static void DecimalToInteger() {
    decimal price = 5.99M;

    // Truncates the decimal portion
    Console.WriteLine((int)price);

    // Rounds to the nearest whole number
    Console.WriteLine(Convert.ToInt32(price));

    // The following DOES NOT work
    // int result = price;
  }
}
