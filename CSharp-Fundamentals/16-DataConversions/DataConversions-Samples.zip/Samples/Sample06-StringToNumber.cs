﻿namespace CSharpSamples;

public class Sample06 {
  public static void StringToInteger() {
    string qty = "10";
    int result = Convert.ToInt32(qty);

    Console.WriteLine(result);

    // The following DOES NOT work
    //result = (int)qty;
  }

  public static void StringToIntegerUsingParse() {
    string qty = "10";
    int result = int.Parse(qty);

    Console.WriteLine(result);
  }

  public static void StringToIntegerUsingTryParse() {
    string qty = "10";
    int result = 0;

    if (int.TryParse(qty, out result)) {
      Console.WriteLine(result);
    }
    else {
      Console.WriteLine("Not a Valid Integer");
    }
  }
}
