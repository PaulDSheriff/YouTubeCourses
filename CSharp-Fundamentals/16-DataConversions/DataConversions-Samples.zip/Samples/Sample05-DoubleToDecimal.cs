﻿namespace CSharpSamples;

public class Sample05 {
  public static void DoubleToDecimal() {
    decimal price = 5.99M;

    Console.WriteLine((double)price);

    Console.WriteLine(Convert.ToDouble(price));
  }
}
