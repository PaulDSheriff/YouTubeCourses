﻿namespace CSharpSamples;

public class Sample02 {
  public static void DateTimeToString() {
    DateTime dt = DateTime.Now;

    Console.WriteLine(dt.ToString());
    Console.WriteLine(Convert.ToString(dt));

    // DOES NOT work
    // Console.WriteLine((string)dt);
  }

  public static void DateOnlyToString() {
    DateOnly dt = DateOnly.FromDateTime(DateTime.Now);

    Console.WriteLine(dt.ToString());
    Console.WriteLine(Convert.ToString(dt));
    // DOES NOT work
    //Console.WriteLine((string)dt);
  }
}
