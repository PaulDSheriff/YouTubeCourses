﻿namespace CSharpSamples;

public class Sample07 {
  public static void StringToDateTime() {
    string dt = "1/1/2022";
    DateTime result = Convert.ToDateTime(dt);

    Console.WriteLine(result);
  }

  public static void StringToDateTimeUsingParse() {
    string dt = "1/1/2022";

    DateTime result = DateTime.Parse(dt);

    Console.WriteLine(result);
  }

  public static void StringToDateTimeUsingTryParse() {
    string dt = "1/1/2022";
    DateTime result;

    if (DateTime.TryParse(dt, out result)) {
      Console.WriteLine(result);
    }
    else {
      Console.WriteLine("Not a Valid Date/Time");
    }
  }
}
