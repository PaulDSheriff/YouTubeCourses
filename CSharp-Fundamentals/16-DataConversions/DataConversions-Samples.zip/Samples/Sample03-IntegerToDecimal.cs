﻿namespace CSharpSamples;

public class Sample03 {
  public static void IntegerToDecimal() {
    decimal price = 5.99M;
    int qty = 10;

    price = qty;

    Console.WriteLine(qty);
  }
}
