﻿using CSharpSamples;

Sample01.DecimalToString();
//Sample01.IntegerToString();

//Sample02.DateTimeToString();
//Sample02.DateOnlyToString();

//Sample03.IntegerToDecimal();
//Sample04.DecimalToInteger();
//Sample05.DoubleToDecimal();

//Sample06.StringToInteger();
//Sample06.StringToIntegerUsingParse();
//Sample06.StringToIntegerUsingTryParse();

//Sample07.StringToDateTime();
//Sample07.StringToDateTimeUsingParse();
//Sample07.StringToDateTimeUsingTryParse();

// Pause to review the results
Console.ReadKey();