﻿namespace CSharpSamples;

public class Sample04 {
  public static void Compare() {
    string name = "10 speed bicycle";

    //***********************
    // Compare same strings
    int result = String.Compare(name, "10 speed bicycle");

    // The two parameters will sort in the same position
    Console.WriteLine(result);  // Result = 0

    //***********************
    // Compare shorter string
    result = String.Compare(name, "10 speed bicycl");

    // 'name' follows 2nd parameter when sorting
    Console.WriteLine(result);  // Result = 1

    //***********************
    // Compare longer string 
    result = String.Compare(name, "10 speed bicycle 123");

    // 'name' precedes 2nd parameter when sorting
    Console.WriteLine(result);  // Result = -1
  }

  public static void Contains() {
    string name = "10 speed bicycle";

    bool result = name.Contains("10 speed");

    Console.WriteLine(result);
  }

  public static void EndsWith() {
    string name = "10 speed bicycle";

    bool result = name.EndsWith("cycle");

    Console.WriteLine(result);
  }

  public static void StartsWith() {
    string name = "10 speed bicycle";

    bool result = name.StartsWith("10");

    Console.WriteLine(result);
  }

  public static void Format() {
    string name = "{0} speed bicycle {1}";

    string result = String.Format(name, "10", "(Blue)");

    Console.WriteLine(result);
  }

  public static void IndexOf() {
    string name = "10 speed bicycle";

    int result = name.IndexOf("bicycle");

    Console.WriteLine(result);
  }

  public static void LastIndexOf() {
    string name = "10 speed bicycle";

    int result = name.LastIndexOf("speed");

    Console.WriteLine(result);
  }

  public static void IsNullOrEmptyWhiteSpace() {
    string name = "  ";

    bool result = String.IsNullOrEmpty(name);

    Console.WriteLine("IsNullOrEmpty = " + result);

    // IsNullOrWhiteSpace
    result = String.IsNullOrWhiteSpace(name);

    Console.WriteLine("IsNullOrWhiteSpace = " + result);
  }

  public static void Split() {
    string name = "10 Speed Bicycle";

    string[] arr = name.Split(" ");

    for (int index = 0; index < arr.Length; index++) {
      Console.WriteLine(arr[index]);
    }
  }

  public static void Join() {
    string[] arr = { "10", "Speed", "Bicycle" };

    string name = String.Join(" ", arr);

    Console.WriteLine(name);
  }

  public static void Substring() {
    string name = "10 Speed Bicycle";

    Console.WriteLine(name.Substring(0, 8));
  }

  public static void ToLowerToUpper() {
    string name = "10 Speed Bicycle";

    Console.WriteLine("ToLower() = " + name.ToLower());

    Console.WriteLine("ToUpper() = " + name.ToUpper());
  }

  public static void TrimTrimEnd() {
    string name = "     10 Speed Bicycle     ";

    Console.WriteLine("Trim() = " + name.Trim().Length);

    Console.WriteLine("TrimEnd() = " + name.TrimEnd().Length);
  }
}
