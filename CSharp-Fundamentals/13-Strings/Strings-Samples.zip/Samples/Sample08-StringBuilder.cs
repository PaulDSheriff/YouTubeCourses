﻿using System.Text;

namespace CSharpSamples;

public class Sample08 {
  public static void StringBuilder() {
    StringBuilder sb = new(1024);

    sb.Append("Helmet");
    sb.AppendLine(" - 1");

    sb.AppendFormat("{0} - {1}", "10 Speed Bicycle", 2);

    Console.WriteLine(sb.ToString());
  }
}
