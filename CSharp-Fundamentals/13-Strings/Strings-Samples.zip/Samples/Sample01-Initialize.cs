﻿namespace CSharpSamples;

public class Sample01 {
  public static void Initialize() {
string name = "Helmet";
string desc = new("A large size gray helmet");
string astericks = new('*', 40);

Console.WriteLine(name);
Console.WriteLine(desc);
Console.WriteLine(astericks);
  }
}
