﻿using CSharpSamples;

Sample01.Initialize();
//Sample02.Immutability();
//Sample03.Properties();

//Sample04.Compare();
//Sample04.Contains();
//Sample04.EndsWith();
//Sample04.StartsWith();
//Sample04.Format();
//Sample04.IndexOf();
//Sample04.LastIndexOf();
//Sample04.IsNullOrEmptyWhiteSpace();
//Sample04.Split();
//Sample04.Join();
//Sample04.Substring();
//Sample04.ToLowerToUpper();
//Sample04.TrimTrimEnd();

//Sample05.EscapeSequences();
//Sample06.Verbatim();
//Sample07.Interpolation();
//Sample08.StringBuilder();

// Pause to review the results
Console.ReadKey();