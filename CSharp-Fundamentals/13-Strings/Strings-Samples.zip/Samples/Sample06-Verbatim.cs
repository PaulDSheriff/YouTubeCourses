﻿namespace CSharpSamples;

public class Sample06 {
  public static void Verbatim() {
    string fileName = @"D:\Samples\Test.txt";

    Console.WriteLine(fileName);

    string value = @"D:\nTest\t";

    Console.WriteLine(value);

    string desc = @"This 10 speed bicycle has excellent
  qualities and was built for the road. Come try this
    fantastic 10 speed bike today.";

    Console.WriteLine(desc);
  }
}
