﻿namespace CSharpSamples;

public class Sample02 {
  public static void Immutability() {
    string name1 = "10 speed ";
    string name2 = "bicycle";

    // Performing concatentation creates
    // a new object in memory and the old 
    // memory space occupied by 'name1'
    // is released
    name1 = name1 + name2;

    Console.WriteLine(name1);
  }
}
