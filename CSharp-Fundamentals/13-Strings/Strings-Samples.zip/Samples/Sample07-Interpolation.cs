﻿namespace CSharpSamples;

public class Sample07 {
  public static void Interpolation() {
    int id = 1;
    string name = "Bicycle";

    string result = $"ID = {id}, Name='{name}'";

    Console.WriteLine(result);
  }
}
