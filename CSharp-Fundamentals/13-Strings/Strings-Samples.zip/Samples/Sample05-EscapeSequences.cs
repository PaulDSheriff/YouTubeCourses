﻿namespace CSharpSamples;

public class Sample05 {
  public static void EscapeSequences() {
    string name = "10 Speed Bicycle \"Blue\"";

    Console.WriteLine(name);

    name = "10 Speed Bicycle \nBlue";
    Console.WriteLine(name);

    name = "10\tSpeed\tBicycle\t\"Blue\"";
    Console.WriteLine(name);
  }
}
