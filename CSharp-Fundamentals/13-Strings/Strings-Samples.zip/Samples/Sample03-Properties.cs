﻿namespace CSharpSamples;

public class Sample03 {
  public static void Properties() {
    string name = "10 speed bicycle";

    Console.WriteLine(name.Length);
    Console.WriteLine(name[3]);
    Console.WriteLine(name[3..8]);
  }
}
