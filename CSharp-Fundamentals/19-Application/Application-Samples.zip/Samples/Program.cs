﻿using CSharpSamples;
string fileName = @"D:\Samples\Products.tsv";

Product entity = new();
Product[] products = entity.GetProducts(fileName);

foreach (Product item in products) {
  Console.WriteLine(item);
}

Console.ReadKey();