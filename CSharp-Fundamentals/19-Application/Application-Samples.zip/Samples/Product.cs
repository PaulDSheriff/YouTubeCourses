﻿using System.Collections;
using System.Text;

namespace CSharpSamples;

public class Product {
  public int ProductId { get; set; }
  public string Name { get; set; }

  private decimal _ListPrice;
  public decimal ListPrice
  {
    get { return _ListPrice; }
    set
    {
      _ListPrice = value;
      CalculateProfit();
    }
  }

  private decimal _StandardCost;

  public decimal StandardCost
  {
    get { return _StandardCost; }
    set
    {
      _StandardCost = value;
      CalculateProfit();
    }
  }

  public decimal Profit { get; set; }
  public DateTime SellStartDate { get; set; }
  public DateTime SellEndDate { get; set; }

  private void CalculateProfit() {
    Profit = _ListPrice - StandardCost;
  }

  public int GetNumberOfSellDays() {
    return (SellEndDate - SellStartDate).Days;
  }

  public Product[] GetProducts(string fileName) {
    Product[] ret = null;
    string[] lines;

    try {
      lines = ReadProductFile(fileName);
      ret = ProcessProductLines(lines);
    }
    catch (FileNotFoundException ex) {
      Console.WriteLine(ex.ToString());
    }
    catch (FileTooLargeException ex) {
      Console.WriteLine(ex.ToString());
    }
    catch (Exception ex) {
      Console.WriteLine(ex.ToString());
    }

    return ret;
  }

  private string[] ReadProductFile(string fileName) {
    string[] ret;

    if (File.Exists(fileName)) {
      // Check to ensure file is not too large to open
      CheckFileSize(fileName);
      // Attempt to read all lines in the file
      ret = File.ReadAllLines(fileName);
    }
    else {
      throw new FileNotFoundException($"The file '{fileName}' does not exist.");
    }

    return ret;
  }

  private void CheckFileSize(string fileName) {
    FileStream fs = null;

    try {
      fs = File.Open(fileName, FileMode.Open);
      if (fs.Length > 100000) {
        throw new FileTooLargeException($"The file '{fileName}' is too large.", fs.Length);
      }
    }
    finally {
      fs?.Close();
    }
  }

  private Product[] ProcessProductLines(string[] lines) {
    Product[] ret;
    ArrayList products = new();

    foreach (string item in lines) {
      string[] entity = item.Split('\t');

      products.Add(new Product {
        ProductId = Convert.ToInt32(entity[0]),
        Name = entity[1],
        StandardCost = Convert.ToDecimal(entity[2]),
        ListPrice = Convert.ToDecimal(entity[3]),
        SellStartDate = Convert.ToDateTime(entity[4]),
        SellEndDate = string.IsNullOrEmpty(entity[5]) ? DateTime.MinValue : Convert.ToDateTime(entity[5])
      });
    }

    // Convert ArrayList to Array
    ret = (Product[])products.ToArray(typeof(Product));

    return ret;
  }

  public override string ToString() {
    StringBuilder sb = new(1024);

    sb.AppendLine($"{Name} - ({ProductId})");
    sb.Append("Cost = " + StandardCost.ToString("c"));
    sb.Append("  Price = " + ListPrice.ToString("c"));
    sb.AppendLine("  Profit = " + Profit.ToString("c"));
    sb.Append("Start Selling = " + SellStartDate.ToString("d"));
    if (SellEndDate == DateTime.MinValue) {
      sb.AppendLine("  No Selling End Date");
    }
    else {
      sb.Append("  End Selling on = '" + SellEndDate.ToString("d") + "'");
      sb.AppendLine("  Selling Days = " + GetNumberOfSellDays());
    }

    return sb.ToString();
  }
}