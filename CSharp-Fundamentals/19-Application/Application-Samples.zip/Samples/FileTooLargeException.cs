﻿using System.Text;

public class FileTooLargeException : Exception {
  public long FileSize { get; set; }

  public FileTooLargeException(string message, long size) : base(message) {
    FileSize = size;
  }

  public override string ToString() {
    StringBuilder sb = new(256);

    sb.AppendLine($"Message: {Message}");
    sb.AppendLine($"File Size: {FileSize.ToString()}");

    return sb.ToString();
  }
}