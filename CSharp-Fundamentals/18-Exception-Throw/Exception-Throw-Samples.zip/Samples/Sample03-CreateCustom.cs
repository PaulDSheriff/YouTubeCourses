﻿namespace CSharpSamples;

public class Sample03 {
  public static void CreateCustom() {
    // Look at the FileTooLargeException.cs file
  }
}
