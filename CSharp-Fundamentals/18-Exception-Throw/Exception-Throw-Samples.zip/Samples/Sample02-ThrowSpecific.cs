﻿namespace CSharpSamples;

public class Sample02 {
  public static void ThrowSpecific() {
    long size;
    FileStream? fs = null;
    string fileName = @"D:\Samples\Test.txt";

    try {
      fs = File.Open(fileName, FileMode.Open);
      size = fs.Length;
    }
    catch (Exception ex) {
      throw new FileNotFoundException($"Unable to open the file '{fileName}'", ex);
    }
    finally {
      fs?.Close();
      fs?.Dispose();
    }
  }
}
