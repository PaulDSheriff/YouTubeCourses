﻿namespace CSharpSamples;

public class Sample04 {
  /// <summary>
  /// Copy the CSharpSamples.sln file to the D:\Samples folder
  /// </summary>
  public static void ThrowCustom() {
    long size;
    FileStream? fs = null;
    string fileName = @"D:\Samples\CSharpSamples.sln";

    try {
      fs = File.Open(fileName, FileMode.Open);
      size = fs.Length;
      if (size > 100) {
        //  Pass back the new exception. There's no
        // inner exception to pass back, so pass null
        throw new FileTooLargeException($"The file '{fileName}' is too large.", size);
      }
    }
    catch (FileTooLargeException ex) {
      Console.WriteLine(ex.ToString());
    }
    catch (Exception ex) {
      Console.WriteLine(ex.ToString());
    }
    finally {
      fs?.Close();
      fs?.Dispose();
    }
  }
}
