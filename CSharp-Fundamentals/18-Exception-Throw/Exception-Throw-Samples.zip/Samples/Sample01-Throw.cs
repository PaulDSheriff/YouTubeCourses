﻿namespace CSharpSamples;

public class Sample01 {
  public static void Throw() {
    long size;
    FileStream? fs = null;
    string fileName = @"D:\Samples\Test.txt";

    try {
      fs = File.Open(fileName, FileMode.Open);
      size = fs.Length;
    }
    catch {
      throw;
    }
    finally {
      fs?.Close();
      fs?.Dispose();
    }
  }
}
