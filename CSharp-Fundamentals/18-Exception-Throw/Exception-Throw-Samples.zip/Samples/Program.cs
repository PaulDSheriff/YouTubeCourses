﻿using CSharpSamples;

Sample01.Throw();
//Sample02.ThrowSpecific();
//Sample03.CreateCustom();
//Sample04.ThrowCustom();
  
// Pause to review the results
Console.ReadKey();