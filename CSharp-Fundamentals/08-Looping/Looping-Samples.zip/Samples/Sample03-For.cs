﻿using System;

namespace CSharpSamples;

public class Sample03 {
  public static void ForLoop() {
    for (int index = 1; index <= 10; index++) {
      Console.WriteLine(index);
    }

    // Console.WriteLine(index);  // 'index' is not available
  }
}
