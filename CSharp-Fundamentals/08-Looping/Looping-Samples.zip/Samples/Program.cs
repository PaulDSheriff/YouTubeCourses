﻿using CSharpSamples;

// Call samples
Sample01.WhileLoop();
//Sample02.DoLoop();
//Sample03.ForLoop();
//Sample04.ForLoop2();
//Sample05.ForLoop3();
//Sample06.ForEachLoop();

// Pause to review the results
Console.ReadKey();