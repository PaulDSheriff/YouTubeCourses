﻿namespace CSharpSamples;

public class Sample05 {
  public static void ForLoop3() {
    for (int index = 20; index >= 0; index -= 2) {
      Console.WriteLine(index);
    }
  }
}
