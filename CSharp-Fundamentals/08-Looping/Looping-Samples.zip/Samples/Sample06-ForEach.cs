﻿namespace CSharpSamples;

public class Sample06 {
  public static void ForEachLoop() {
    string name = "10 Speed Bicycle";

    foreach (char chr in name) {
      Console.WriteLine(chr);
    }
  }
}
