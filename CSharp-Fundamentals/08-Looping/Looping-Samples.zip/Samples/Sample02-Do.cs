﻿namespace CSharpSamples;

public class Sample02 {
  public static void DoLoop() {
    int index = 0;

    do {
      index += 1;

      Console.WriteLine(index);
    } while (index < 10);
  }
}
