﻿namespace CSharpSamples;

public class Sample04 {
  public static void ForLoop2() {
    int index = 0;

    for (; index <= 20; index += 2) {
      Console.WriteLine(index);
    }

    Console.WriteLine(index);  // 'index' is available
  }
}
