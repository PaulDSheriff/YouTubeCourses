﻿namespace CSharpSamples;

public class Sample01 {
  public static void WhileLoop() {
    int index = 0;

    while (index < 10) {
      index += 1;

      Console.WriteLine(index);
    }
  }
}
