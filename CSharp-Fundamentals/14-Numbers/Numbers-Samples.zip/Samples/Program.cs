﻿using CSharpSamples;

// Call samples
Sample01.EqualsMethod();
//Sample01.MinValue();
//Sample01.MaxValue();
//Sample01.Parse();
//Sample01.TryParse();

//Sample02.Constants();
//Sample02.Negate();
//Sample02.Ceiling();
//Sample02.Floor();
//Sample02.Round();
//Sample02.Truncate();

// Pause to review the results
Console.ReadKey();