﻿namespace CSharpSamples;

public class Sample01 {
  public static void EqualsMethod() {
    int id = 1;

    Console.WriteLine(int.Equals(id, 1));

    // Same as
    Console.WriteLine(id == 1);
  }

  public static void MinValue() {
    Console.WriteLine(int.MinValue);
  }

  public static void MaxValue() {
    Console.WriteLine(int.MaxValue);
  }

  public static void Parse() {
    Console.WriteLine(int.Parse("10"));

    // The following will fail
    // Console.WriteLine(int.Parse("10a"));
  }

  public static void TryParse() {
    Console.WriteLine(int.TryParse("10", out int tmp1));
    Console.WriteLine(int.TryParse("10a", out int tmp2));

    // Don't need to create variables
    // Use the underscore
    Console.WriteLine(int.TryParse("10", out _));
    Console.WriteLine(int.TryParse("10a", out _));
  }
}
