﻿namespace CSharpSamples;

public class Sample02 {
  public static void Constants() {
    var zero = decimal.Zero;
    var one = decimal.One;
    var minOne = decimal.MinusOne;

    Console.WriteLine(zero);
    Console.WriteLine(one);
    Console.WriteLine(minOne);
  }

  public static void Negate() {
    var result = decimal.Negate(10);

    Console.WriteLine(result);
  }

  public static void Ceiling() {
    var result = decimal.Ceiling(10.3M);

    Console.WriteLine(result);
  }

  public static void Floor() {
    var result = decimal.Floor(10.9M);

    Console.WriteLine(result);
  }

  public static void Round() {
    var result = decimal.Round(10.9M);

    Console.WriteLine(result);
  }

  public static void Truncate() {
    var result = decimal.Truncate(10.5M);

    Console.WriteLine(result);
  }
}
