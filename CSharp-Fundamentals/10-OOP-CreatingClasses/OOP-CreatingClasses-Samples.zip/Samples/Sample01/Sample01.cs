﻿namespace CSharpSamples.Sample01;

public class Sample01 {
  public static void SimpleClass() {
    Product entity = new();

    entity.ProductId = 1;
    entity.Name = "Bicycle";

    Console.Write(entity.ProductId);
    Console.Write(" - ");
    Console.WriteLine(entity.Name);
  }
}
