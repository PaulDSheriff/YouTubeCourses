﻿namespace CSharpSamples.Sample04;

public class Sample04 {
  public static void CalculateProfit() {
    Product entity = new() {
      ProductId = 1,
      Name = "Bicycle",
      StandardCost = 2.99M,
      ListPrice = 6.99M
    };

    Console.Write(entity.ProductId);
    Console.Write(" - ");
    Console.WriteLine(entity.Name);
    Console.WriteLine("Cost = " + entity.StandardCost.ToString("c"));
    Console.WriteLine("Price = " + entity.ListPrice.ToString("c"));
    Console.WriteLine("Profit = " + entity.Profit.ToString("c"));
  }
}
