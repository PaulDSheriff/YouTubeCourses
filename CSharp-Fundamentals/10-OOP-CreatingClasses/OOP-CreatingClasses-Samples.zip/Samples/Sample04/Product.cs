﻿namespace CSharpSamples.Sample04;

public class Product {
  public int ProductId { get; set; }
  public string Name { get; set; }

  private decimal _ListPrice;
  public decimal ListPrice
  {
    get { return _ListPrice; }
    set
    {
      _ListPrice = value;
      CalculateProfit();
    }
  }

  private decimal _StandardCost;

  public decimal StandardCost
  {
    get { return _StandardCost; }
    set
    {
      _StandardCost = value;
      CalculateProfit();
    }
  }

  public decimal Profit { get; set; }
   
  private void CalculateProfit() {
    Profit = _ListPrice - StandardCost;
  }
}