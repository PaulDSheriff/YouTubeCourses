﻿namespace CSharpSamples.Sample03;

public class Product {
  public int ProductId { get; set; }
  public string Name { get; set; }

  private decimal _ListPrice;
  public decimal ListPrice
  {
    get { return _ListPrice; }
    set { _ListPrice = value; }
  }

  private decimal _StandardCost;

  public decimal StandardCost
  {
    get { return _StandardCost; }
    set { _StandardCost = value; }
  }
}