﻿namespace CSharpSamples.Sample03;

public class Sample03 {
  public static void CreateFullProperty() {
    Product entity = new() {
      ProductId = 1,
      Name = "Bicycle",
      StandardCost = 2.99M,
      ListPrice = 6.99M
    };

    Console.Write(entity.ProductId);
    Console.Write(" - ");
    Console.WriteLine(entity.Name);
    Console.WriteLine("Cost = " + entity.StandardCost);
    Console.WriteLine("Price = " + entity.ListPrice);
  }
}
