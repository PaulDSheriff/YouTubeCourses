﻿// Call samples
CSharpSamples.Sample01.Sample01.SimpleClass();
//CSharpSamples.Sample02.Sample02.AlternateNewSyntax();
//CSharpSamples.Sample03.Sample03.CreateFullProperty();
//CSharpSamples.Sample04.Sample04.CalculateProfit();
//CSharpSamples.Sample05.Sample05.GetNumberOfSellDays();

// Pause to review the results
Console.ReadKey();