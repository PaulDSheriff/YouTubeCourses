﻿namespace CSharpSamples.Sample05;

public class Sample05 {
  public static void GetNumberOfSellDays() {
    Product entity = new() {
      ProductId = 1,
      Name = "Bicycle",
      StandardCost = 2.99M,
      ListPrice = 6.99M,
      SellStartDate = DateTime.Parse("10/1/2022"),
      SellEndDate = DateTime.Parse("12/31/2022")
    };

    Console.Write(entity.ProductId);
    Console.Write(" - ");
    Console.WriteLine(entity.Name);
    Console.WriteLine("Cost = " + entity.StandardCost.ToString("c"));
    Console.WriteLine("Price = " + entity.ListPrice.ToString("c"));
    Console.WriteLine("Profit = " + entity.Profit.ToString("c"));
    Console.WriteLine("Days to Sell: " + entity.GetNumberOfSellDays());
  }
}
