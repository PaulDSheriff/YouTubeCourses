﻿namespace CSharpSamples.Sample02;

public class Sample02 {
  public static void AlternateNewSyntax() {
    Product entity = new() {
      ProductId = 1,
      Name = "Bicycle"
    };

    Console.Write(entity.ProductId);
    Console.Write(" - ");
    Console.WriteLine(entity.Name);
  }
}
