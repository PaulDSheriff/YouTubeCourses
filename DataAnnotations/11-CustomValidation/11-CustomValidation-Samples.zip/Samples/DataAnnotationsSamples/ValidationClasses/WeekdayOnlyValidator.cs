﻿using System.ComponentModel.DataAnnotations;

namespace Common.Library;

public class WeekdayOnlyValidator
{ 
  public static string ErrorMessage { get; set;  } = string.Empty;
  public static ValidationResult? Validate(DateTime date)
  {
    ErrorMessage ??= "Please enter a valid weekday from Monday to Friday for {0}.";
    return date.DayOfWeek == DayOfWeek.Saturday || 
      date.DayOfWeek == DayOfWeek.Sunday ? 
      new ValidationResult(ErrorMessage) : ValidationResult.Success;
  }
}