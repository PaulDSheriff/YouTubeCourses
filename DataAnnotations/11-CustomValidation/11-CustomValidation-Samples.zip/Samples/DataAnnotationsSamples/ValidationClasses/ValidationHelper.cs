﻿using System.ComponentModel.DataAnnotations;

namespace Common.Library;

public static class ValidationHelper
{
  #region Validate<T> Method
  /// <summary>
  /// Call this method to validate any entity class with Data Annotations
  /// </summary>
  /// <param name="entity">The entity to validate</param>
  /// <returns>Zero or more ValidationResult objects</returns>
  public static List<ValidationResult> Validate<T>(T entity) where T : class
  {
    List<ValidationResult> ret = new();

    // Create instance of ValidationContext object
    ValidationContext context = new(entity);

    // Call TryValidateObject() method
    Validator.TryValidateObject(entity, context, ret, true);

    return ret;
  }
  #endregion

  #region ValidateToValidationMessage Method
  /// <summary>
  /// Convert a List<ValidationResult> objects into a List<ValidateMessage>. This is typically used when you with to perform data binding on both the property name in error and the validation message.
  /// </summary>
  /// <param name="results">A collection of ValidationResult objects</param>
  /// <returns>A Dictionary with the validation errors</returns>
  public static List<ValidationMessage> ValidateToValidationMessage<T>(T entity) where T : class
  {
    List<ValidationMessage> ret = new();

    // Validate Entity
    List<ValidationResult> results = Validate(entity);

    // See if any validation results returned
    if (results.Count != 0) {
      // Iterate over validation results
      foreach (ValidationResult item in results) {
        string propName = "UnknownProperty";
        // See if there is a property name
        if (item.MemberNames.Any()) {
          propName = item.MemberNames.ToArray()[0];
        }
        // Create a new ValidationMessage object and add to return results
        ret.Add(new() {
          PropertyName = propName,
          ErrorMessage = item.ErrorMessage ?? "Unknown Validation Error"
        });
      }
    }

    return ret;
  }
  #endregion

  #region ValidateToDictionary Method
  /// <summary>
  /// Convert a List<ValidationResult> objects into a dictionary. This is typically used in Web API applications where you need to return the collection of validation errors in a 400 Bad Request.
  /// </summary>
  /// <param name="results">A collection of ValidationResult objects</param>
  /// <returns>A Dictionary with the validation errors</returns>
  public static Dictionary<string, string[]> ValidateToDictionary<T>(T entity) where T : class
  {
    Dictionary<string, string[]> ret = new();

    // Validate Entity
    List<ValidationResult> results = Validate(entity);

    // See if any validation results returned
    if (results.Count != 0) {
      // Iterate over validation results
      foreach (ValidationResult item in results) {
        string propName = "UnknownProperty";
        // See if there is a property name
        if (item.MemberNames.Any()) {
          propName = item.MemberNames.ToArray()[0];
        }
        // Create a new dictionary object and add to return results
        ret.Add(propName, new string[] {
          item.ErrorMessage ?? "Unknown Validation Error"
        });
      }
    }

    return ret;
  }
  #endregion
}
