﻿using Common.Library;
using System.ComponentModel.DataAnnotations;

namespace DataAnnotationsSamples;

public class Customer
{
  [Required]
  [Display(Name = "Next Billing Date")]
  [CustomValidation(typeof(WeekdayOnlyValidator), nameof(WeekdayOnlyValidator.Validate))]
  public DateTime NextBillingDate { get; set; }
}
