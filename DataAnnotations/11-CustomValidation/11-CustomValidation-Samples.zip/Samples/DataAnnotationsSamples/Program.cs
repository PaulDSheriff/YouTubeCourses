﻿using Common.Library;
using DataAnnotationsSamples;
using System.ComponentModel.DataAnnotations;

List<ValidationResult> msgs;

Customer entity = new() {
  NextBillingDate = DateTime.Parse("1/14/2024")
};

msgs = ValidationHelper.Validate(entity);

if (msgs.Count > 0) {
  // Display Failed Validation Messages
  foreach (var item in msgs) {
    Console.WriteLine(item);
  }

  // Display Total Count
  Console.WriteLine();
  Console.WriteLine($"Total Validations Failed: {msgs.Count}");
}
else {
  Console.WriteLine();
  Console.WriteLine("Entity is Valid");
}