﻿using System.ComponentModel.DataAnnotations;

namespace Common.Library;

public static class ValidationHelper
{
  /// <summary>
  /// Call this method to validate any entity class with Data Annotations
  /// </summary>
  /// <param name="entity">The entity to validate</param>
  /// <returns>Zero or more ValidationResult objects</returns>
  public static List<ValidationResult> Validate<T>(T entity) where T : class
  {
    List<ValidationResult> ret = new();

    // Create instance of ValidationContext object
    ValidationContext context = new(entity);

    // Call TryValidateObject() method
    Validator.TryValidateObject(entity, context, ret, true);

    return ret;
  }
}
