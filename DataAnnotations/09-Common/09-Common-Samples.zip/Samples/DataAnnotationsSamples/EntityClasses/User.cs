﻿using System.ComponentModel.DataAnnotations;

namespace DataAnnotationsSamples;

public partial class User
{
  public int UserId { get; set; }
  [Display(Name = "Login Id")]
  public string LoginId { get; set; } = string.Empty;
  public string Password { get; set; } = string.Empty;
  public string ConfirmPassword { get; set; } = string.Empty;
  
  [Display(Name = "Email Address")]
  [EmailAddress]
  public string EmailAddress { get; set; } = string.Empty;
  
  [Display(Name = "Phone Number")]
  [Phone]
  public string Phone { get; set; } = string.Empty;
}
