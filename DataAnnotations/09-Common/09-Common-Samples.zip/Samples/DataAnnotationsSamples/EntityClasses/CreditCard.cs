﻿using System.ComponentModel.DataAnnotations;

namespace DataAnnotationsSamples;

public class CreditCard
{
  [Required]
  [Display(Name = "Credit Card Type")]
  public string CardType { get; set; } = string.Empty;
  [Required]
  [Display(Name = "Name on Card")]
  public string NameOnCard { get; set; } = string.Empty;
  [CreditCard]
  [Display(Name = "Credit Card Number")]
  public string CardNumber { get; set; } = string.Empty;
  [Required]
  [Display(Name = "Security Code")]
  public string SecurityCode { get; set; } = string.Empty;
  [Range(1, 12)]
  [Display(Name = "Expiration Month")]
  public int ExpMonth { get; set; } = 1;
  [Range(2024, 2030)]
  [Display(Name = "Expiration Year")]
  public int ExpYear { get; set; } = DateTime.Now.Year;
  [Required]
  [Display(Name = "Card Billing Postal Code")]
  public string BillingPostalCode { get; set; } = string.Empty;
}
