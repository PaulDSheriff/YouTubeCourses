﻿using Common.Library;
using DataAnnotationsSamples;
using System.ComponentModel.DataAnnotations;

List<ValidationResult> msgs;

CreditCard entity = new() {
  CardType = "Visa",
  CardNumber = "12 13 123 1234",
  NameOnCard = "Joe Smith",
  BillingPostalCode = "99999",
  ExpMonth = 01,
  ExpYear = 2026,
  SecurityCode = "000"
};


msgs = ValidationHelper.Validate(entity);

if (msgs.Count > 0) {
  // Display Failed Validation Messages
  foreach (var item in msgs) {
    Console.WriteLine(item);
  }

  // Display Total Count
  Console.WriteLine();
  Console.WriteLine($"Total Validations Failed: {msgs.Count}");
}
else {
  Console.WriteLine();
  Console.WriteLine("Entity is Valid");
}