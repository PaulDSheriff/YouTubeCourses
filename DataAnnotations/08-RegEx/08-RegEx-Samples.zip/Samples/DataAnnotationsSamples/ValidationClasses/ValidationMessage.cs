﻿namespace Common.Library;

public class ValidationMessage
{
  public string PropertyName { get; set; } = string.Empty;

  public string ErrorMessage { get; set; } = string.Empty;

  public override string ToString()
  {
    return $"{ErrorMessage}";
  }
}
