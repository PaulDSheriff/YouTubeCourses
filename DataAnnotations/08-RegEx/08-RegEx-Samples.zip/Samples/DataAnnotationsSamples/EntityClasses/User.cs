﻿using System.ComponentModel.DataAnnotations;

namespace DataAnnotationsSamples;

public partial class User
{
  public int UserId { get; set; }
  [Display(Name = "Login Id")]
  public string LoginId { get; set; } = string.Empty;
  public string Password { get; set; } = string.Empty;
  public string ConfirmPassword { get; set; } = string.Empty;
  
  [Display(Name = "Email Address")]
  [RegularExpression("^\\w+@[a-zA-Z_]+?\\.[a-zA-Z]{2,3}$", 
    ErrorMessage = "The email address entered is not valid.")]
  public string EmailAddress { get; set; } = string.Empty;
  
  [Display(Name = "Phone Number")]
  [RegularExpression("((\\(\\d{3}\\) ?)|(\\d{3}-))?\\d{3}-\\d { 4}",
    ErrorMessage = "The phone number entered is not valid. Please use the format (nnn) nnn-nnnn")]
  public string Phone { get; set; } = string.Empty;
}
