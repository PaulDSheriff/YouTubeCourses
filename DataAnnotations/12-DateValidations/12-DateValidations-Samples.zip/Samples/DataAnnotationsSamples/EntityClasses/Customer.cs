﻿using Common.Library;
using System.ComponentModel.DataAnnotations;

namespace DataAnnotationsSamples;

public class Customer
{
  [Required]
  [Display(Name = "Next Billing Date")]
  [CustomValidation(typeof(WeekdayOnlyValidator), nameof(WeekdayOnlyValidator.Validate), ErrorMessage = "{0} Must Be a Work Day.")]
  [DateMaximum("12/31/2029")]
  public DateTime NextBillingDate { get; set; }
}
