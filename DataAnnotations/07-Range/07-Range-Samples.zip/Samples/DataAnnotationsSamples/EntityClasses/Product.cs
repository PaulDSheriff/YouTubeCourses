﻿using System.ComponentModel.DataAnnotations;

namespace DataAnnotationsSamples;

public partial class Product
{
  public int ProductID { get; set; }

  [Display(Name = "Product Name")]
  [Required]
  [StringLength(50, MinimumLength = 4, ErrorMessage = "{0} Can Only Have Between {2} and {1} Characters.")]
  public string Name { get; set; } = string.Empty;

  [Display(Name = "Product Number")]
  [Required(ErrorMessage = "{0} Must Be Filled In.")]
  [MaxLength(25)]
  public string ProductNumber { get; set; } = string.Empty;

  [Required(ErrorMessage = "{0} Must Be Filled In.")]
  [Display(Name = "Color")]
  [MinLength(3, ErrorMessage = "{0} Must Have {1} Characters or More.")]
  [MaxLength(15)]
  public string Color { get; set; } = string.Empty;

  [Display(Name = "Standard Cost")]
  [Range(0.01, 9999)]
  public decimal StandardCost { get; set; }
  [Display(Name = "List Price")]
  [Range(0.01, 9999, ErrorMessage = "{0} must be between {1:c} and {2:c}")]
  public decimal ListPrice { get; set; }
  [Display(Name = "Selling Start Date")]
  [Range(typeof(DateTime), "1/1/2000", "12/31/2030", ErrorMessage = "{0} must be between {1:d} and {2:d}")]
  public DateTime SellStartDate { get; set; }
  [Display(Name = "Selling End Date")]
  [Range(typeof(DateTime), "1/1/2000", "12/31/2030", ErrorMessage = "{0} must be between {1:d} and {2:d}")]
  public DateTime? SellEndDate { get; set; }

  [Display(Name = "Discontinued Date")]
  public DateTime? DiscontinuedDate { get; set; }

  public override string ToString()
  {
    return $"{Name} ({ProductID})";
  }
}
