﻿using Common.Library;
using DataAnnotationsSamples;
using System.ComponentModel.DataAnnotations;

List<ValidationResult> msgs;

Product entity = new() {
  ProductID = 1,
  Name = "A New Product",
  ProductNumber = "NEW-001",
  Color = "Red",
  StandardCost = -1,
  ListPrice = 10,
  SellStartDate = Convert.ToDateTime("1/1/1999"),
  SellEndDate = Convert.ToDateTime("1/1/2031"),
  DiscontinuedDate = DateTime.Now
};

msgs = ValidationHelper.Validate(entity);

if (msgs.Count > 0) {
  // Display Failed Validation Messages
  foreach (var item in msgs) {
    Console.WriteLine(item);
  }

  // Display Total Count
  Console.WriteLine();
  Console.WriteLine($"Total Validations Failed: {msgs.Count}");
}
else {
  Console.WriteLine();
  Console.WriteLine("Entity is Valid");
}