﻿using Common.Library;
using DataAnnotationsSamples;
using System.ComponentModel.DataAnnotations;

List<ValidationResult> msgs;

User entity = new() {
  UserId = 1,
  LoginId = "JoeSmith",
  Password = "Joe!Smith@2024",
  ConfirmPassword = "Joesmith2024",
  EmailAddress = "john@smith.com",
  Phone = "(615) 111-1111"
};


msgs = ValidationHelper.Validate(entity);

if (msgs.Count > 0) {
  // Display Failed Validation Messages
  foreach (var item in msgs) {
    Console.WriteLine(item);
  }

  // Display Total Count
  Console.WriteLine();
  Console.WriteLine($"Total Validations Failed: {msgs.Count}");
}
else {
  Console.WriteLine();
  Console.WriteLine("Entity is Valid");
}