﻿using Common.Library;
using DataAnnotationsSamples;
using System.ComponentModel.DataAnnotations;

List<ValidationResult> msgs;

Product entity = new() {
  ProductID = 1,
  Name = "A New Product",
  ProductNumber = "PROD001",
  ProductUrl = "http://www.advworks.com",
  Color = "Red",
  StandardCost = 5,
  ListPrice = 1,
  SellStartDate = DateTime.Today,
  SellEndDate = DateTime.Today.AddDays(1),
  DiscontinuedDate = DateTime.Today
};

msgs = ValidationHelper.Validate(entity);

if (msgs.Count > 0) {
  // Display Failed Validation Messages
  foreach (var item in msgs) {
    Console.WriteLine(item);
  }

  // Display Total Count
  Console.WriteLine();
  Console.WriteLine($"Total Validations Failed: {msgs.Count}");
}
else {
  Console.WriteLine();
  Console.WriteLine("Entity is Valid");
}