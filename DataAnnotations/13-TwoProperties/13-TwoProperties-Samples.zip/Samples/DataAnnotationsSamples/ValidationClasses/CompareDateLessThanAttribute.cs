﻿using System.ComponentModel.DataAnnotations;
using System.Reflection;

namespace DataAnnotationsSamples;

public class CompareDateLessThanAttribute : ValidationAttribute
{
  public CompareDateLessThanAttribute(string propToCompare)
  {
    _propToCompare = propToCompare;
  }

  private readonly string _propToCompare;

  protected override ValidationResult? IsValid(object? value, ValidationContext vc)
  {
    if (value != null) {
      // Get value entered
      DateTime currentValue = (DateTime)value;
      // Get PropertyInfo for comparison property
      PropertyInfo? pinfo = vc.ObjectType.GetProperty(_propToCompare);
      // Get the value to ensure it is a valid date and not null
      object? compare = pinfo?.GetValue(vc.ObjectInstance, null);
      // Ensure the comparison property value is not null
      if (compare != null) {
        // Perform the comparison
        if (currentValue > (DateTime)compare) {
          return new ValidationResult(ErrorMessage, new[] { vc.MemberName ?? "UnknownProperty" });
        }
      }
    }

    return ValidationResult.Success;
  }
}
