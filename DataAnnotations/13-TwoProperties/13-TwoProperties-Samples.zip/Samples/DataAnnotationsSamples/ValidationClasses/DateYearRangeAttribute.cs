﻿using System.ComponentModel.DataAnnotations;

namespace DataAnnotationsSamples;

public class DateYearRangeAttribute : ValidationAttribute
{
  public DateYearRangeAttribute(int yearsPrior, int yearsAfter)
  {
    _minDate = DateTime.Now.AddYears(yearsPrior);
    _maxDate = DateTime.Now.AddYears(yearsAfter);
  }

  private readonly DateTime _minDate;
  private readonly DateTime _maxDate;

  protected override ValidationResult? IsValid(object? value, ValidationContext vc)
  {
    if (value != null) {
      // Get the value entered
      var dateEntered = (DateTime)value;

      // Get display name for validation message
      string displayName = vc.DisplayName;

      // Is date entered within the date range
      if (dateEntered < _minDate ||
          dateEntered > _maxDate) {
        // Check if ErrorMessage is filled in
        if (string.IsNullOrEmpty(ErrorMessage)) {
          ErrorMessage = $"{displayName} must be between '{_minDate:MM/dd/yyyy}' and '{_maxDate:MM/dd/yyyy}'.";
        }

        return new ValidationResult(ErrorMessage, new[] { vc.MemberName ?? "UnknownProperty" });
      }
    }

    return ValidationResult.Success;
  }
}