﻿using System.ComponentModel.DataAnnotations;

namespace DataAnnotationsSamples;

public partial class Product
{
  public int ProductID { get; set; }

  [Display(Name = "Product Name")]
  [Required]
  public string Name { get; set; } = string.Empty;
  [Display(Name = "Product Number")]
  [Required(ErrorMessage = "{0} Must Be Filled In.")]
  public string ProductNumber { get; set; } = string.Empty;
  [Required(ErrorMessage = "{0} Must Be Filled In.")]
  [Display(Name = "Color")]
  public string Color { get; set; } = string.Empty;
  [Display(Name = "Standard Cost")]
  public decimal StandardCost { get; set; }
  [Display(Name = "List Price")]
  public decimal ListPrice { get; set; }
  [Display(Name = "Selling Start Date")]
  public DateTime SellStartDate { get; set; }
  [Display(Name = "Selling End Date")]
  public DateTime? SellEndDate { get; set; }
  [Display(Name = "Discontinued Date")]
  public DateTime? DiscontinuedDate { get; set; }

  public override string ToString()
  {
    return $"{Name} ({ProductID})";
  }
}
