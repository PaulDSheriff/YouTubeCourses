To run this application
-------------------------
Open a terminal window
If the "node_modules" folder is not present, type: npm install
type: npm start