let fs = require('fs');

const FILE_NAME = './assets/people.json';

let peopleRepo = {
  get: function (resolve, reject) {
    fs.readFile(FILE_NAME, function (err, data) {
      if (err) {
        reject(err);
      }
      else {
        resolve(JSON.parse(data));
      }
    });
  },
  getById: function (id, resolve, reject) {
    fs.readFile(FILE_NAME, function (err, data) {
      if (err) {
        reject(err);
      }
      else {
        let resp = JSON.parse(data).find(row => row.personId == id);
        resolve(resp);
      }
    });
  },
  insert: function (newData, resolve, reject) {
    fs.readFile(FILE_NAME, function (err, data) {
      if (err) {
        reject(err);
      }
      else {
        let resp = JSON.parse(data);

        // Get array of personId values
        let ids = resp.map(row => { return row.personId; });
        // Get max id and add one
        let maxId = Math.max(...ids) + 1;
        // Assign new personId
        newData.personId = maxId;
        // Add new person to array
        resp.push(newData);
        
        fs.writeFile(FILE_NAME, JSON.stringify(resp, null, 2), function (err) {
          if (err) {
            reject(err);
          }
          else {
            resolve(newData);
          }
        });
      }
    });
  },
  update: function (changedData, id, resolve, reject) {
    fs.readFile(FILE_NAME, function (err, data) {
      if (err) {
        reject(err);
      }
      else {
        let list = JSON.parse(data);
        let current = list.find(row => row.personId == id);
        if (current) {
          Object.assign(current, changedData);
          fs.writeFile(FILE_NAME, JSON.stringify(list, null, 2), function (err) {
            if (err) {
              reject(err);
            }
            else {
              resolve(changedData);
            }
          });
        }
      }
    });
  },
  delete: function (id, resolve, reject) {
    fs.readFile(FILE_NAME, function (err, data) {
      if (err) {
        reject(err);
      }
      else {
        let list = JSON.parse(data);
        let index = list.findIndex(row => row.personId == id);
        if (index != -1) {
          list.splice(index, 1);
          fs.writeFile(FILE_NAME, JSON.stringify(list, null, 2), function (err) {
            if (err) {
              reject(err);
            }
            else {
              // Deleted the data
              resolve(true);
            }
          });
        }
        else {
          // Did not find the id to delete
          resolve(false);
        }
      }
    });
  }
};

module.exports = peopleRepo;