// *****************************************
// Global Variable for Common Functions
// *****************************************
let common = (function () {
  // ******************************
  // Private Functions
  // ******************************
  async function processResponseObject(response) {
    let text = "";
    let data = {};
    // Create custom response object
    let ret = {
      "ok": response.ok,
      "status": response.status,
      "statusText": response.statusText,
      "url": response.url,
      "message": ""
    };

    try {
      // Get text first
      text = await response.text();
      // Attempt to convert to JSON
      data = JSON.parse(text);
      // Return JSON data
      ret.message = data.message;
      ret.data = data.data;
    }
    catch {
      // Return the text
      ret.data = text;
    }

    return ret;
  }

  function handleNetworkError(error) {
    let msg = "A network error has occurred. Check the apiUrl property to ensure it is set correctly.";

    console.error(error + " - " + msg);

    return msg;
  }

  function handleError(vm) {
    let msg = "";

    switch (vm.status) {
      case 400:
        msg = JSON.stringify(vm.data);
        break;
      case 404:
        if (vm.data) {
          msg = vm.data;
        }
        else {
          msg = `${vm.statusText} - ${vm.apiUrl}`;
        }
        break;
      case 500:
        msg = JSON.parse(vm.data).message;
        break;
      default:
        msg = JSON.stringify(vm.data);
        break;
    }

    if (msg) {
      console.error(msg);
    }

    return msg;
  }

  //*********************************
  //* Generic Display Methods
  //*********************************
  function displayList() {
    document.getElementById("list").classList.remove('d-none');
    document.getElementById("detail").classList.add('d-none');
  }

  function displayMessage(msg) {
    if (msg) {
      document.getElementById("message").textContent = msg;
      document.getElementById("message").classList.remove('d-none');
    }
    else {
      document.getElementById("message").classList.add('d-none');
    }
  }

  function displayError(msg) {
    if (msg) {
      document.getElementById("error").textContent = msg;
      document.getElementById("error").classList.remove('d-none');
    }
    else {
      document.getElementById("error").classList.add('d-none');
    }
  }

  function displayButtons() {
    document.getElementById("saveButton").classList.remove('d-none');
    document.getElementById("cancelButton").classList.remove('d-none');
  }

  function displayDetail() {
    document.getElementById("list").classList.add('d-none');
    document.getElementById("detail").classList.remove('d-none');
  }

  function hideButtons() {
    document.getElementById("saveButton").classList.add('d-none');
    document.getElementById("cancelButton").classList.add('d-none');
  }

  // ******************************
  // Public Functions
  // ******************************
  return {
    "processResponseObject": processResponseObject,
    "handleNetworkError": handleNetworkError,
    "handleError": handleError,
    "displayList": displayList,
    "displayMessage": displayMessage,
    "displayError": displayError,
    "displayButtons": displayButtons,
    "displayDetail": displayDetail,
    "hideButtons": hideButtons
  };
})();
