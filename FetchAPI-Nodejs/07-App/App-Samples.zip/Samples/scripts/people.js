// ********************************
// Global Variable for people Page
// ********************************
let peopleController = (function () {
  // ******************************
  // Private Variables
  // ******************************
  let vm = {
    "list": [],
    "entity": {},
    "data": null,
    "mode": "list",
    "apiUrl": "http://localhost:5000/api/people",
    "ok": false,
    "status": 0,
    "statusText": "",
    "message": "",
    "lastResponse": {}
  }

  // ******************************
  // Private Functions 
  // ******************************
  function get() {
    vm.mode = "list";
    vm.entity = {};

    fetch(vm.apiUrl)
      .then(response => processResponseObject(response))
      .then(data => {
        // Check if response was successful
        if (vm.ok) {
          // Assign data to view model's list property
          vm.list = data.data;
          // Use template to build HTML table
          buildList(vm);
        }
        else {
          common.displayError(common.handleError(vm));
        }
      })
      .catch(error => common.displayError(common.handleNetworkError(error)));
  }

  function getEntity(id) {
    vm.mode = "edit";
    vm.list = [];

    fetch(`${vm.apiUrl}/${id}`)
      .then(response => processResponseObject(response))
      .then(data => {
        // Check if response was successful
        if (vm.ok) {
          // Assign data to view model's entity property
          vm.entity = data.data;

          // Display entity
          setInput();

          // Unhide Save/Cancel buttons
          common.displayButtons();

          // Unhide detail area
          common.displayDetail();
        }
        else {
          common.displayError(common.handleError(vm));
        }
      })
      .catch(error => common.displayError(common.handleNetworkError(error)));
  }

  function insertEntity() {
    setEntityFromInput();

    let options = {
      method: 'POST',
      body: JSON.stringify(vm.entity),
      headers: {
        'Content-Type': 'application/json'
      }
    };

    fetch(vm.apiUrl, options)
      .then(response => processResponseObject(response))
      .then(data => {
        if (vm.ok) {
          // Hide buttons while 'success message' is displayed
          common.hideButtons();

          // Display a success message
          common.displayMessage(vm.message);

          // Redisplay entity returned from Web API
          setInput();

          // Clear messages
          clearMessages(true);
        }
        else {
          common.displayError(common.handleError(vm));
        }
      })
      .catch(error => common.displayError(common.handleNetworkError(error)));
  }

  function updateEntity() {
    setEntityFromInput();

    let options = {
      method: 'PUT',
      body: JSON.stringify(vm.entity),
      headers: {
        'Content-Type': 'application/json'
      }
    };

    fetch(`${vm.apiUrl}/${vm.entity.personId}`, options)
      .then(response => processResponseObject(response))
      .then(data => {
        if (vm.ok) {
          // Hide buttons while 'success message' is displayed
          common.hideButtons();

          // Display a success message
          common.displayMessage(vm.message);

          // Redisplay entity returned from Web API
          setInput();

          // Clear messages
          clearMessages(true);
        }
        else {
          common.displayError(common.handleError(vm));
        }
      })
      .catch(error => common.displayError(common.handleNetworkError(error)));
  }

  function deleteEntity(id) {
    if (confirm(`Delete Person ${id}?`)) {
      let options = {
        method: 'DELETE'
      };

      fetch(`${vm.apiUrl}/${id}`, options)
        .then(response => processResponseObject(response))
        .then(data => {
          // Check if response was successful
          if (vm.ok) {
            // Display success message
            common.displayMessage("Person Deleted.");

            // Redisplay all data
            get();

            // Clear messages
            clearMessages(false);
          }
          else {
            common.displayError(common.handleError(vm));
          }
        })
        .catch(error => common.displayError(common.handleNetworkError(error)));
    }
  }

  async function processResponseObject(response) {
    let resp = await common.processResponseObject(response);

    vm.ok = resp.ok;
    vm.status = resp.status;
    vm.statusText = resp.statusText;
    vm.message = resp.message;
    vm.data = resp.data;
    vm.lastResponse = resp;

    return vm;
  }

  function buildList(vm) {
    // Get HTML template from <script> tag
    let template = document.getElementById("listTmpl").text;

    // Call Mustache passing in the template and
    // the object with the collection of data
    let html = Mustache.render(template, vm);

    // Insert the rendered HTML into the DOM
    document.getElementById("people").getElementsByTagName('tbody')[0].innerHTML = html;

    // Display HTML table and hide <form> area
    common.displayList();
  }

  function setInput() {
    document.getElementById("personId").value = vm.entity.personId;
    document.getElementById("firstName").value = vm.entity.firstName;
    document.getElementById("lastName").value = vm.entity.lastName;
    document.getElementById("emailAddress").value = vm.entity.emailAddress;
    document.getElementById("startDate").value = vm.entity.startDate;
  }

  function setEntityFromInput() {
    vm.entity.personId = Number.parseInt(document.getElementById("personId").value);
    vm.entity.firstName = document.getElementById("firstName").value
    vm.entity.lastName = document.getElementById("lastName").value;
    vm.entity.emailAddress = document.getElementById("emailAddress").value;
    vm.entity.startDate = document.getElementById("startDate").value;
  }

  function cancel() {
    // Hide detail area
    document.getElementById("detail").classList.add('d-none');
    // Clear any messages
    common.displayMessage("");
    // Display all data
    get();
  }

  function clearInput() {
    vm.entity.personId = 0;
    vm.entity.firstName = "";
    vm.entity.lastName = "";
    vm.entity.emailAddress = "";
    vm.entity.startDate = "2024-01-01";

    setInput();
  }

  function add() {
    vm.mode = "add";

    // Display empty entity
    clearInput();

    // Make sure buttons are displayed
    common.displayButtons();

    // Unhide detail area
    common.displayDetail();
  }

  function save() {
    // Determine method to call based on the mode property
    if (vm.mode === "add") {
      insertEntity();
    } else if (vm.mode === "edit") {
      updateEntity();
    }
  }

  function clearMessages(redisplayList) {
    setTimeout(() => {
      if (redisplayList) {
        get();
      }

      // Clear message
      common.displayMessage("");
    }, 2000);
  }
  // ******************************
  // Public Functions
  // ******************************
  return {
    "get": get,
    "getEntity": getEntity,
    "cancel": cancel,
    "add": add,
    "save": save,
    "deleteEntity": deleteEntity
  };
})();
