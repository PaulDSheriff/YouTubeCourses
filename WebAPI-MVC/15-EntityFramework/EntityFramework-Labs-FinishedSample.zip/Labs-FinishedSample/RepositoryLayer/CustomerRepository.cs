using AdvWorksAPI.EntityLayer;
using AdvWorksAPI.Interfaces;
using AdvWorksAPI.Models;

namespace AdvWorksAPI.RepositoryLayer;

/// <summary>
/// This class creates some fake data for the Customer table.
/// </summary>
public class CustomerRepository : IRepository<Customer>
{
  private readonly AdvWorksLTDbContext _DbContext;

  public CustomerRepository(AdvWorksLTDbContext context)
  {
    _DbContext = context;
  }

  #region Get Method
  /// <summary>
  /// Get all Customer objects
  /// </summary>
  /// <returns>A list of Customer objects</returns>
  public List<Customer> Get()
  {
    return _DbContext.Customers.OrderBy(row => row.LastName).ToList();
  }
  #endregion

  #region Get Method
  /// <summary>
  /// Get a single Customer object
  /// </summary>
  /// <param name="id">The value to locate</param>
  /// <returns>A valid Customer object object, or null if not found</returns>
  public Customer? Get(int id) {
    return _DbContext.Customers.Where(row => row.CustomerID == id).FirstOrDefault();
  }
  #endregion
}