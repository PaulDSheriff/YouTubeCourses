using AdvWorksAPI.EntityLayer;
using AdvWorksAPI.Interfaces;
using AdvWorksAPI.Models;
using AdvWorksAPI.SearchClasses;

namespace AdvWorksAPI.RepositoryLayer;

/// <summary>
/// This class creates some fake data for the Customer table.
/// </summary>
public class CustomerRepository : IRepository<Customer, CustomerSearch>
{
  private readonly AdvWorksLTDbContext _DbContext;

  public CustomerRepository(AdvWorksLTDbContext context)
  {
    _DbContext = context;
  }

  #region Get Method
  /// <summary>
  /// Get all Customer objects
  /// </summary>
  /// <returns>A list of Customer objects</returns>
  public List<Customer> Get()
  {
    return _DbContext.Customers.OrderBy(row => row.LastName).ToList();
  }
  #endregion

  #region Get Method
  /// <summary>
  /// Get a single Customer object
  /// </summary>
  /// <param name="id">The value to locate</param>
  /// <returns>A valid Customer object object, or null if not found</returns>
  public Customer? Get(int id) {
    return _DbContext.Customers.Where(row => row.CustomerID == id).FirstOrDefault();
  }
  #endregion

  #region Search Methods
  public List<Customer> Search(CustomerSearch search)
  {
    IQueryable<Customer> query = _DbContext.Customers;

    // Add WHERE clause(s)
    query = AddWhereClause(query, search);

    // Add ORDER BY clause(s)
    query = AddOrderByClause(query, search);

    return query.ToList();
  }

  protected virtual IQueryable<Customer> AddWhereClause(IQueryable<Customer> query, CustomerSearch search)
  {
    // Perform Searching      
    if (!string.IsNullOrEmpty(search.FirstName)) {
      query = query.Where(row => row.FirstName.Contains(search.FirstName));
    }
    if (!string.IsNullOrEmpty(search.LastName)) {
      query = query.Where(row => row.LastName.Contains(search.LastName));
    }
    if (!string.IsNullOrEmpty(search.Title)) {
      // NOTE: Do NOT simplify this expression, or the query will not work.
#pragma warning disable IDE0075 // Simplify conditional expression
      // Title allows nulls, so you have to check for a null value
      query = query.Where(row => string.IsNullOrEmpty(row.Title) ? true : row.Title.StartsWith(search.Title));
#pragma warning restore IDE0075 // Simplify conditional expression
    }

    return query;
  }

  protected virtual IQueryable<Customer> AddOrderByClause(IQueryable<Customer> query, CustomerSearch search)
  {
    switch (search.OrderBy.ToLower()) {
      case "":
      case "lastname":
        query = query.OrderBy(row => row.LastName);
        break;
      case "firstname":
        query = query.OrderBy(row => row.FirstName);
        break;
      case "title":
        query = query.OrderBy(row => row.Title);
        break;
    }

    return query;
  }
  #endregion

  #region Insert Method
  public Customer Insert(Customer entity)
  {
    // Fill in required fields not passed by client
    entity.Rowguid = Guid.NewGuid();
    entity.ModifiedDate = DateTime.Now;

    // Add new entity to Customers DbSet
    _DbContext.Customers.Add(entity);

    // Save changes in database
    _DbContext.SaveChanges();

    return entity;
  }
  #endregion

  #region Update Method
  public Customer Update(Customer entity)
  {
    // Update last date updated
    entity.ModifiedDate = DateTime.Now;

    // Update entity in Customers DbSet
    _DbContext.Customers.Update(entity);

    // Save changes in database
    _DbContext.SaveChanges();

    return entity;
  }
  #endregion

  #region SetValues Method
  public Customer SetValues(Customer current, Customer changes)
  {
    // Since we don't necessarily pass in all the data,
    // overwrite the changed properties in the one
    // read from the database
    // TODO: Make this a little more bullet-proof
    current.NameStyle = changes.NameStyle;
    current.Title = string.IsNullOrWhiteSpace(changes.Title) ? current.Title : changes.Title;
    current.FirstName = string.IsNullOrWhiteSpace(changes.FirstName) ? current.FirstName : changes.FirstName;
    current.MiddleName = string.IsNullOrWhiteSpace(changes.MiddleName) ? current.MiddleName : changes.MiddleName;
    current.LastName = string.IsNullOrWhiteSpace(changes.LastName) ? current.LastName : changes.LastName;
    current.Suffix = string.IsNullOrWhiteSpace(changes.Suffix) ? current.Suffix : changes.Suffix;
    current.CompanyName = string.IsNullOrWhiteSpace(changes.CompanyName) ? current.CompanyName : changes.CompanyName;
    current.SalesPerson = string.IsNullOrWhiteSpace(changes.SalesPerson) ? current.SalesPerson : changes.SalesPerson;
    current.EmailAddress = string.IsNullOrWhiteSpace(changes.EmailAddress) ? current.EmailAddress : changes.EmailAddress;
    current.Phone = string.IsNullOrWhiteSpace(changes.Phone) ? current.Phone : changes.Phone;
    current.PasswordHash = string.IsNullOrWhiteSpace(changes.PasswordHash) ? current.PasswordHash : changes.PasswordHash;
    current.PasswordSalt = string.IsNullOrWhiteSpace(changes.PasswordSalt) ? current.PasswordSalt : changes.PasswordSalt;
    current.Rowguid = changes.Rowguid == Guid.Empty ? current.Rowguid : Guid.NewGuid();
    current.ModifiedDate = DateTime.Now;

    return current;
  }
  #endregion

  #region Delete Method
  public bool Delete(int id)
  {
    Customer? entity = _DbContext.Customers.Find(id);

    if (entity != null) {
      // Locate entity to delete in the Customers DbSet
      _DbContext.Customers.Remove(entity);

      // Save changes in database
      _DbContext.SaveChanges();

      return true;
    }
    else {
      return false;
    }
  }
  #endregion
}