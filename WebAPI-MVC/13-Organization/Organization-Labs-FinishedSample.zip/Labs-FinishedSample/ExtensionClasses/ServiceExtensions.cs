﻿using AdvWorksAPI.ConstantClasses;
using AdvWorksAPI.EntityLayer;
using AdvWorksAPI.Interfaces;
using AdvWorksAPI.RepositoryLayer;

namespace AdvWorksAPI.ExtensionClasses;

public static class ServiceExtension
{
  public static void AddRepositoryClasses(this IServiceCollection services)
  {
    // Add Repository Classes
    services.AddScoped<IRepository<Customer>, CustomerRepository>();
  }

  public static IServiceCollection ConfigureCors(this IServiceCollection services)
  {
    // Add & Configure CORS
    return services.AddCors(options =>
    {
      options.AddPolicy(AdvWorksAPIConstants.CORS_POLICY,
        builder =>
        {
          builder.WithOrigins("http://localhost:5081");
        });
    });
  }
}
