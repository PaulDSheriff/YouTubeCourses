﻿using TestAsync.RepositoryLayer;

var repo = new ProductRepository();

// *************************
// Sync Process
// *************************
//Console.WriteLine("Starting Sync Task");
//var list = repo.Get();
//Console.WriteLine("Complete: " + list.Count);
//Console.WriteLine("After Sync Task");

// *************************
// Async Process
// *************************
Console.WriteLine("Starting Async Task");
var task = repo.GetAsync();

while (!task.IsCompleted) {
  Console.WriteLine("Doing Other Stuff...");
}
if (task.IsCompleted) {
  Console.WriteLine("Getting the List");
  var list = task.Result.ToList();
  Console.WriteLine("Complete: " + list.Count);
}
Console.WriteLine("After Async Task");
