using AdvWorksAPI.EntityLayer;
using AdvWorksAPI.Interfaces;
using AdvWorksAPI.RepositoryLayer;

// **********************************************
// Create a WebApplicationBuilder object
// to configure the how the ASP.NET service runs
// **********************************************
var builder = WebApplication.CreateBuilder(args);

// **********************************************
// Add and Configure Services
// **********************************************
builder.Services.AddSingleton<AdvWorksAPIDefaults, AdvWorksAPIDefaults>();
builder.Services.AddScoped<IRepository<Customer>, CustomerRepository>();

// Configure Open API (Swagger)
// More Info: https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

// **********************************************
// After adding and configuring services
// Create an instance of a WebApplication object
// **********************************************
var app = builder.Build();

// **********************************************
// Configure the HTTP Request Pipeline
// **********************************************
if (app.Environment.IsDevelopment()) {
  app.UseSwagger();
  app.UseSwaggerUI();
}

// **********************************************
// Map Minimal API Endpoints
// **********************************************
app.MapGet("/api/GetSettings", (AdvWorksAPIDefaults settings) => Results.Ok(settings)).WithTags("Settings");
app.MapGet("/api/GetSettingsAgain", (AdvWorksAPIDefaults settings) => Results.Ok(settings)).WithTags("Settings");

app.MapGet("/api/Customer", (IRepository<Customer> repo) =>
{
  List<Customer> list;

  // Get all customers
  list = repo.Get();

  // Simulate not getting any data
  //list.Clear();

  if (list == null || list.Count == 0) {
    return Results.NotFound("No Customers Found.");
  }
  else {
    return Results.Ok(list);
  }
}).WithTags("Customer").Produces(200)
.Produces<List<Customer>>()
.Produces(404);


app.MapGet("/api/Customer/{id:int}", (int id, IRepository<Customer> repo) =>
{
  Customer? entity;

  // Attempt to get a single customer
  entity = repo.Get(id);
  if (entity == null) {
    return Results.NotFound($"Customer with CustomerID = '{id}' was not found.");
  }
  else {
    return Results.Ok(entity);
  }
}).WithTags("Customer").Produces(200)
.Produces<List<Customer>>()
.Produces(404);

var summaries = new[]
{
    "Freezing", "Bracing", "Chilly", "Cool", "Mild", "Warm", "Balmy", "Hot", "Sweltering", "Scorching"
};

app.MapGet("/weatherforecast", () =>
{
  var forecast = Enumerable.Range(1, 5).Select(index =>
      new WeatherForecast
      (
          DateTime.Now.AddDays(index),
          Random.Shared.Next(-20, 55),
          summaries[Random.Shared.Next(summaries.Length)]
      ))
      .ToArray();
  return forecast;
})
.WithName("GetWeatherForecast");

// **********************************************
// Run the Application
// **********************************************
app.Run();

// **********************************************
// Any Additional Data Below Here
// **********************************************
internal record WeatherForecast(DateTime Date, int TemperatureC, string? Summary)
{
  public int TemperatureF => 32 + (int)(TemperatureC / 0.5556);
}