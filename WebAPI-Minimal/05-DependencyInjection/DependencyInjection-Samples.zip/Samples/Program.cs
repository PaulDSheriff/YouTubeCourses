// **********************************************
// Create a WebApplicationBuilder object
// to configure the how the ASP.NET service runs
// **********************************************
using AdvWorksAPI.EntityLayer;
using AdvWorksAPI.Interfaces;
using AdvWorksAPI.RepositoryLayer;

var builder = WebApplication.CreateBuilder(args);

// **********************************************
// Add and Configure Services
// **********************************************
builder.Services.AddSingleton<AdvWorksAPIDefaults, AdvWorksAPIDefaults>();
builder.Services.AddScoped<IRepository<Product>, ProductRepository>();


// Configure Open API (Swagger)
// More Info: https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

// **********************************************
// After adding and configuring services
// Create an instance of a WebApplication object
// **********************************************
var app = builder.Build();

// **********************************************
// Configure the HTTP Request Pipeline
// **********************************************
if (app.Environment.IsDevelopment()) {
  app.UseSwagger();
  app.UseSwaggerUI();
}

// **********************************************
// Create Minimal API Endpoints
// **********************************************
app.MapGet("/api/HelloAll", () => "Hello Everyone").WithTags("Simple");
app.MapGet("/api/HelloWorld", () => Results.Ok("Hello World")).WithTags("Simple");
app.MapGet("/api/HelloPerson", (string name) => Results.Ok($"Hello {name}")).WithTags("Simple");

app.MapGet("/api/Settings", (AdvWorksAPIDefaults settings) => Results.Ok(settings)).WithTags("Settings");
app.MapGet("/api/Settings2", (AdvWorksAPIDefaults settings) => Results.Ok(settings)).WithTags("Settings");

app.MapGet("/api/Product/{id:int}", (int id, IRepository<Product> repo) =>
{
  Product? entity;

  entity = repo.Get(id);
  if (entity == null) {
    return Results.NotFound($"Product with ProductID = '{id}' was not found.");
  }
  else {
    return Results.Ok(entity);
  }
}).WithTags("Product")
.Produces(200)
.Produces<Product>()
.Produces(404);

app.MapGet("/api/Product", (IRepository<Product> repo) =>
{
  List<Product> list;

  // Get all products
  list = repo.Get();

  // Simulate not getting any data
  //list.Clear();

  if (list == null || list.Count == 0) {
    return Results.NotFound("No Products Found.");
  }
  else {
    return Results.Ok(list);
  }
}).WithTags("Product")
.Produces(200)
.Produces<List<Product>>()
.Produces(404);


// **********************************************
// Run the Application
// **********************************************
app.Run();