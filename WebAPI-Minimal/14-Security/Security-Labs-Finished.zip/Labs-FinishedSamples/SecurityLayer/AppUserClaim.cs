﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace AdvWorksAPI.SecurityLayer;

[Table("UserClaim", Schema = "Security")]
public partial class AppUserClaim
{
  public AppUserClaim()
  {
    ClaimId = Guid.NewGuid();
    UserId = Guid.NewGuid();
    ClaimType = string.Empty;
    ClaimValue = string.Empty;
  }

  [Required()]
  [Key()]
  public Guid ClaimId { get; set; }

  [Required()]
  public Guid UserId { get; set; }

  [Required()]
  [StringLength(100)]
  public string ClaimType { get; set; }

  [Required()]
  [StringLength(50)]
  public string ClaimValue { get; set; }
}
