﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;

namespace AdvWorksAPI.SecurityLayer;

[Table("User", Schema = "Security")]
public partial class AppUser
{
  public AppUser()
  {
    UserId = Guid.NewGuid();
    UserName = string.Empty;
    Password = string.Empty;
    IsAuthenticated = false;
  }

  [Required()]
  [Key()]
  public Guid UserId { get; set; }

  [Required()]
  [StringLength(255)]
  public string UserName { get; set; }

  [Required()]
  [StringLength(255)]
  [JsonIgnore]
  public string Password { get; set; }

  public bool IsAuthenticated { get; set; }
}
