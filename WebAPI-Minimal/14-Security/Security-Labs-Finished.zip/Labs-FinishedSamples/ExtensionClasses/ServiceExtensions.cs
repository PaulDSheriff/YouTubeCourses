﻿using System.Text;
using AdvWorksAPI.ConstantClasses;
using AdvWorksAPI.EntityLayer;
using AdvWorksAPI.Interfaces;
using AdvWorksAPI.RepositoryLayer;
using AdvWorksAPI.RouterClasses;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Http.Json;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;

namespace AdvWorksAPI.ExtensionClasses;

public static class ServiceExtension
{
  public static void AddRepositoryClasses(this IServiceCollection services)
  {
    // Add Repository Classes
    services.AddScoped<IRepository<Customer>, CustomerRepository>();
  }

  public static void AddRouterClasses(this IServiceCollection services)
  {
    // Add "Router" classes as a service
    services.AddScoped<RouterBase, ErrorRouter>();
    services.AddScoped<RouterBase, CustomerRouter>();
    services.AddScoped<RouterBase, SettingsRouter>();
    services.AddScoped<RouterBase, LogTestRouter>();
    services.AddScoped<RouterBase, SecurityTestRouter>();
  }

  public static IServiceCollection ConfigureCors(this IServiceCollection services)
  {
    // Add CORS
    return services.AddCors(options =>
    {
      options.AddPolicy(AdvWorksAPIConstants.CORS_POLICY,
        builder =>
        {
          builder.WithOrigins("http://localhost:5081");
        });
    });
  }

  public static IServiceCollection ConfigureJsonOptions(this IServiceCollection services)
  {
    // Add CORS
    return services.Configure<JsonOptions>(options =>
    {
      //// Set property names to PascalCase
      //options.SerializerOptions.PropertyNamingPolicy = null;
      //// Ignore "readonly" fields
      //options.SerializerOptions.IgnoreReadOnlyProperties = true;
    });
  }

  public static AuthenticationBuilder ConfigureJwtAuthentication(this IServiceCollection services, AdvWorksAPIDefaults settings)
  {
    // Add Authentication to Services
    return services.AddAuthentication(options =>
    {
      options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
      options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
      options.DefaultScheme = JwtBearerDefaults.AuthenticationScheme;      
    }).AddJwtBearer(jwtOptions =>
    {
      jwtOptions.TokenValidationParameters =
        new TokenValidationParameters
        {
          ValidIssuer = settings.JWTSettings.Issuer,
          ValidAudience = settings.JWTSettings.Audience,
          IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(settings.JWTSettings.Key)),
          ValidateIssuer = true,
          ValidateAudience = true,
          ValidateLifetime = true,
          ValidateIssuerSigningKey = true,
          ClockSkew = TimeSpan.FromMinutes(settings.JWTSettings.MinutesToExpiration)
        };
    });
  }

  public static IServiceCollection ConfigureJwtAuthorization(this IServiceCollection services)
  {
    return services.AddAuthorization(options =>
    {
      options.AddPolicy("GetCustomersClaim", policy => policy.RequireClaim("GetCustomers"));
      options.AddPolicy("GetACustomerClaim", policy => policy.RequireClaim("GetACustomer"));
      options.AddPolicy("SearchClaim", policy => policy.RequireClaim("Search"));
      options.AddPolicy("AddCustomerClaim", policy => policy.RequireClaim("AddCustomer"));
      options.AddPolicy("UpdateCustomerClaim", policy => policy.RequireClaim("UpdateCustomer"));
    });
  }

  public static IServiceCollection ConfigureOpenAPI(this IServiceCollection services)
  {
    // Configure Open API (Swagger)
    // More Info: https://aka.ms/aspnetcore/swashbuckle
    services.AddEndpointsApiExplorer();
    return services.AddSwaggerGen(options =>
    {
      options.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme
      {
        Scheme = "Bearer",
        BearerFormat = "JWT",
        In = ParameterLocation.Header,
        Name = "Authorization",
        Description = "Bearer Authentication with JWT Token",
        Type = SecuritySchemeType.Http
      });
      options.AddSecurityRequirement(new OpenApiSecurityRequirement
      {
        {
          new OpenApiSecurityScheme
          {
            Reference = new OpenApiReference
            {
              Id = "Bearer",
              Type = ReferenceType.SecurityScheme
            }
          },
          new List<string>()
        }
      });
    });
  }
}
