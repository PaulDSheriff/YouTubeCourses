#nullable disable

using TestAsync.EntityLayer;

namespace TestAsync.RepositoryLayer;

/// <summary>
/// Show Sync/Async Sample
/// </summary>
public class ProductRepository
{
  #region GetAsync Method
  public async Task<IEnumerable<Product>> GetAsync()
  {
    return await Task.Run(() => Get());
  }
  #endregion

  #region Get Method
  public List<Product> Get()
  {
    // Simulate a long process
    Thread.Sleep(2000);

    // Return a list of products
    return new List<Product>
    {
      new Product {
         ProductID = 706,
         Name = @"HL Road Frame - Red, 58",
         ProductNumber = @"FR-R92R-58",
         Color = @"Red",
         StandardCost = 1059.3100m,
         ListPrice = 1500.0000m,
         Size = @"58",
         Weight = 1016.04m,
         ProductCategoryID = 18,
         ProductModelID = 6,
         SellStartDate = Convert.ToDateTime("6/1/1998 12:00:00 AM"),
         SellEndDate = Convert.ToDateTime("6/1/1998 12:00:00 AM"),
         DiscontinuedDate = null,
      },
      new Product {
         ProductID = 707,
         Name = @"Sport-100 Helmet, Red",
         ProductNumber = @"HL-U509-R",
         Color = @"Red",
         StandardCost = 13.0800m,
         ListPrice = 34.9900m,
         Size = null,
         Weight = null,
         ProductCategoryID = 35,
         ProductModelID = 33,
         SellStartDate = Convert.ToDateTime("7/1/2001 12:00:00 AM"),
         SellEndDate = null,
         DiscontinuedDate = null,
      },
      new Product {
         ProductID = 708,
         Name = @"Sport-100 Helmet, Black",
         ProductNumber = @"HL-U509",
         Color = @"Black",
         StandardCost = 13.0863m,
         ListPrice = 34.9900m,
         Size = null,
         Weight = null,
         ProductCategoryID = 35,
         ProductModelID = 33,
         SellStartDate = Convert.ToDateTime("7/1/2001 12:00:00 AM"),
         SellEndDate = null,
         DiscontinuedDate = null,
      },
      new Product {
         ProductID = 709,
         Name = @"Mountain Bike Socks, M",
         ProductNumber = @"SO-B909-M",
         Color = @"White",
         StandardCost = 3.3963m,
         ListPrice = 9.5000m,
         Size = @"M",
         Weight = null,
         ProductCategoryID = 27,
         ProductModelID = 18,
         SellStartDate = Convert.ToDateTime("7/1/2001 12:00:00 AM"),
         SellEndDate = Convert.ToDateTime("6/30/2002 12:00:00 AM"),
         DiscontinuedDate = null,
      }
    };
  }
  #endregion
}