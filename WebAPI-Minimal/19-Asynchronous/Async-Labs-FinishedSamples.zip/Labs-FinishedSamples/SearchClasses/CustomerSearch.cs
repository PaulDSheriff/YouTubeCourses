﻿using AdvWorksAPI.BaseClasses;

namespace AdvWorksAPI.SearchClasses;

public class CustomerSearch : SearchBase
{
  public CustomerSearch()
  {
    OrderBy = "LastName";
    FirstName = string.Empty;
    LastName = string.Empty;
    Title = string.Empty;
  }

  public string? FirstName { get; set; }
  public string? LastName { get; set; }
  public string? Title { get; set; }

  /// <summary>
  /// The following allows us to bind the CustomerSearch on the query line when using Minimal APIs
  /// </summary>
  /// <param name="httpContext"></param>
  /// <returns></returns>
  public static ValueTask<CustomerSearch> BindAsync(HttpContext httpContext)
  {
    ValueTask<CustomerSearch> ret;

    ret = ValueTask.FromResult<CustomerSearch>(
      new CustomerSearch {
        FirstName = httpContext.Request.Query["firstname"].ToString(),
        LastName = httpContext.Request.Query["lastname"].ToString(),
        Title = httpContext.Request.Query["title"].ToString(),
      });

    return ret;
  }
}
