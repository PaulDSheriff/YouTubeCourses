﻿using AdvWorksAPI.BaseClasses;
using AdvWorksAPI.EntityLayer;
using AdvWorksAPI.Interfaces;
using AdvWorksAPI.SearchClasses;

namespace AdvWorksAPI.RouterClasses;

public class CustomerAsyncRouter : RouterBase
{
  private readonly AdvWorksAPIDefaults _Settings;

  public CustomerAsyncRouter(ILogger<CustomerRouter> logger, AdvWorksAPIDefaults settings) : base(logger)
  {
    UrlFragment = "api/CustomerAsync";
    TagName = "CustomerAsync";
    _Settings = settings;
  }

  /// <summary>
  /// Add asynchronous routes
  /// </summary>
  /// <param name="app">A WebApplication object</param>
  public override void AddRoutes(WebApplication app)
  {
    app.MapGet($"/{UrlFragment}", async (IRepository<Customer, CustomerSearch> repo) => await GetAsync(repo))
       .WithTags(TagName)
       .Produces(200)
       .Produces<List<Customer>>()
       .Produces(404)
       .Produces(500);

    app.MapGet($"/{UrlFragment}/{{id:int}}", async (int id, IRepository<Customer, CustomerSearch> repo) => await GetAsync(id, repo))
     .WithTags(TagName)
     .Produces(200)
     .Produces<Customer>()
     .Produces(404);

    app.MapGet($"/{UrlFragment}/Search", async (CustomerSearch search, IRepository<Customer, CustomerSearch> repo) => await SearchAsync(search, repo))
     .WithTags(TagName)
     .Produces(200)
     .Produces<List<Customer>>()
     .Produces(404);
  }

  protected virtual async Task<IResult> GetAsync(IRepository<Customer, CustomerSearch> repo)
  {
    IResult ret;
    List<Customer> list;
    InfoMessage = "No Customers Found.";

    try {
      list = await repo.GetAsync();

      if (list == null || list.Count == 0) {
        ret = Results.NotFound(InfoMessage);
      }
      else {
        ret = Results.Ok(list);
      }
    }
    catch (Exception ex) {
      // Return generic message for the user
      InfoMessage = _Settings.InfoMessageDefault
          .Replace("{Verb}", "GET")
          .Replace("{ClassName}", TagName);

      ErrorLogMessage = "Error in CustomerAsyncRouter.GetAsync()";

      ret = HandleException(ex);
    }

    return ret;
  }

  protected virtual async Task<IResult> GetAsync(int id, IRepository<Customer, CustomerSearch> repo)
  {
    Customer? entity;

    entity = await repo.GetAsync(id);
    if (entity == null) {
      return Results.NotFound($"Customer with CustomerID = '{id}' was not found.");
    }
    else {
      return Results.Ok(entity);
    }
  }

  protected virtual async Task<IResult> SearchAsync(CustomerSearch search, IRepository<Customer, CustomerSearch> repo)
  {
    IResult ret;
    List<Customer> list;

    InfoMessage = "Can't find Customers matching the criteria passed in.";

    try {
      // Search for Data
      list = await repo.SearchAsync(search);

      if (list != null && list.Count > 0) {
        return Results.Ok(list);
      }
      else {
        return Results.NotFound(InfoMessage);
      }
    }
    catch (Exception ex) {
      ErrorLogMessage = "Error in CustomerController.SearchAsync()";

      ret = HandleException(ex);
    }

    return ret;
  }
}
