﻿using AdvWorksAPI.BaseClasses;

namespace AdvWorksAPI.SearchClasses;

public class ProductSearch : SearchBase
{
  public ProductSearch()
  {
    Name = string.Empty;
    OrderBy = "Name";
  }

  public string Name { get; set; }
  public decimal? ListPrice { get; set; }

  /// <summary>
  /// The following allows us to bind the ProductSearch on the query line when using Minimal APIs
  /// </summary>
  /// <param name="httpContext"></param>
  /// <param name="parameter"></param>
  /// <returns></returns>
  public static ValueTask<ProductSearch> BindAsync(HttpContext httpContext)
  {
    // Create product search object
    ProductSearch search = new() {
      // Get name from query line, if it exists
      Name = httpContext.Request.Query["name"].ToString()
    };

    // See if listPrice is passed in, and it's a decimal value
    if (decimal.TryParse(httpContext.Request.Query["listPrice"],
     out var listPrice)) {
      search.ListPrice = listPrice;
    }

    // Create ValueTask object from ProductSearch object
    return ValueTask.FromResult<ProductSearch>(search);
  }
}
