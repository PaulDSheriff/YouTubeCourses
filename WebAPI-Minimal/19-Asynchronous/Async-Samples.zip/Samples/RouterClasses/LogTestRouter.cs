﻿using System.Text.Json;
using AdvWorksAPI.BaseClasses;
using AdvWorksAPI.EntityLayer;

namespace AdvWorksAPI.RouterClasses;

public class LogTestRouter : RouterBase
{
  public LogTestRouter(ILogger<LogTestRouter> logger, AdvWorksAPIDefaults settings) : base(logger, settings)
  {
    UrlFragment = "api/LogTest";
    TagName = "LogTest";
  }

  /// <summary>
  /// Add routes
  /// </summary>
  /// <param name="app">A WebApplication object</param>
  public override void AddRoutes(WebApplication app)
  {
    app.MapGet($"/{UrlFragment}/WriteLogMessages", () => WriteLogMessages())
        .WithTags(TagName)
        .Produces(200);

    app.MapGet($"/{UrlFragment}/LogObject", () => LogProduct())
      .WithTags(TagName)
      .Produces(200);
  }

  protected virtual IResult WriteLogMessages()
  {
    // The following are in the Log Level order
    _Logger.LogTrace("This is a Trace log entry");
    _Logger.LogDebug("This is a Debug log entry.");
    _Logger.LogInformation("This is an Information log entry.");
    _Logger.LogWarning("This is a Warning log entry.");
    _Logger.LogError("This is an Error log entry.");
    _Logger.LogError(new ApplicationException("This is an exception."), "Exception Object");
    _Logger.LogCritical("This is a Critical log entry.");

    return Results.Ok("Check Console Window or Log File.");
  }

  protected virtual IResult LogProduct()
  {
    // Log an Object
    Product entity = new()
    {
      ProductID = 999,
      Name = "A Test Product",
      ProductNumber = "TEST001",
      StandardCost = 5M,
      ListPrice = 10.99M,
      Color = "Black",
      Size = "LG"
    };

    _Logger.LogInformation("Product = {0}", base.SerializeEntity<Product>(entity));

    return Results.Ok("Check Console Window or Log File.");
  }
}
