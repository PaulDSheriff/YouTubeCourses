﻿using AdvWorksAPI.EntityLayer;
using AdvWorksAPI.Interfaces;
using AdvWorksAPI.RouterClasses;
using AdvWorksAPI.SearchClasses;

namespace AdvWorksAPI.BaseClasses;

public class ProductAsyncRouter : RouterBase
{
  public ProductAsyncRouter(ILogger<ProductRouter> logger, AdvWorksAPIDefaults settings) : base(logger, settings)
  {
    UrlFragment = "api/ProductAsync";
    TagName = "ProductAsync";
  }

  /// <summary>
  /// Add asynchronous routes
  /// </summary>
  /// <param name="app">A WebApplication object</param>
  public override void AddRoutes(WebApplication app)
  {
    app.MapGet($"/{UrlFragment}", async (IRepository<Product, ProductSearch> repo) => await GetAsync(repo))
       .WithTags(TagName)
       .Produces(200)
       .Produces<List<Product>>()
       .Produces(404)
       .Produces(500);

    app.MapGet($"/{UrlFragment}/{{id:int}}", async (int id, IRepository<Product, ProductSearch> repo) => await GetAsync(id, repo))
      .WithTags(TagName)
      .Produces(200)
      .Produces<Product>()
      .Produces(404);

    app.MapGet($"/{UrlFragment}/Search", async (ProductSearch search, IRepository<Product, ProductSearch> repo) => await SearchAsync(search, repo))
      .WithTags(TagName)
      .Produces(200)
      .Produces<List<Product>>()
      .Produces(404);

    app.MapPost($"/{UrlFragment}", async (Product entity, IRepository<Product, ProductSearch> repo) => await InsertAsync(entity, repo))
      .WithTags(TagName)
      .Produces(200)
      .Produces<Product>()
      .Produces(400)
      .Produces(500);

    app.MapPut($"/{UrlFragment}/{{id:int}}", async (int id, Product entity, IRepository<Product, ProductSearch> repo) => await UpdateAsync(id, entity, repo))
      .WithTags(TagName)
      .Produces(200)
      .Produces<Product>()
      .Produces(404)
      .Produces(500);

    app.MapDelete($"/{UrlFragment}/{{id:int}}", async (int id, IRepository<Product, ProductSearch> repo) => await DeleteAsync(id, repo))
      .WithTags(TagName)
      .Produces(200)
      .Produces<Product>()
      .Produces(404)
      .Produces(500);
  }

  protected virtual async Task<IResult> GetAsync(IRepository<Product, ProductSearch> repo)
  {
    IResult ret;
    List<Product> list;
    InfoMessage = "No Products Found.";

    try {
      list = await repo.GetAsync();

      if (list == null || list.Count == 0) {
        ret = Results.NotFound(InfoMessage);
      }
      else {
        ret = Results.Ok(list);
      }
    }
    catch (Exception ex) {
      // Return generic message for the user
      InfoMessage = _Settings.InfoMessageDefault
          .Replace("{Verb}", "GET")
          .Replace("{ClassName}", "Product");

      ErrorLogMessage = "Error in ProductRouter.GetAsync()";
      ErrorLogMessage += $"{Environment.NewLine}Message: {ex.Message}";
      ErrorLogMessage += $"{Environment.NewLine}Source: {ex.Source}";

      ret = HandleException(ex);
    }

    return ret;
  }

  protected virtual async Task<IResult> GetAsync(int id, IRepository<Product, ProductSearch> repo)
  {
    Product? entity;

    entity = await repo.GetAsync(id);
    if (entity == null) {
      return Results.NotFound($"Product with ProductID = '{id}' was not found.");
    }
    else {
      return Results.Ok(entity);
    }
  }

  protected virtual async Task<IResult> SearchAsync(ProductSearch search, IRepository<Product, ProductSearch> repo)
  {
    IResult ret;
    List<Product> list;

    InfoMessage = "Can't find products matching the criteria passed in.";

    try {
      // Search for Data
      list = await repo.SearchAsync(search);

      if (list != null && list.Count > 0) {
        return Results.Ok(list);
      }
      else {
        return Results.NotFound(InfoMessage);
      }
    }
    catch (Exception ex) {
      // Return generic message for the user
      InfoMessage = _Settings.InfoMessageDefault
          .Replace("{Verb}", "SEARCH")
          .Replace("{ClassName}", "Product");

      ErrorLogMessage = "Error in ProductRouter.SearchAsync()";
      ErrorLogMessage += $"{Environment.NewLine}Message: {ex.Message}";
      ErrorLogMessage += $"{Environment.NewLine}Source: {ex.Source}";

      ret = HandleException(ex);
    }

    return ret;
  }

  protected virtual async Task<IResult> InsertAsync(Product entity, IRepository<Product, ProductSearch> repo)
  {
    IResult ret;

    // Serialize entity
    SerializeEntity<Product>(entity);

    try {
      if (entity != null) {
        // Attempt to update the database
        entity = await repo.InsertAsync(entity);

        // Return a '201 Created' with the new entity
        ret = Results.Created($"/{UrlFragment}/{entity.ProductID}", entity);
      }
      else {
        InfoMessage = "Product object passed to POST method is empty.";
        // Return a '400 Bad Request'
        ret = Results.BadRequest(InfoMessage);
        // Log an informational message
        _Logger.LogInformation("{InfoMessage}", InfoMessage);
      }
    }
    catch (Exception ex) {
      // Return generic message for the user
      InfoMessage = _Settings.InfoMessageDefault
        .Replace("{Verb}", "POST")
        .Replace("{ClassName}", "Product");

      // Log the exception and return a '500' status
      ErrorLogMessage = $"ProductRouter.Insert() - Exception trying to insert a new product: {EntityAsJson}";

      ret = HandleException(ex);
    }

    return ret;
  }

  protected virtual async Task<IResult> UpdateAsync(int id, Product entity, IRepository<Product, ProductSearch> repo)
  {
    IResult ret;

    // Serialize entity
    SerializeEntity<Product>(entity);

    try {
      if (entity != null) {
        // Attempt to locate the data to update
        Product? current = await repo.GetAsync(id);

        if (current != null) {
          // Combine changes into current record
          entity = repo.SetValues(current, entity);

          // Attempt to update the database
          current = await repo.UpdateAsync(current);

          // Pass back a '200 Ok'
          ret = Results.Ok(current);
        }
        else {
          InfoMessage = $"Can't find Product Id '{id}' to update.";
          // Did not find data, return '404 Not Found'
          ret = Results.NotFound(InfoMessage);
          // Log an informational message
          _Logger.LogInformation("{InfoMessage}", InfoMessage);
        }
      }
      else {
        InfoMessage = $"Product object passed to PUT method is empty.";
        // Return a '400 Bad Request'
        ret = Results.BadRequest(InfoMessage);
        // Log an informational message
        _Logger.LogInformation("{InfoMessage}", InfoMessage);
      }
    }
    catch (Exception ex) {
      // Return generic message for the user
      InfoMessage = _Settings.InfoMessageDefault
        .Replace("{Verb}", "PUT")
        .Replace("{ClassName}", "Product");

      // Log the exception and return a '500' status
      ErrorLogMessage = $"ProductRouter.Update() - Exception trying to update Product: {EntityAsJson}";
      ret = HandleException(ex);
    }

    return ret;
  }

  protected virtual async Task<IResult> DeleteAsync(int id, IRepository<Product, ProductSearch> repo)
  {
    IResult ret;

    try {
      // Attempt to delete from the database    
      if (await repo.DeleteAsync(id)) {
        // Return '204 No Content'
        ret = Results.NoContent();
      }
      else {
        InfoMessage = $"Can't find Product Id '{id}' to delete.";
        // Did not find data, return '404 Not Found'
        ret = Results.NotFound(InfoMessage);
        // Log an informational message
        _Logger.LogInformation("{InfoMessage}", InfoMessage);
      }
    }
    catch (Exception ex) {
      // Return generic message for the user
      InfoMessage = _Settings.InfoMessageDefault
        .Replace("{Verb}", "DELETE")
        .Replace("{ClassName}", "Product");

      // Log the exception and return a '500' status
      ErrorLogMessage = $"ProductRouter.Delete() - Exception trying to delete ProductID: '{id}'.";
      ret = HandleException(ex);
    }

    return ret;
  }
}
