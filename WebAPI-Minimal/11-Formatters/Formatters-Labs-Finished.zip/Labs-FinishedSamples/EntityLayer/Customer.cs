﻿using System.Text.Json.Serialization;

namespace AdvWorksAPI.EntityLayer;

public partial class Customer
{
  public Customer()
  {
    Title = string.Empty;
    FirstName = string.Empty;
    MiddleName = string.Empty;
    LastName = string.Empty;
    CompanyName = string.Empty;
    EmailAddress = string.Empty;
    Phone = string.Empty;
  }

  public int CustomerID { get; set; }
  public string? Title { get; set; }
  public string FirstName { get; set; }
  //[JsonIgnore]
  public string? MiddleName { get; set; }
  public string LastName { get; set; }
  //[JsonPropertyName("Company")]
  public string? CompanyName { get; set; }
  //[JsonPropertyName("Email")]
  public string? EmailAddress { get; set; }
  public string? Phone { get; set; }
  //[JsonPropertyOrder(-1)]
  public DateTime ModifiedDate { get; set; }

  public bool IsActive { get; }

  #region ToString Override
  public override string ToString()
  {
    return $"{LastName}, {FirstName} ({CustomerID})";
  }
  #endregion
}
