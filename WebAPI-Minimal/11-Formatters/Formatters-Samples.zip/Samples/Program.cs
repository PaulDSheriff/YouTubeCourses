using AdvWorksAPI.BaseClasses;
using AdvWorksAPI.EntityLayer;
using AdvWorksAPI.Interfaces;
using AdvWorksAPI.RepositoryLayer;
using AdvWorksAPI.RouterClasses;
using Serilog;
using Serilog.Events;
using Microsoft.AspNetCore.Http.Json;

// **********************************************
// Create a WebApplicationBuilder object
// to configure the how the ASP.NET service runs
// **********************************************
var builder = WebApplication.CreateBuilder(args);

// **********************************************
// Add and Configure Services
// **********************************************
builder.Services.AddSingleton<AdvWorksAPIDefaults, AdvWorksAPIDefaults>();
builder.Services.AddScoped<IRepository<Product>, ProductRepository>();
// Read "AdvWorksAPI" section and add as a singleton
AdvWorksAPIDefaults settings = new();
builder.Configuration.GetSection("AdvWorksAPI").Bind(settings);
builder.Services.AddSingleton<AdvWorksAPIDefaults>(settings);

// Add "Router" classes as a service
builder.Services.AddScoped<RouterBase, ProductRouter>();
builder.Services.AddScoped<RouterBase, SimpleRouter>();
builder.Services.AddScoped<RouterBase, SettingsRouter>();
builder.Services.AddScoped<RouterBase, LogTestRouter>();
builder.Services.AddScoped<RouterBase, ErrorRouter>();
builder.Services.AddScoped<RouterBase, ConfigTestRouter>();

// Configure logging to Console & File using Serilog
builder.Host.UseSerilog((ctx, lc) =>
{
  // Log to Console
  lc.WriteTo.Console();
  // Log to Rolling File
  lc.WriteTo.File("Logs/InfoLog-.txt",
    rollingInterval: RollingInterval.Day,
    restrictedToMinimumLevel: LogEventLevel.Information
  );
  lc.WriteTo.File("Logs/ErrorLog-.txt",
    rollingInterval: RollingInterval.Day,
    restrictedToMinimumLevel: LogEventLevel.Error);
});

// Configure JSON Options
builder.Services.Configure<JsonOptions>(options =>
{
  // Set property names to PascalCase
  options.SerializerOptions.PropertyNamingPolicy = null;
  // Ignore "readonly" fields
  options.SerializerOptions.IgnoreReadOnlyProperties = true;
});


// Configure Open API (Swagger)
// More Info: https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

// **********************************************
// After adding and configuring services
// Create an instance of a WebApplication object
// **********************************************
var app = builder.Build();

// **********************************************
// Configure the HTTP Request Pipeline
// **********************************************
if (app.Environment.IsDevelopment()) {
  app.UseSwagger();
  app.UseSwaggerUI();
}

// Enable Exception Handling Middleware
if (app.Environment.IsDevelopment()) {
  app.UseExceptionHandler("/DevelopmentError");
}
else {
  app.UseExceptionHandler("/ProductionError");
}
app.UseStatusCodePagesWithReExecute("/StatusCode/{0}");

//*********************************************
// Create Minimal API Endpoints by
// Adding Routes from All Router Classes
// Run the Application
//*********************************************
using (var scope = app.Services.CreateScope()) {
  var services = scope.ServiceProvider.GetServices<RouterBase>();
  // Loop through each RouterBase class
  foreach (var item in services) {
    // Invoke the AddRoutes() method to add the routes
    item.AddRoutes(app);
  }

  // Run the Application
  app.Run();
}
