﻿using AdvWorksAPI.BaseClasses;
using AdvWorksAPI.EntityLayer;
using AdvWorksAPI.Interfaces;

namespace AdvWorksAPI.RouterClasses;

public class ProductRouter : RouterBase
{
  public ProductRouter(IRepository<Product> _repo, ILogger<ProductRouter> logger) : base(logger)
  {
    UrlFragment = "api/Product";
    TagName = "Product";
    _Repo = _repo;
  }
  private readonly IRepository<Product> _Repo;

  /// <summary>
  /// Add routes
  /// </summary>
  /// <param name="app">A WebApplication object</param>
  public override void AddRoutes(WebApplication app)
  {
    app.MapGet($"/{UrlFragment}", () => Get())
       .WithTags(TagName)
       .Produces(200)
       .Produces<List<Product>>()
       .Produces(404)
       .Produces(500);

    app.MapGet($"/{UrlFragment}/{{id:int}}", (int id) => Get(id))
      .WithTags(TagName)
      .Produces(200)
      .Produces<Product>()
      .Produces(404);
  }

  protected virtual IResult Get()
  {
    IResult ret;
    List<Product> list;
    InfoMessage = "No Products Found.";

    try {
      // Intentionally Cause an Exception
      //throw new ApplicationException("ERROR!");

      list = _Repo.Get();

      //list.Clear();
      if (list == null || list.Count == 0) {
        ret = Results.NotFound(InfoMessage);
      }
      else {
        ret = Results.Ok(list);
      }
    }
    catch (Exception ex) {
      InfoMessage = "Error in Product API. Please Contact the System Administrator.";

      ErrorLogMessage = "Error in ProductRouter.Get()";
      ErrorLogMessage += $"{Environment.NewLine}Message: {ex.Message}";
      ErrorLogMessage += $"{Environment.NewLine}Source: {ex.Source}";

      ret = HandleException(ex);
    }

    return ret;
  }


  protected virtual IResult Get(int id)
  {
    Product? entity;

    // Attempt to get a single product
    entity = _Repo.Get(id);
    if (entity == null) {
      return Results.NotFound($"Product with Product ID = '{id}' Not Found.");
    }
    else {
      return Results.Ok(entity);
    }
  }
}
