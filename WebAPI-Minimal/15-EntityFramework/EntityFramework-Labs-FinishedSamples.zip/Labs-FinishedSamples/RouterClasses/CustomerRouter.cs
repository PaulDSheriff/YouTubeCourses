﻿using AdvWorksAPI.BaseClasses;
using AdvWorksAPI.EntityLayer;
using AdvWorksAPI.Interfaces;
using AdvWorksAPI.RepositoryLayer;

namespace AdvWorksAPI.RouterClasses;

public class CustomerRouter : RouterBase
{
  private readonly AdvWorksAPIDefaults _Settings;

  public CustomerRouter(ILogger<CustomerRouter> logger, AdvWorksAPIDefaults settings) : base(logger)
  {
    UrlFragment = "api/Customer";
    TagName = "Customer";
    _Settings = settings;
  }

  /// <summary>
  /// Add routes
  /// </summary>
  /// <param name="app">A WebApplication object</param>
  public override void AddRoutes(WebApplication app)
  {
    app.MapGet($"/{UrlFragment}", (IRepository<Customer> repo) => Get(repo))
        .WithTags(TagName)
        .Produces(200)
        .Produces<List<Customer>>()
        .Produces(404)
        .Produces(500);
    //.RequireAuthorization("GetCustomersClaim");

    app.MapGet($"/{UrlFragment}/{{id:int}}", (int id, IRepository<Customer> repo) => Get(id, repo))
        .WithTags(TagName)
        .Produces(200)
        .Produces<Customer>()
        .Produces(404);
  }

  protected virtual IResult Get(IRepository<Customer> repo)
  {
    IResult ret;
    List<Customer> list;
    InfoMessage = "No Customers Found.";

    try {
      // Intentionally Cause an Exception
      //throw new ApplicationException("ERROR!");

      list = repo.Get();

      //list.Clear();
      if (list == null || list.Count == 0) {
        ret = Results.NotFound(InfoMessage);
      }
      else {
        ret = Results.Ok(list);
      }
    }
    catch (Exception ex) {
      // Return generic message for the user
      InfoMessage = _Settings.InfoMessageDefault
          .Replace("{Verb}", "GET")
          .Replace("{ClassName}", "Customer");

      ErrorLogMessage = "Error in CustomerRouter.Get()";

      ret = HandleException(ex);
    }

    return ret;
  }

  protected virtual IResult Get(int id, IRepository<Customer> repo)
  {
    Customer? entity;

    // Attempt to get a single product
    entity = repo.Get(id);
    if (entity == null) {
      return Results.NotFound($"Customer with Customer ID = '{id}' Not Found.");
    }
    else {
      return Results.Ok(entity);
    }
  }

}
