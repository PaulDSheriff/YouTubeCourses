using AdvWorksAPI;
using AdvWorksAPI.EntityLayer;
using AdvWorksAPI.Interfaces;
using AdvWorksAPI.RepositoryLayer;
using AdvWorksAPI.RouterClasses;

// **********************************************
// Create a WebApplicationBuilder object
// to configure the how the ASP.NET service runs
// **********************************************
var builder = WebApplication.CreateBuilder(args);

// **********************************************
// Add and Configure Services
// **********************************************
builder.Services.AddSingleton<AdvWorksAPIDefaults, AdvWorksAPIDefaults>();
builder.Services.AddScoped<IRepository<Customer>, CustomerRepository>();

// Add "Router" Classes as a Service
builder.Services.AddScoped<RouterBase, CustomerRouter>();
builder.Services.AddScoped<RouterBase, SettingsRouter>();

// Configure Open API (Swagger)
// More Info: https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

// **********************************************
// After adding and configuring services
// Create an instance of a WebApplication object
// **********************************************
var app = builder.Build();

// **********************************************
// Configure the HTTP Request Pipeline
// **********************************************
if (app.Environment.IsDevelopment()) {
  app.UseSwagger();
  app.UseSwaggerUI();
}

//*********************************************
// Map Minimal API Endpoints by
// Adding Routes from All Router Classes
// Run the Application
//*********************************************
using (var scope = app.Services.CreateScope()) {
  var services = scope.ServiceProvider.GetServices<RouterBase>();
  // Loop through each RouterBase class
  foreach (var item in services) {
    // Invoke the AddRoutes() method to add the routes
    item.AddRoutes(app);
  }

  // Run the Application
  app.Run();
}
