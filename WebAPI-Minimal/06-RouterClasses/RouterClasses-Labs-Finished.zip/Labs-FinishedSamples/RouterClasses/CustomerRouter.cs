﻿using AdvWorksAPI.EntityLayer;
using AdvWorksAPI.Interfaces;
using AdvWorksAPI.RepositoryLayer;

namespace AdvWorksAPI.RouterClasses;

public class CustomerRouter : RouterBase
{
  private readonly IRepository<Customer> _Repo;

  public CustomerRouter(IRepository<Customer> repo)
  {
    UrlFragment = "api/Customer";
    TagName = "Customer";
    _Repo = repo;
  }

  /// <summary>
  /// Add routes
  /// </summary>
  /// <param name="app">A WebApplication object</param>
  public override void AddRoutes(WebApplication app)
  {
    app.MapGet($"/{UrlFragment}", () => Get())
       .WithTags(TagName)
       .Produces(200)
       .Produces<List<Customer>>()
       .Produces(404);

    app.MapGet($"/{UrlFragment}/{{id:int}}", (int id) => Get(id))
       .WithTags(TagName)
       .Produces(200)
       .Produces<Customer>()
       .Produces(404);
  }

  protected virtual IResult Get()
  {
    List<Customer> list;

    // Get all customers
    list = _Repo.Get();

    // Simulate not getting any data
    //list.Clear();

    if (list == null || list.Count == 0) {
      return Results.NotFound("No Customers Found.");
    }
    else {
      return Results.Ok(list);
    }
  }

  protected virtual IResult Get(int id)
  {
    Customer? entity;

    // Attempt to get a single product
    entity = _Repo.Get(id);
    if (entity == null) {
      return Results.NotFound($"Customer with Customer ID = '{id}' Not Found.");
    }
    else {
      return Results.Ok(entity);
    }
  }

}
