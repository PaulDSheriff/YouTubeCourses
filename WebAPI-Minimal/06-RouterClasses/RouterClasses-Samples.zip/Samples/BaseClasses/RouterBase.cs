﻿namespace AdvWorksAPI.BaseClasses;

public abstract class RouterBase
{
  public RouterBase()
  {
    UrlFragment = string.Empty;
    TagName = string.Empty;
  }

  public string UrlFragment;
  public string TagName;

  public abstract void AddRoutes(WebApplication app);
}
