﻿using AdvWorksAPI.EntityLayer;

namespace AdvWorksAPI;

public class SettingsRouter : RouterBase
{
  public SettingsRouter()
  {
    UrlFragment = "api/Settings";
    TagName = "Settings";
  }

  /// <summary>
  /// Add routes
  /// </summary>
  /// <param name="app">A WebApplication object</param>
  public override void AddRoutes(WebApplication app)
  {
    app.MapGet($"/{UrlFragment}", (AdvWorksAPIDefaults settings)
      => Results.Ok(settings))
      .WithTags(TagName);
    app.MapGet($"/{UrlFragment}Again", (AdvWorksAPIDefaults settings)
      => Results.Ok(settings))
      .WithTags(TagName);
  }
}
