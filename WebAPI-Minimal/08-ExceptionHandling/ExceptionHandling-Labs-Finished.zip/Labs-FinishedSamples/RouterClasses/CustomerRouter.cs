﻿using AdvWorksAPI.EntityLayer;
using AdvWorksAPI.Interfaces;
using AdvWorksAPI.RepositoryLayer;

namespace AdvWorksAPI.RouterClasses;

public class CustomerRouter : RouterBase
{
  private readonly IRepository<Customer> _Repo;
  private readonly ILogger<CustomerRouter> _Logger;

  public CustomerRouter(IRepository<Customer> repo, ILogger<CustomerRouter> logger)
  {
    UrlFragment = "api/Customer";
    TagName = "Customer";
    _Repo = repo;
    _Logger = logger;
  }

  /// <summary>
  /// Add routes
  /// </summary>
  /// <param name="app">A WebApplication object</param>
  public override void AddRoutes(WebApplication app)
  {
    app.MapGet($"/{UrlFragment}", () => Get())
       .WithTags(TagName)
       .Produces(200)
       .Produces<List<Customer>>()
       .Produces(404)
       .Produces(500);


    app.MapGet($"/{UrlFragment}/{{id:int}}", (int id) => Get(id))
       .WithTags(TagName)
       .Produces(200)
       .Produces<Customer>()
       .Produces(404);

  }

  protected virtual IResult Get()
  {
    IResult ret;
    List<Customer> list;
    string msg = "No Customers Found.";

    try {
      // Intentionally Cause an Exception
      throw new ApplicationException("ERROR!");

      // Get all customers
      list = _Repo.Get();

      //list.Clear();
      if (list == null || list.Count == 0) {
        ret = Results.NotFound(msg);
      }
      else {
        ret = Results.Ok(list);
      }
    }
    catch (Exception ex) {
      msg = "Error in CustomerRouter.Get()";
      msg += $"{Environment.NewLine}Message: {ex.Message}";
      msg += $"{Environment.NewLine}Source: {ex.Source}";

      // Log error for the developer
      _Logger.LogError(ex, "{msg}", msg);

      // Return generic message for the user
      ret = Results.Problem("Error in Customer API. Please Contact the System Administrator");
    }

    return ret;
  }

  protected virtual IResult Get(int id)
  {
    Customer? entity;

    // Attempt to get a single product
    entity = _Repo.Get(id);
    if (entity == null) {
      return Results.NotFound($"Customer with Customer ID = '{id}' Not Found.");
    }
    else {
      return Results.Ok(entity);
    }
  }

}
