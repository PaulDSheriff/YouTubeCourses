﻿using Microsoft.AspNetCore.Diagnostics;

namespace AdvWorksAPI;

public class ErrorRouter : RouterBase
{
  /// <summary>
  /// Add routes
  /// </summary>
  /// <param name="app">A WebApplication object</param>
  public override void AddRoutes(WebApplication app)
  {
    app.Map("/ProductionError", (HttpContext context) => ProductionErrorHandler(context));
    app.Map("/DevelopmentError", (HttpContext context) => DevelopmentErrorHandler(context));
  }

  protected virtual IResult ProductionErrorHandler(HttpContext context)
  {
    string msg = "Unknown Exception";

    var features = context.Features.Get<IExceptionHandlerFeature>();

    if (features != null) {
      msg = features.Error.Message;
    }

    return Results.Problem(msg);
  }

  protected virtual IResult DevelopmentErrorHandler(HttpContext context)
  {
    string msg = "Unknown Exception";

    var features = context.Features.Get<IExceptionHandlerFeature>();

    if (features != null) {
      msg = "Message: " + features.Error.Message;
      msg += Environment.NewLine + "Source: " + features.Error.Source;
      msg += Environment.NewLine + features.Error.StackTrace;
    }

    return Results.Problem(msg);
  }
}
