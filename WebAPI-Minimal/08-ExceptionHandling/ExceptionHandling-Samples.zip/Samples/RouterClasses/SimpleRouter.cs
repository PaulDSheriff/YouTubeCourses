﻿using AdvWorksAPI.BaseClasses;

namespace AdvWorksAPI.RouterClasses;

public class SimpleRouter : RouterBase
{
  public SimpleRouter()
  {
    UrlFragment = "api/Simple";
    TagName = "Simple";
  }

  /// <summary>
  /// Add routes
  /// </summary>
  /// <param name="app">A WebApplication object</param>
  public override void AddRoutes(WebApplication app)
  {
    app.MapGet($"{UrlFragment}/HelloAll", () => "Hello Everyone").WithTags("Simple");
    app.MapGet($"{UrlFragment}/HelloWorld", () => Results.Ok("Hello World")).WithTags("Simple");
    app.MapGet($"{UrlFragment}/HelloPerson", (string name) => Results.Ok($"Hello {name}")).WithTags("Simple");
  }
}
