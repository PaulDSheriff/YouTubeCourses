﻿using AdvWorksAPI.BaseClasses;
using AdvWorksAPI.EntityLayer;
using AdvWorksAPI.Interfaces;

namespace AdvWorksAPI.RouterClasses;

public class ProductRouter : RouterBase
{
  public ProductRouter(IRepository<Product> _repo, ILogger<ProductRouter> logger)
  {
    UrlFragment = "api/Product";
    TagName = "Product";
    _Repo = _repo;
    _Logger = logger;
  }
  private readonly IRepository<Product> _Repo;
  private readonly ILogger<ProductRouter> _Logger;

  /// <summary>
  /// Add routes
  /// </summary>
  /// <param name="app">A WebApplication object</param>
  public override void AddRoutes(WebApplication app)
  {
    app.MapGet($"/{UrlFragment}", () => Get())
       .WithTags(TagName)
       .Produces(200)
       .Produces<List<Product>>()
       .Produces(404)
       .Produces(500);

    app.MapGet($"/{UrlFragment}/{{id:int}}", (int id) => Get(id))
      .WithTags(TagName)
      .Produces(200)
      .Produces<Product>()
      .Produces(404);
  }

  protected virtual IResult Get()
  {
    IResult ret;
    List<Product> list;
    string msg = "No Products Found.";

    try {
      // Intentionally Cause an Exception
      throw new ApplicationException("ERROR!");

      list = _Repo.Get();

      //list.Clear();
      if (list == null || list.Count == 0) {
        ret = Results.NotFound(msg);
      }
      else {
        ret = Results.Ok(list);
      }
    }
    catch (Exception ex) {
      msg = "Error in ProductRouter.Get()";
      msg += $"{Environment.NewLine}Message: {ex.Message}";
      msg += $"{Environment.NewLine}Source: {ex.Source}";

      // Log error for the developer
      _Logger.LogError(ex, "{msg}", msg);

      // Return generic message for the user
      ret = Results.Problem("Error in Product API. Please Contact the System Administrator");
    }

    return ret;
  }


  protected virtual IResult Get(int id)
  {
    Product? entity;

    // Attempt to get a single product
    entity = _Repo.Get(id);
    if (entity == null) {
      return Results.NotFound($"Product with Product ID = '{id}' Not Found.");
    }
    else {
      return Results.Ok(entity);
    }
  }
}
