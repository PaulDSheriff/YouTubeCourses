using AdvWorksAPI;
using AdvWorksAPI.EntityLayer;
using AdvWorksAPI.Interfaces;
using AdvWorksAPI.RepositoryLayer;
using AdvWorksAPI.RouterClasses;
using Serilog;
using Serilog.Events;

// **********************************************
// Create a WebApplicationBuilder object
// to configure the how the ASP.NET service runs
// **********************************************
var builder = WebApplication.CreateBuilder(args);

// **********************************************
// Add and Configure Services
// **********************************************
builder.Services.AddSingleton<AdvWorksAPIDefaults, AdvWorksAPIDefaults>();
// Read "AdvWorksAPI" section
// Use the IOptionsMonitor<AdvWorksAPIDefaults> in controller's constructor
builder.Services.Configure<AdvWorksAPIDefaults>(builder.Configuration.GetSection("AdvWorksAPI"));
builder.Services.AddScoped<IRepository<Customer>, CustomerRepository>();

// Add "Router" Classes as a Service
builder.Services.AddScoped<RouterBase, ErrorRouter>();
builder.Services.AddScoped<RouterBase, CustomerRouter>();
builder.Services.AddScoped<RouterBase, SettingsRouter>();
builder.Services.AddScoped<RouterBase, LogTestRouter>();

// Configure logging to Console & File using Serilog
builder.Host.UseSerilog((ctx, lc) =>
{
  // Log to Console
  lc.WriteTo.Console();
  // Log to Rolling File
  lc.WriteTo.File("Logs/InfoLog-.txt",
  rollingInterval: RollingInterval.Day,
  restrictedToMinimumLevel: LogEventLevel.Information);
  lc.WriteTo.File("Logs/ErrorLog-.txt",
    rollingInterval: RollingInterval.Day,
    restrictedToMinimumLevel: LogEventLevel.Error);
});

// Configure Open API (Swagger)
// More Info: https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

// **********************************************
// After adding and configuring services
// Create an instance of a WebApplication object
// **********************************************
var app = builder.Build();

// **********************************************
// Configure the HTTP Request Pipeline
// **********************************************
if (app.Environment.IsDevelopment()) {
  app.UseSwagger();
  app.UseSwaggerUI();
}

// Enable Exception Handling Middleware
if (app.Environment.IsDevelopment()) {
  app.UseExceptionHandler("/DevelopmentError");
}
else {
  app.UseExceptionHandler("/ProductionError");
}

//*********************************************
// Map Minimal API Endpoints by
// Adding Routes from All Router Classes
// Run the Application
//*********************************************
using (var scope = app.Services.CreateScope()) {
  var services = scope.ServiceProvider.GetServices<RouterBase>();
  // Loop through each RouterBase class
  foreach (var item in services) {
    // Invoke the AddRoutes() method to add the routes
    item.AddRoutes(app);
  }

  // Run the Application
  app.Run();
}
