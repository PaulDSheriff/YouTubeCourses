﻿using AdvWorksAPI.BaseClasses;
using AdvWorksAPI.EntityLayer;

namespace AdvWorksAPI.RouterClasses;

public class SettingsRouter : RouterBase
{
  public SettingsRouter(ILogger<SettingsRouter> logger) : base(logger)
  {
    UrlFragment = "api/Settings";
    TagName = "Settings";
  }

  /// <summary>
  /// Add routes
  /// </summary>
  /// <param name="app">A WebApplication object</param>
  public override void AddRoutes(WebApplication app)
  {
    app.MapGet($"/{UrlFragment}", (AdvWorksAPIDefaults settings)
      => Results.Ok(settings))
      .WithTags(TagName);
    app.MapGet($"/{UrlFragment}Again", (AdvWorksAPIDefaults settings)
      => Results.Ok(settings))
      .WithTags(TagName);
  }
}
