﻿using AdvWorksAPI.BaseClasses;
using AdvWorksAPI.EntityLayer;
using AdvWorksAPI.SecurityLayer;

namespace AdvWorksAPI.RouterClasses;

public class SecurityTestRouter : RouterBase
{
  private readonly AdvWorksAPIDefaults _Settings;

  public SecurityTestRouter(ILogger<SecurityTestRouter> logger, AdvWorksAPIDefaults settings) : base(logger)
  {
    UrlFragment = "api/SecurityTest";
    TagName = "SecurityTest";
    _Settings = settings;
  }

  /// <summary>
  /// Add routes
  /// </summary>
  /// <param name="app">A WebApplication object</param>
  public override void AddRoutes(WebApplication app)
  {
    app.MapGet($"/{UrlFragment}/AuthenticateUser/{{name}}/password/{{password}}", (string name, string password) =>
      AuthenticateUser(name, password))
      .WithTags(TagName)
      .Produces(200)
      .Produces<AppSecurityToken>()
      .Produces(400);
  }

  protected virtual IResult AuthenticateUser(string name, string password)
  {
    IResult ret;
    AppSecurityToken asToken;

    asToken = new SecurityManager().AuthenticateUser(name, password, _Settings.JWTSettings);

    if (asToken.User.IsAuthenticated) {
      ret = Results.Ok(asToken);
    }
    else {
      ret = Results.BadRequest("Invalid User Name/Password.");
    }

    return ret;
  }
}
