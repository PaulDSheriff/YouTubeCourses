﻿using AdvWorksAPI.BaseClasses;
using AdvWorksAPI.EntityLayer;
using AdvWorksAPI.Interfaces;
using AdvWorksAPI.ValidationClasses;
using System.Runtime;

namespace AdvWorksAPI.RouterClasses;

public class ProductRouter : RouterBase
{
  public ProductRouter(ILogger<ProductRouter> logger, AdvWorksAPIDefaults settings) : base(logger, settings)
  {
    UrlFragment = "api/Product";
    TagName = "Product";
  }
  
  /// <summary>
  /// Add routes
  /// </summary>
  /// <param name="app">A WebApplication object</param>
  public override void AddRoutes(WebApplication app)
  {
    app.MapGet($"/{UrlFragment}", (IRepository<Product> repo) => Get(repo))
       .WithTags(TagName)
       .Produces(200)
       .Produces<List<Product>>()
       .Produces(404)
       .Produces(500);
       //.RequireAuthorization("GetProductsClaim");

    app.MapGet($"/{UrlFragment}/{{id:int}}", (int id, IRepository<Product> repo) => Get(id, repo))
      .WithTags(TagName)
      .Produces(200)
      .Produces<Product>()
      .Produces(404);

    app.MapPost($"/{UrlFragment}", (Product entity, IRepository<Product> repo) => Insert(entity, repo))
      .WithTags(TagName)
      .Produces(201)
      .Produces<Product>()
      .Produces(400)
      .Produces(500);

    app.MapPut($"/{UrlFragment}/{{id:int}}", (int id, Product entity, IRepository<Product> repo) => Update(id, entity, repo))
      .WithTags(TagName)
      .Produces(200)
      .Produces<Product>()
      .Produces(400)
      .Produces(404)
      .Produces(500);

    app.MapDelete($"/{UrlFragment}/{{id:int}}", (int id, IRepository<Product> repo) => Delete(id, repo))
      .WithTags(TagName)
      .Produces(204)
      .Produces<Product>()
      .Produces(404)
      .Produces(500);

  }

  protected virtual IResult Get(IRepository<Product> repo)
  {
    IResult ret;
    List<Product> list;
    InfoMessage = "No Products Found.";

    try {
      // Intentionally Cause an Exception
      //throw new ApplicationException("ERROR!");

      list = repo.Get();

      //list.Clear();
      if (list == null || list.Count == 0) {
        ret = Results.NotFound(InfoMessage);
      }
      else {
        ret = Results.Ok(list);
      }
    }
    catch (Exception ex) {
      InfoMessage = "Error in Product API. Please Contact the System Administrator.";

      ErrorLogMessage = "Error in ProductRouter.Get()";
      ErrorLogMessage += $"{Environment.NewLine}Message: {ex.Message}";
      ErrorLogMessage += $"{Environment.NewLine}Source: {ex.Source}";

      ret = HandleException(ex);
    }

    return ret;
  }


  protected virtual IResult Get(int id, IRepository<Product> repo)
  {
    Product? entity;

    // Attempt to get a single product
    entity = repo.Get(id);
    if (entity == null) {
      return Results.NotFound($"Product with Product ID = '{id}' Not Found.");
    }
    else {
      return Results.Ok(entity);
    }
  }

  protected virtual IResult Insert(Product entity, IRepository<Product> repo)
  {
    IResult ret;

    // Serialize entity
    SerializeEntity<Product>(entity);
    Dictionary<string, string[]> msgs;

    try {
      if (entity != null) {
        // Validate the Entity object
        msgs = ValidationHelper.Validate<Product>(entity);
        if (msgs == null || msgs.Count == 0) {
          // Attempt to update the database
          entity = repo.Insert(entity);

          // Return a '201 Created' with the new entity
          ret = Results.Created($"/{UrlFragment}/{entity.ProductID}", entity);
        }
        else {
          ret = Results.ValidationProblem(msgs);
        }
      }
      else {
        InfoMessage = "Product object passed to POST method is empty.";
        // Return a '400 Bad Request'
        ret = Results.BadRequest(InfoMessage);
        // Log an informational message
        _Logger.LogInformation("{InfoMessage}", InfoMessage);
      }
    }
    catch (Exception ex) {
      // Return generic message for the user
      InfoMessage = _Settings.InfoMessageDefault
        .Replace("{Verb}", "POST")
        .Replace("{ClassName}", "Product");

      // Log the exception and return a '500' status
      ErrorLogMessage = $"ProductRouter.Insert() - Exception trying to insert a new product: {EntityAsJson}";

      ret = HandleException(ex);
    }

    return ret;
  }

  protected virtual IResult Update(int id, Product entity, IRepository<Product> repo)
  {
    IResult ret;

    // Serialize entity
    SerializeEntity<Product>(entity);
    Dictionary<string, string[]> msgs;

    try {
      if (entity != null) {
        // Attempt to locate the data to update
        Product? current = repo.Get(id);

        if (current != null) {
          // Validate the Entity object
          msgs = ValidationHelper.Validate<Product>(entity);
          if (msgs == null || msgs.Count == 0) {
            // Combine changes into current record
            entity = repo.SetValues(current, entity);

            // Attempt to update the database
            current = repo.Update(current);

            // Pass back a '200 Ok'
            ret = Results.Ok(current);
          }
          else {
            ret = Results.ValidationProblem(msgs);
          }
        }
        else {
          InfoMessage = $"Can't find Product Id '{id}' to update.";
          // Did not find data, return '404 Not Found'
          ret = Results.NotFound(InfoMessage);
          // Log an informational message
          _Logger.LogInformation("{InfoMessage}", InfoMessage);
        }
      }
      else {
        InfoMessage = $"Product object passed to PUT method is empty.";
        // Return a '400 Bad Request'
        ret = Results.BadRequest(InfoMessage);
        // Log an informational message
        _Logger.LogInformation("{InfoMessage}", InfoMessage);
      }
    }
    catch (Exception ex) {
      // Return generic message for the user
      InfoMessage = _Settings.InfoMessageDefault
        .Replace("{Verb}", "PUT")
        .Replace("{ClassName}", "Product");

      // Log the exception and return a '500' status
      ErrorLogMessage = $"ProductRouter.Update() - Exception trying to update Product: {EntityAsJson}";
      ret = HandleException(ex);
    }

    return ret;
  }

  protected virtual IResult Delete(int id, IRepository<Product> repo)
  {
    IResult ret;

    try {
      // Attempt to delete from the database    
      if (repo.Delete(id)) {
        // Return '204 No Content'
        ret = Results.NoContent();
      }
      else {
        InfoMessage = $"Can't find Product Id '{id}' to delete.";
        // Did not find data, return '404 Not Found'
        ret = Results.NotFound(InfoMessage);
        // Log an informational message
        _Logger.LogInformation("{InfoMessage}", InfoMessage);
      }
    }
    catch (Exception ex) {
      // Return generic message for the user
      InfoMessage = _Settings.InfoMessageDefault
        .Replace("{Verb}", "DELETE")
        .Replace("{ClassName}", "Product");

      // Log the exception and return a '500' status
      ErrorLogMessage = $"ProductRouter.Delete() - Exception trying to delete ProductID: '{id}'.";
      ret = HandleException(ex);
    }

    return ret;
  }

}
