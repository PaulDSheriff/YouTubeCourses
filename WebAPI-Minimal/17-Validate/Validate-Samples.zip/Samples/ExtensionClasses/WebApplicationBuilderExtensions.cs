﻿using AdvWorksAPI.EntityLayer;
using AdvWorksAPI.Interfaces;
using AdvWorksAPI.RepositoryLayer;

namespace AdvWorksAPI.ExtensionClasses
{
  public static class WebApplicationBuilderExtensions
  {
    public static void ConfigureGlobalSettings(this WebApplicationBuilder builder)
    {
      builder.Services.AddSingleton<AdvWorksAPIDefaults, AdvWorksAPIDefaults>();

      // Read "AdvWorksAPI" section and add as a singleton
      AdvWorksAPIDefaults settings = new();
      builder.Configuration.GetSection("AdvWorksAPI").Bind(settings);
      builder.Services.AddSingleton<AdvWorksAPIDefaults>(settings);
    }
  }
}
