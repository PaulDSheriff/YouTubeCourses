using AdvWorksAPI.BaseClasses;
using AdvWorksAPI.ConstantClasses;
using AdvWorksAPI.ExtensionClasses;

// **********************************************
// Create a WebApplicationBuilder object
// to configure the how the ASP.NET service runs
// **********************************************
var builder = WebApplication.CreateBuilder(args);

// **********************************************
// Add and Configure Services
// **********************************************
// Add & Configure Global Application Settings
builder.ConfigureGlobalSettings();

// Add & Configure Repository Classes
builder.Services.AddRepositoryClasses();

// Add "Router" classes as a service
builder.Services.AddRouterClasses();

// Add & Configure Logging Serilog
builder.Host.ConfigureSeriLog();

// Add & Configure JSON Options
builder.Services.ConfigureJsonOptions();

// Add & Configure CORS
builder.Services.ConfigureCors();

// Configure Open API (Swagger)
// More Info: https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

// **********************************************
// After adding and configuring services
// Create an instance of a WebApplication object
// **********************************************
var app = builder.Build();

// **********************************************
// Configure the HTTP Request Pipeline
// **********************************************
if (app.Environment.IsDevelopment()) {
  app.UseSwagger();
  app.UseSwaggerUI();
}

// Enable Exception Handling Middleware
if (app.Environment.IsDevelopment()) {
  app.UseExceptionHandler("/DevelopmentError");
}
else {
  app.UseExceptionHandler("/ProductionError");
}
app.UseStatusCodePagesWithReExecute("/StatusCode/{0}");

// Enable CORS Middleware
app.UseCors(AdvWorksAPIConstants.CORS_POLICY);

//*********************************************
// Create Minimal API Endpoints by
// Adding Routes from All Router Classes
// Run the Application
//*********************************************
using (var scope = app.Services.CreateScope()) {
  var services = scope.ServiceProvider.GetServices<RouterBase>();
  // Loop through each RouterBase class
  foreach (var item in services) {
    // Invoke the AddRoutes() method to add the routes
    item.AddRoutes(app);
  }

  // Run the Application
  app.Run();
}
