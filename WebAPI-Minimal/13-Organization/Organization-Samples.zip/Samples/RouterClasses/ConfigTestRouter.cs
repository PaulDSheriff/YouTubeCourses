﻿using AdvWorksAPI.BaseClasses;
using AdvWorksAPI.EntityLayer;

namespace AdvWorksAPI.RouterClasses;

public class ConfigTestRouter : RouterBase
{
  public ConfigTestRouter(ILogger<ConfigTestRouter> logger) : base(logger)
  {
    UrlFragment = "api/ConfigTest";
    TagName = "ConfigTest";
  }

  /// <summary>
  /// Add routes
  /// </summary>
  /// <param name="app">A WebApplication object</param>
  public override void AddRoutes(WebApplication app)
  {
    app.MapGet($"/{UrlFragment}/IConfigurationTest", (IConfiguration config)
      => Results.Ok(config["AdvWorksAPI:InfoMessageDefault"]))
        .WithTags(TagName)
        .Produces(200);

    app.MapGet($"/{UrlFragment}/InjectDefaults", (AdvWorksAPIDefaults settings) =>
    {
      settings.InfoMessageDefault = settings.InfoMessageDefault
          .Replace("{Verb}", "GET")
          .Replace("{ClassName}", "ConfigTestRouter");

      return Results.Ok(settings);
    })
    .WithTags(TagName)
    .Produces(200)
    .Produces<AdvWorksAPIDefaults>();

    app.MapGet($"/{UrlFragment}/AssignToClass", (IConfiguration config) =>
    {
      AdvWorksAPIDefaults settings;

      settings = config.GetRequiredSection("AdvWorksAPI")
      .Get<AdvWorksAPIDefaults>();

      return Results.Ok(settings);
    })
    .WithTags(TagName)
    .Produces(200)
    .Produces<AdvWorksAPIDefaults>();

    app.MapGet($"/{UrlFragment}/SetProperties", (IConfiguration config) =>
    {
      AdvWorksAPIDefaults settings = new()
      {
        InfoMessageDefault = config["AdvWorksAPI:InfoMessageDefault"] ?? string.Empty,
        ProductCategoryID = Convert.ToInt32(config["AdvWorksAPI:ProductCategoryID"]),
        ProductModelID = Convert.ToInt32(config["AdvWorksAPI:ProductModelID"])
      };

      return Results.Ok(settings);
    })
    .WithTags(TagName)
    .Produces(200)
    .Produces<AdvWorksAPIDefaults>();
  }
}
