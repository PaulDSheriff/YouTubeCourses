﻿using AdvWorksAPI.EntityLayer;

namespace AdvWorksAPI.ExtensionClasses
{
  public static class WebApplicationBuilderExtensions
  {
    public static void ConfigureGlobalSettings(this WebApplicationBuilder builder)
    {
      // Configure Global Settings
      builder.Services.AddSingleton<AdvWorksAPIDefaults, AdvWorksAPIDefaults>();

      // Read "AdvWorksAPI" section
      // Use the IOptionsMonitor<AdvWorksAPIDefaults> in controller's constructor
      builder.Services.Configure<AdvWorksAPIDefaults>(builder.Configuration.GetSection("AdvWorksAPI"));
    }
  }
}
