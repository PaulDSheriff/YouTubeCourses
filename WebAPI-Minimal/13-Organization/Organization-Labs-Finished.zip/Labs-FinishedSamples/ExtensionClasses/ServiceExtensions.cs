﻿using AdvWorksAPI.ConstantClasses;
using AdvWorksAPI.EntityLayer;
using AdvWorksAPI.Interfaces;
using AdvWorksAPI.RepositoryLayer;
using AdvWorksAPI.RouterClasses;
using Microsoft.AspNetCore.Http.Json;

namespace AdvWorksAPI.ExtensionClasses;

public static class ServiceExtension
{
  public static void AddRepositoryClasses(this IServiceCollection services)
  {
    // Add Repository Classes
    services.AddScoped<IRepository<Customer>, CustomerRepository>();
  }

  public static void AddRouterClasses(this IServiceCollection services)
  {
    // Add "Router" classes as a service
    services.AddScoped<RouterBase, CustomerRouter>();
    services.AddScoped<RouterBase, SettingsRouter>();
    services.AddScoped<RouterBase, LogTestRouter>();
    services.AddScoped<RouterBase, ErrorRouter>();
  }

  public static IServiceCollection ConfigureCors(this IServiceCollection services)
  {
    // Add CORS
    return services.AddCors(options =>
    {
      options.AddPolicy(AdvWorksAPIConstants.CORS_POLICY,
        builder =>
        {
          builder.WithOrigins("http://localhost:5081");
        });
    });
  }

  public static IServiceCollection ConfigureJsonOptions(this IServiceCollection services)
  {
    // Add CORS
    return services.Configure<JsonOptions>(options =>
    {
      // Set property names to PascalCase
      options.SerializerOptions.PropertyNamingPolicy = null;
      // Ignore "readonly" fields
      options.SerializerOptions.IgnoreReadOnlyProperties = true;
    });
  }
}
