﻿namespace OOPLab;

public abstract class Person : IPerson {
  public virtual void Init() {
    FirstName = string.Empty;
    LastName = string.Empty;
  }

  public string FirstName { get; set; }
  public string LastName { get; set; }
  public int Age { get; set; }
  protected DateTime LastModified { get; set; }

  public abstract string ContactInfo();

  public virtual string GetInfo() {
    return $"{LastName}, {FirstName} Age = {Age}";
  }

  public virtual string FullName() {
    return $"{LastName}, {FirstName}";
  }

  public override string ToString() {
    return FullName();
  }
}
