﻿using OOPLab;

//* Using a List<Customer> *//
CustomerRepository repo = new();

List<Customer> customers = repo.GetCustomers(Directory.GetCurrentDirectory() + "\\Customers.tsv");

foreach (Customer cust in customers) {
  Console.WriteLine(cust);
}


//* Find a Specific Customer *//
//CustomerRepository repo = new();

//List<Customer> customers = repo.GetCustomers(Directory.GetCurrentDirectory() + "\\Customers.tsv");

//Customer entity = customers.Find(row => row.CustomerId == 2);
//Console.WriteLine();
//Console.WriteLine(entity);


//* Extract a Subset of Customers *//
//CustomerRepository repo = new();

//List<Customer> customers = repo.GetCustomers(Directory.GetCurrentDirectory() + "\\Customers.tsv");

//Console.WriteLine();
//foreach (Customer cust in customers.Where(row => row.CompanyName.Contains("Bike"))) {
//  Console.WriteLine(cust);
//}
