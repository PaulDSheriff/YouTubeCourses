﻿using CSharpSamples;

//* Array Sample *//
//Product[] products = {
//  new() {
//    ProductId = 1,
//    Name = "Bike Helmet"
//  }, new() {
//    ProductId = 2,
//    Name = "Brake Pads"
//  }, new() {
//    ProductId = 3,
//    Name = "Bike Gloves"
//  }
//};

//foreach (Product item in products) {
//  Console.WriteLine(item);
//}

//* List<Product> Sample *//
List<Product> products = new() {
  new() {
    ProductId = 1,
    Name = "Bike Helmet"
  }, new() {
    ProductId = 2,
    Name = "Brake Pads"
  }, new() {
    ProductId = 3,
    Name = "Bike Gloves"
  }
};

// Adding Products
products.Add(new() {
  ProductId = 4,
  Name = "Handlebars"
});

products.Insert(2, new() {
  ProductId = 5,
  Name = "Pedals"
});

products.AddRange(new List<Product>() {
  new() {
    ProductId = 6,
    Name = "Long Sleeve Jersey"
  }, new() {
    ProductId = 7,
    Name = "Black T-Shirt"
  }, new() {
    ProductId = 8,
    Name = "27in. Bike Frame"
  }
});

// Remove products
//products.Remove(products[1]);
//products.RemoveAt(1);
//products.RemoveRange(1, 2);

Console.WriteLine(products.Count);
foreach (Product item in products) {
  Console.WriteLine(item);
}

// Find a specific entity in collection
//Product entity = products.Find(row => row.ProductId == 2);
Product entity = products.Find(row => row.Name.Contains("Bike"));
Console.WriteLine();
Console.WriteLine(entity);

// Get a Subset of Data
Console.WriteLine();
foreach (Product prod in products.Where(row => row.Name.Contains("Bike"))) {
  Console.WriteLine(prod);
}
