#nullable disable

using System.Globalization;

namespace Common.Library;

/// <summary>
/// A class for helping you work with Dates.
/// </summary>
public static class DateHelper
{ 
  /// <summary>
  /// Returns the first day of the month for the date value passed in.
  /// </summary>
  /// <param name="value">A Date Value</param>
  /// <returns>DateTime</returns>
  public static DateTime MonthStart(DateTime value)
  {
    return new DateTime(value.Year, value.Month, 1, 0, 0, 0, 0, CultureInfo.CurrentCulture.Calendar);
  }

  /// <summary>
  /// Returns the last day of the month for the date value passed in.
  /// </summary>
  /// <param name="value">A Date Value</param>
  /// <returns>DateTime</returns>
  public static DateTime MonthEnd(DateTime value)
  {
    int lastDay;
    DateTime dt;

    lastDay = DateTime.DaysInMonth(value.Year, value.Month);

    dt = new DateTime(value.Year, value.Month, lastDay, 12, 59, 59, 0, CultureInfo.CurrentCulture.Calendar);

    return dt;
  }

  /// <summary>
  /// Returns a Date that is the first day of the quarter for the given date value passed in.
  /// </summary>
  /// <param name="value">A Date Value</param>
  /// <returns>DateTime</returns>
  public static DateTime QuarterStart(DateTime value)
  {
    DateTime dt = DateTime.MinValue;

    switch (value.Month) {
      case 1:
      case 2:
      case 3:
        dt = new DateTime(value.Year, 1, 1, value.Hour, value.Minute, value.Second, value.Millisecond, CultureInfo.CurrentCulture.Calendar);
        break;
      case 4:
      case 5:
      case 6:
        dt = new DateTime(value.Year, 4, 1, value.Hour, value.Minute, value.Second, value.Millisecond, CultureInfo.CurrentCulture.Calendar);
        break;
      case 7:
      case 8:
      case 9:
        dt = new DateTime(value.Year, 7, 1, value.Hour, value.Minute, value.Second, value.Millisecond, CultureInfo.CurrentCulture.Calendar);
        break;
      case 10:
      case 11:
      case 12:
        dt = new DateTime(value.Year, 10, 1, value.Hour, value.Minute, value.Second, value.Millisecond, CultureInfo.CurrentCulture.Calendar);
        break;

      default:
        break;
    }

    return dt;
  }

  /// <summary>
  /// Returns a Date that is the last day of the quarter for the given date value passed in.
  /// </summary>
  /// <param name="value">A Date Value</param>
  /// <returns>DataTime</returns>
  public static DateTime QuarterEnd(DateTime value)
  {
    DateTime dt = DateTime.MinValue;

    switch (value.Month) {
      case 1:
      case 2:
      case 3:
        dt = new DateTime(value.Year, 3, 31, value.Hour, value.Minute, value.Second, value.Millisecond, CultureInfo.CurrentCulture.Calendar);
        break;
      case 4:
      case 5:
      case 6:
        dt = new DateTime(value.Year, 6, 30, value.Hour, value.Minute, value.Second, value.Millisecond, CultureInfo.CurrentCulture.Calendar);
        break;
      case 7:
      case 8:
      case 9:
        dt = new DateTime(value.Year, 9, 30, value.Hour, value.Minute, value.Second, value.Millisecond, CultureInfo.CurrentCulture.Calendar);
        break;
      case 10:
      case 11:
      case 12:
        dt = new DateTime(value.Year, 12, 31, value.Hour, value.Minute, value.Second, value.Millisecond, CultureInfo.CurrentCulture.Calendar);
        break;

      default:
        break;
    }

    return dt;
  }

  /// <summary>
  /// Returns the first day of the year for the given date passed in.
  /// </summary>
  /// <param name="value">A Date Value</param>
  /// <returns>DateTime</returns>
  public static DateTime YearStart(DateTime value)
  {
    DateTime dt;

    dt = new DateTime(value.Year, 1, 1, value.Hour, value.Minute, value.Second, value.Millisecond, CultureInfo.CurrentCulture.Calendar);

    return dt;
  }

  /// <summary>
  /// Returns the last day of the year for the given date value passed in.
  /// </summary>
  /// <param name="value">DateTime</param>
  /// <returns>DateTime</returns>
  public static DateTime YearEnd(DateTime value)
  {
    DateTime dt;

    dt = new DateTime(value.Year, 12, 31, value.Hour, value.Minute, value.Second, value.Millisecond, CultureInfo.CurrentCulture.Calendar);

    return dt;
  }

  /// <summary>
  /// Returns the number of the quarter that the given date falls within.
  /// </summary>
  /// <param name="value">A Date Value</param>
  /// <returns>DateTime</returns>
  public static int GetQuarter(DateTime value)
  {
    // Get the current month
    int ret = 1;

    switch (value.Month) {
      case 1:
      case 2:
      case 3:
        ret = 1;
        break;

      case 4:
      case 5:
      case 6:
        ret = 2;
        break;

      case 7:
      case 8:
      case 9:
        ret = 3;
        break;

      case 10:
      case 11:
      case 12:
        ret = 4;
        break;

      default:
        break;
    }

    return ret;
  }

  /// <summary>
  /// Returns True if the string value passed in is a valid date.
  /// </summary>
  /// <param name="value">A string to be test</param>
  /// <returns>boolean</returns>
  public static bool IsADate(string value)
  {
    bool ret;

    ret = DateTime.TryParse(value, out _);

    return ret;
  }

  /// <summary>
  /// Returns True if the string value passed in is a valid date. This method also allows you to pass in a format such as "yyyyMMdd".
  /// This method does use the CurrentCulture and assumes that your date passed in is in a local format.
  /// </summary>
  /// <param name="value">The date to test</param>
  /// <param name="dateFormat">A valid date format string such as "yyyyMMdd" that the 'value' parameter is in</param>
  /// <returns>True or False</returns>
  public static bool IsADate(string value, string dateFormat)
  {
    bool ret;

    ret = DateTime.TryParseExact(value, dateFormat,
      CultureInfo.CurrentCulture, DateTimeStyles.AssumeLocal, out _);

    return ret;
  }

  /// <summary>     
  /// Returns the age of a person in years based on today's date and the birthdate passed in
  /// </summary>     
  /// <param name="birthDate">The date of birth</param>     
  /// <returns>The age in years. If the birth date passed in is a future date, then zero is returned</returns>     
  public static int Age(DateTime birthDate)
  {
    return Age(birthDate, DateTime.Today);
  }

  /// <summary>     
  /// Calculates the age in years of the current System.DateTime object as of later date.     
  /// </summary>     
  /// <param name="birthDate">The date of birth</param>     
  /// <param name="baseDate">The date on which to calculate the age.</param>     
  /// <returns>The age in years</returns>     
  public static int Age(DateTime birthDate, DateTime baseDate)
  {
    int ret;

    ret = baseDate.Year - birthDate.Year;
    if (ret > 0)
      ret -= Convert.ToInt32(baseDate.Date < birthDate.Date.AddYears(ret));
    else
      ret = 0;

    return ret;
  }
}