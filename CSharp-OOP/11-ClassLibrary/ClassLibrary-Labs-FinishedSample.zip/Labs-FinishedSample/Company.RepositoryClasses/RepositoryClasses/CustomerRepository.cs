﻿using Common.Library.HelperClasses;
using Common.Library.Interfaces;
using Company.EntityClasses.EntityClasses;
using Company.EntityClasses.EventArgsClasses;
using System.Collections;

namespace Company.RepositoryClasses.RepositoryClasses;

public class CustomerRepository : IRepository<Customer> {

    public event EventHandler<CustomerEventArgs> CustomerProcessed;

    public List<Customer> GetCustomers(string fileName) {
        List<Customer> ret = null;

        try {
            string[] lines = FileHelper.ReadAllLines(fileName);
            ret = ProcessCustomerLines(lines);
        }
        catch (FileNotFoundException ex) {
            Console.WriteLine(ex.ToString());
        }
        catch (Exception ex) {
            Console.WriteLine(ex.ToString());
        }

        return ret;
    }

    private List<Customer> ProcessCustomerLines(string[] lines) {
        List<Customer> ret = new();

        foreach (string item in lines) {
            string[] entity = item.Split('\t');

            Customer cust = new() {
                CustomerId = Convert.ToInt32(entity[0]),
                FirstName = entity[1],
                LastName = entity[2],
                CompanyName = entity[3]
            };
            ret.Add(cust);

            CustomerProcessed?.Invoke(this,
              new() {
                  CustomerObject = cust
              });
        }

        return ret;
    }

    protected Customer Save(Customer entity, bool isAdding) {
        if (isAdding) {
            // TODO: Write Code to Insert an Entity Here
        }
        else {
            // TODO: Write Code to Update an Entity Here
        }

        return entity;
    }

    public Customer Insert(Customer entity) {
        return Save(entity, true);
    }

    public Customer Update(Customer entity) {
        return Save(entity, false);
    }

    public bool Delete(int id) {
        return true;
    }
}
