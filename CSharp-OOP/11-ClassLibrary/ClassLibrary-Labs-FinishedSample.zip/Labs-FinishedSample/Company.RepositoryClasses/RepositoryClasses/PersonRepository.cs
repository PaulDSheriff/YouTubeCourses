﻿using Common.Library.Interfaces;
using Company.EntityClasses.EntityClasses;

namespace Company.RepositoryClasses.RepositoryClasses;

public class PersonRepository : IRepository<Person> {
    public Person Insert(Person entity) {
        return Save(entity, true);
    }

    public Person Update(Person entity) {
        return Save(entity, false);
    }

    protected Person Save(Person entity, bool isAdding) {
        if (isAdding) {
            // TODO: Write Code to Insert an Entity Here
        }
        else {
            // TODO: Write Code to Update an Entity Here
        }

        return entity;
    }

    public bool Delete(int id) {
        return true;
    }
}
