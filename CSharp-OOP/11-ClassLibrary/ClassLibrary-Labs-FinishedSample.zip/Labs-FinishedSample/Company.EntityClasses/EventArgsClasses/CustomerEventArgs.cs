﻿using Company.EntityClasses.EntityClasses;

namespace Company.EntityClasses.EventArgsClasses;

public class CustomerEventArgs : EventArgs {
    public Customer CustomerObject { get; set; }
}
