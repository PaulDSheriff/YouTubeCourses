﻿namespace Common.Library.HelperClasses;

public static class FileHelper {
    public static string[] ReadAllLines(string fileName) {
        string[] ret;

        if (File.Exists(fileName)) {
            // Attempt to read all lines in the file
            ret = File.ReadAllLines(fileName);
        }
        else {
            throw new FileNotFoundException($"The file '{fileName}' does not exist.");
        }

        return ret;
    }
}
