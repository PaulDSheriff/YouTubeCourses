namespace Common.Library;

public interface IRepository<TEntity>
{
  TEntity Get(int id);
  TEntity CreateEmpty();
  TEntity Insert(TEntity entity);
  TEntity Update(TEntity entity);
  bool Delete(int id);
}