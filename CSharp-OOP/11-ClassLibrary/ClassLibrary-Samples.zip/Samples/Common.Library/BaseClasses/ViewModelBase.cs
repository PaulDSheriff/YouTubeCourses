namespace Common.Library;

public class ViewModelBase {
  #region Constructor
  public ViewModelBase() {
    Init();
  }
  #endregion

  /// <summary>
  /// Is Detail or Search/List page displayed
  /// </summary>
  public bool IsDetailVisible { get; set; }
  /// <summary>
  /// Get/Set if the user is adding or editing a record
  /// </summary>
  public bool IsAdding { get; set; }
  /// <summary>
  /// Get/Set total number of rows returned from the last query
  /// </summary>
  public int TotalRows { get; set; }

  public virtual void Init() {
  }
}