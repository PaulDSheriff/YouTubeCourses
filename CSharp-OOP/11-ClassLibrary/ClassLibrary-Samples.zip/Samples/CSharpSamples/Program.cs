﻿using Common.Library;

//* DateHelper Class *//
Console.WriteLine(DateHelper.GetQuarter(DateTime.Now));
Console.WriteLine();

//* PhoneHelper Class *//
string phoneParens = "(615) 999-9999";
string phoneDashes = "615-999-9999";
string phone = "6159999999";

Console.WriteLine(PhoneHelper.CreateUSPhoneNumberWithDashes(phoneParens));
Console.WriteLine(PhoneHelper.CreateUSPhoneNumberWithParens(phoneDashes));
Console.WriteLine();
Console.WriteLine(PhoneHelper.CreateUSPhoneNumberWithDashes(phone));
Console.WriteLine(PhoneHelper.CreateUSPhoneNumberWithParens(phone));
