﻿using OOPLab;

Customer entity = new() {
  CustomerId = 1,
  FirstName = "John",
  LastName = "Smith",
  CompanyName = "Smith, Inc.",
  EmailAddress = "John.Smith@smithinc.com"
};

Console.Write(entity.CustomerId);
Console.Write(" - ");
Console.Write(entity.FirstName);
Console.Write(" ");
Console.WriteLine(entity.LastName);
Console.WriteLine(entity.CompanyName);
Console.WriteLine(entity.EmailAddress);
