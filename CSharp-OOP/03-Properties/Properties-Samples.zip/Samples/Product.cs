﻿namespace CSharpSamples {
  public class Product {
    public int ProductId { get; set; }
    public string Name { get; set; }

    // Alternate syntax for Name property
    //private string _name;
    //public string Name
    //{
    //  get => _name;
    //  set => _name = value;
    //}

    private decimal _StandardCost;

    public decimal StandardCost
    {
      get { return _StandardCost; }
      set { _StandardCost = value;
        _Profit = _ListPrice - StandardCost;
      }
    }

    private decimal _ListPrice;

    public decimal ListPrice
    {
      get { return _ListPrice; }
      set
      {
        _ListPrice = value;
        _Profit = _ListPrice - StandardCost;
      }
    }

    private decimal _Profit;
    public decimal Profit { get { return _Profit; } }

    // Alternate definition of Profit
    // public decimal Profit => _ListPrice – StandardCost;
  }
}
