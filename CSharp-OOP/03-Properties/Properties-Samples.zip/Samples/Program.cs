﻿using CSharpSamples;

Product entity = new() {
  ProductId = 1,
  Name = "Helmet",
  StandardCost = 2.99M,
  ListPrice = 6.99M
};

Console.Write(entity.ProductId);
Console.Write(" - ");
Console.WriteLine(entity.Name);
Console.WriteLine(entity.StandardCost);
Console.WriteLine(entity.ListPrice);
Console.WriteLine("Profit: " + entity.Profit.ToString("c"));