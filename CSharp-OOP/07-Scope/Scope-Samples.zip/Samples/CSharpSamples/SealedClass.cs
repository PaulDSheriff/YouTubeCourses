﻿namespace CSharpSamples;

public sealed class SealedClass {
  public int SealedId { get; set; }
  public string Name { get; set; }
}
