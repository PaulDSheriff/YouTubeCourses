﻿namespace CSharpSamples;

public abstract class Person : IPerson {
  public string FirstName { get; set; }
  public string LastName { get; set; }
  public int Age { get; set; }

  public abstract string ContactInfo();

  public virtual string GetInfo() {
    return $"{LastName}, {FirstName} Age = {Age}";
  }

  public override string ToString() {
    return $"{LastName}, {FirstName}";
  }
}