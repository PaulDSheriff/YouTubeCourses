﻿namespace CSharpSamples;

public class Bicycle : Product {
  public string HandlebarStyle { get; set; }

  public void CheckVariables() {
    // Can access _Profit here because it is protected
    _Profit = 10000M;
    // Can access this method because it is protected
    CalculateProfit(ListPrice, StandardCost);
  }
}
