﻿namespace CSharpSamples;

public class Product {
  public Product() {
    Init();
  }

  public Product(int id, string name) {
    ProductId = id;
    Name = name;

    Init();
  }

  public void Init() {
    Color = DEFAULT_COLOR;
    StandardCost = 1.00M;
    ListPrice = 5.00M;
    SellStartDate = DateTime.Now;
  }

  private const string DEFAULT_COLOR = "Black";

  public int ProductId { get; set; }
  public string Name { get; set; }
  public string Color { get; set; }

  private decimal _StandardCost;

  public decimal StandardCost
  {
    get { return _StandardCost; }
    set
    {      
      _StandardCost = value;
      CalculateProfit();
    }
  }

  private decimal _ListPrice;

  public decimal ListPrice
  {
    get { return _ListPrice; }
    set
    {
      _ListPrice = value;
      CalculateProfit();
    }
  }

  protected decimal _Profit;
  public decimal Profit { get { return _Profit; } }

  // Alternate syntax for a read-only property
  //public decimal Profit => _ListPrice – StandardCost;
  public DateTime SellStartDate { get; set; }
  public DateTime SellEndDate { get; set; }

  private void CalculateProfit() {
    _Profit = _ListPrice - StandardCost;
  }

  public int GetNumberOfSellDays() {
    return (SellEndDate - SellStartDate).Days;
  }

  protected decimal CalculateProfit(decimal price, decimal cost) {
    return price - cost;
  }

  public decimal CalculateProfitByVal(decimal price, decimal cost) {
    price = 20;
    cost = 5;

    return price - cost;
  }

  public static decimal CalculateProfitByRef(ref decimal price, ref decimal cost) {
    price = 20;
    cost = 5;

    return price - cost;
  }

  public void TrialIncreaseByPercentage(decimal percent, out decimal price, out decimal cost) {
    // Must initialize out parameters
    price = ListPrice;
    cost = StandardCost;

    // Now set them to whatever you want
    price *= percent;
    cost *= percent;
  }

}
