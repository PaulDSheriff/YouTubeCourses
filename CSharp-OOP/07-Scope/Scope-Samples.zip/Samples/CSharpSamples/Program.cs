﻿using CSharpSamples;

//* Block-Level Scope - DOESN'T WORK *//
//for (int index = 1; index <= 10; index++) {
//  Console.WriteLine(index);
//}

//Console.WriteLine(index);  // 'index' is NOT available


//* Block-Level Scope - DOES WORK *//
//int index = 1;

//for (; index < 10; index++) {
//  Console.WriteLine(index);
//}

//Console.WriteLine(index);  // 'index' is available

//* Block-Level Scope - Inside if Block *//
//for (int index = 1; index < 10; index++) {
//  Console.WriteLine(index);
//  if (index % 2 == 0) {
//    string name = "Loop = " + index;
//    Console.WriteLine(name);
//  }
//  //Console.WriteLine(name);  // 'name' is NOT available
//}

//* Static Methods *//
//decimal price = 10.00M;
//decimal cost = 15.00M;

//Product.CalculateProfitByRef(ref price, ref cost);

//Console.WriteLine(price);
//Console.WriteLine(cost);

//* Static Class PhoneHelper *//
string phoneParens = "(615) 999-9999";
string phoneDashes = "615-999-9999";
string phone = "6159999999";

Console.WriteLine(PhoneHelper.CreateUSPhoneNumberWithDashes(phoneParens));
Console.WriteLine(PhoneHelper.CreateUSPhoneNumberWithParens(phoneDashes));
Console.WriteLine();
Console.WriteLine(PhoneHelper.CreateUSPhoneNumberWithDashes(phone));
Console.WriteLine(PhoneHelper.CreateUSPhoneNumberWithParens(phone));
