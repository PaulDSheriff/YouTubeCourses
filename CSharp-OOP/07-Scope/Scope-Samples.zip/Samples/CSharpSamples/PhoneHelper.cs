﻿namespace CSharpSamples;

/// <summary>
/// This class has methods to help you work with phone numbers.
/// </summary>
public static class PhoneHelper {
  /// <summary>
  /// Pass in a phone number and this method strips out all other formatting and returns nnn-nnn-nnnn format.
  /// </summary>
  /// <param name="phone">The phone to check</param>
  /// <returns>A phone number in nnn-nnn-nnnn format</returns>
  public static string CreateUSPhoneNumberWithDashes(string phone) {
    string value = phone.Replace("(", "").Replace(")", "").Replace(" ", "").Replace("-", "").Replace(".", "");

    if (value.Length == 10) {
      phone = value[..3] + "-" + value.Substring(3, 3) + "-" + value[6..];
    }

    return phone;
  }

  /// <summary>
  /// Pass in a phone number and this method strips out all other formatting and returns (nnn) nnn-nnnn format.
  /// </summary>
  /// <param name="phone">The phone to check</param>
  /// <returns>A phone number in (nnn) nnn-nnnn format</returns>
  public static string CreateUSPhoneNumberWithParens(string phone) {
    string value = phone.Replace("(", "").Replace(")", "").Replace(" ", "").Replace("-", "").Replace(".", "");

    if (value.Length == 10) {
      phone = "(" + value[..3] + ") " + value.Substring(3, 3) + "-" + value[6..];
    }

    return phone;
  }
}