﻿using CSharpSamples;

namespace Common.Library;

public partial class Clothing : Product {
  public void CheckVariables() {
    base._Profit = 100m;

    Clothing entity = new() {
      Size = "Lg"
    };
  }
}