﻿namespace Common.Library;

public partial class Clothing {
  public string Size { get; set; }
}
