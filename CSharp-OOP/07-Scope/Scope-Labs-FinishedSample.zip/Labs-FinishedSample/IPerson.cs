﻿namespace OOPLab;

public interface IPerson {
  public string FirstName { get; set; }
  public string LastName { get; set; }

  public abstract Person Insert(Person entity);
  public abstract Person Update(Person entity);

  public abstract string FullName();
  public abstract string GetInfo();
  public abstract string ContactInfo();
}
