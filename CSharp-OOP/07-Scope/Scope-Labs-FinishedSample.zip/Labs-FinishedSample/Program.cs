﻿using OOPLab;

Customer entity = new();

string[] lines = entity.GetCustomers( Directory.GetCurrentDirectory() + "\\Customers.tsv");
foreach (string line in lines) {
  Console.WriteLine(line);
}
