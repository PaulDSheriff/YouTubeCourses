﻿namespace OOPLab;

public class Customer : Person {
  public Customer() {
    Init();
  }

  public Customer(int id, decimal limit) {
    Init();

    CustomerId = id;
    _CreditLimit = limit;
  }

  public override void Init() {
    base.Init();

    CustomerId = 1;
    CompanyName = string.Empty;
    EmailAddress = string.Empty;
    _CreditLimit = 50000;
  }

  public int CustomerId { get; set; }

  private string _CompanyName;

  public string CompanyName
  {
    get { return _CompanyName; }
    set { _CompanyName = value; }
  }

  private string _EmailAddress;

  public string EmailAddress
  {
    get { return _EmailAddress; }
    set { _EmailAddress = value; }
  }

  private decimal _CreditLimit;

  public decimal CreditLimit
  {
    get { return _CreditLimit; }
  }
  
  public string[] GetCustomers(string fileName) {
    return FileHelper.ReadAllLines(fileName);
  }

  protected Customer Save(Customer entity, bool isAdding) {
    LastModified = DateTime.Now;

    if (isAdding) {
      // TODO: Write Code to Insert an Entity Here
    }
    else {
      // TODO: Write Code to Update an Entity Here
    }

    return entity;
  }

  public Customer Insert(Customer entity) {
    return Save(entity, true);
  }

  public Customer Update(Customer entity) {
    return Save(entity, false);
  }

  public override string FullName() {
    return $"{CompanyName}: {LastName}, {FirstName}";
  }

  public void SetCreditLimit(decimal limit) {
    _CreditLimit = limit;
  }

  public override string ContactInfo() {
    return GetInfo();
  }

  public override string GetInfo() {
    return $"Customer ID: {CustomerId}: {base.GetInfo()} - Email Address = {EmailAddress}";
  }

  public override string ToString() {
    return $"Customer ID: {CustomerId} - {FullName()}";
  }
}