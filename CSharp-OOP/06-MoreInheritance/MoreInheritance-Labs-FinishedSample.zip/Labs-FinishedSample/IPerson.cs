﻿namespace OOPLab;

public interface IPerson {
  public string FirstName { get; set; }
  public string LastName { get; set; }

  public abstract string FullName();
  public abstract string GetInfo();
  public abstract string ContactInfo();
}
