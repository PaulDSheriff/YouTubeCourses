﻿using OOPLab;

Customer entity = new() {
  CustomerId = 1,
  FirstName = "John",
  LastName = "Smith",
  Age = 50,
  EmailAddress = "John@smithco.com"
};

Console.WriteLine(entity.GetInfo());
