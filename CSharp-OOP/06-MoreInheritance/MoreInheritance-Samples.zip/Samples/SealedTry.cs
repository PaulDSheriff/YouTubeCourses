﻿namespace CSharpSamples;

//public class SealedTry : SealedClass {
//}
