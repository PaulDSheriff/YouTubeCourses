﻿namespace CSharpSamples;

public class Customer : Person {
  public int CustomerId { get; set; }
  public string CompanyName { get; set; }
  public string EmailAddress { get; set; }

  public override string ContactInfo() {
    return GetInfo();
  }

  public override string GetInfo() {
    return $"Customer ID: {CustomerId}: {base.GetInfo()} - Email Address = {EmailAddress}";
  }

  public override string ToString() {
    return GetInfo();
  }
}
