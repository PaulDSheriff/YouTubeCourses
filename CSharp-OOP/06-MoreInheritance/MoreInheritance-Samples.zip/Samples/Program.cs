﻿using CSharpSamples;

//* Can't Instantiate a Person Class *//
//Person entity = new();

//* Customer Class Demo *//
//Customer entity = new() {
//  FirstName = "John",
//  LastName = "Smith",
//  Age = 22,
//  CustomerId = 1,
//  EmailAddress = "John@smithco.com"
//};

//Console.WriteLine(entity.GetInfo());

//* Employee Class Demo *//
Employee entity = new() {
  FirstName = "John",
  LastName = "Smith",
  Age = 22,
  EmployeeId = 1,
  Salary = 100000M
};

Console.WriteLine(entity.GetInfo());