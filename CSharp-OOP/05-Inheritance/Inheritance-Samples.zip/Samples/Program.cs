﻿using CSharpSamples;

//* Person Class *//
//Person entity = new() {
//  FirstName = "John",
//  LastName = "Smith",
//  Age = 22
//};

//Console.WriteLine($"{entity.LastName}, {entity.FirstName}");

//* Employee Class *//
//Employee entity = new() {
//  FirstName = "John",
//  LastName = "Smith",
//  Age = 22,
//  EmployeeId = 1,
//  Salary = 100000m
//};

////Console.WriteLine($"{entity.LastName}, {entity.FirstName}");
////Console.WriteLine($"{entity.EmployeeId} - {entity.Salary:c}");
//Console.WriteLine(entity.GetInfo());

//* Customer Class *//
Customer entity = new() {
  FirstName = "John",
  LastName = "Smith",
  Age = 22,
  CustomerId = 1,
  EmailAddress = "John@smithco.com"
};

Console.WriteLine(entity.GetInfo());
