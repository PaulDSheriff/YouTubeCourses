﻿namespace CSharpSamples;

public class Employee : Person {
  public int EmployeeId { get; set; }
  public decimal Salary { get; set; }

  public override string GetInfo() {
    return $"Employee ID: {EmployeeId}: {base.GetInfo()} - Salary = {Salary:c}";
  }

  public override string ToString() {
    string ret = base.ToString();

    return $"{ret}{Environment.NewLine}{EmployeeId} - {Salary:c}";
  }
}
