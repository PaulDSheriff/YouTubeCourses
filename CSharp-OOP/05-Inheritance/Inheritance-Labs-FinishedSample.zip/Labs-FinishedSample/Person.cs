﻿namespace OOPLab;

public class Person {
  public virtual void Init() {
    FirstName = string.Empty;
    LastName = string.Empty;
  }

  public string FirstName { get; set; }
  public string LastName { get; set; }
  public int Age { get; set; }

  public virtual string FullName() {
    return $"{LastName}, {FirstName}";
  }

  public override string ToString() {
    return FullName();
  }
}
