﻿namespace OOPLab;

public interface IRepository<TEntity> {
  TEntity Insert(TEntity entity);
  TEntity Update(TEntity entity);
  bool Delete(int id);
}
