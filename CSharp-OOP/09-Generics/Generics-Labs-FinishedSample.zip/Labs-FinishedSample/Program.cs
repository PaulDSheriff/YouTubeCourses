﻿using OOPLab;

CustomerRepository repo = new();
Customer entity = new();

repo.CustomerProcessed += Repo_CustomerProcessed;

void Repo_CustomerProcessed(object sender, CustomerEventArgs e) {
  Console.WriteLine(e.CustomerObject);
}

Customer[] customers =
  repo.GetCustomers(Directory.GetCurrentDirectory()
    + "\\Customers.tsv");
