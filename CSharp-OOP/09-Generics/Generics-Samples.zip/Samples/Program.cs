﻿using CSharpSamples;

//* Individual Methods Class *//
//object value = 100;
////object value = DBNull.Value;

//Console.WriteLine(IndividualMethods.ConvertToInt(value, 0));
//Console.WriteLine(IndividualMethods.ConvertToDecimal(value, 0));
//Console.WriteLine(IndividualMethods.ConvertToString(value, "0"));
//Console.WriteLine(IndividualMethods.ConvertToBoolean(value, false));

//* Generic Method Class *//
//object value = 100;
////object value = DBNull.Value;

//Console.WriteLine(GenericMethods.ConvertTo<int>(value, 0));
//Console.WriteLine(GenericMethods.ConvertTo<decimal>(value, 0));
//Console.WriteLine(GenericMethods.ConvertTo<string>(value, "0"));
//Console.WriteLine(GenericMethods.ConvertTo<bool>(value, false));

//* Storage Repository Class: String *//
//StorageRepository<string> repo = new() {
//  Entity = "This is the data to store"
//};

//Console.WriteLine(repo.Entity);

//* Storage Repository Class: Product Class *//
Product entity = new() {
  ProductId = 1,
  Name = "Bike Helmet"
};

StorageRepository<Product> repo = new();

repo.Insert(entity);

Console.WriteLine(repo.Entity.ProductId);
Console.WriteLine(repo.Entity.Name);
