﻿namespace CSharpSamples;

public static class GenericMethods {
  public static T ConvertTo<T>(object value, T defaultValue) {
    if (value == null || value.Equals(DBNull.Value))
      return (T)Convert.ChangeType(defaultValue, typeof(T));
    else
      return (T)Convert.ChangeType(value, typeof(T));
  }
}