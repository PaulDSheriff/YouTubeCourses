﻿namespace CSharpSamples;

public class StorageRepository<T> {
  public T Entity { get; set; }

  public T Insert(T entity) {
    Entity = entity;

    // TODO: Insert data into data store here

    return entity;
  }
}
