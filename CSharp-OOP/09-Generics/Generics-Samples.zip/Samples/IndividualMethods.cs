﻿namespace CSharpSamples;

public static class IndividualMethods {
  public static int ConvertToInt(object value, int defaultValue) {
    if (value == null || value.Equals(DBNull.Value))
      return Convert.ToInt32(defaultValue);
    else
      return Convert.ToInt32(value);
  }

  public static DateTime ConvertToDateTime(object value, DateTime defaultValue) {
    if (value == null || value.Equals(DBNull.Value))
      return Convert.ToDateTime(defaultValue);
    else
      return Convert.ToDateTime(value);
  }

  public static string ConvertToString(object value, string defaultValue) {
    if (value == null || value.Equals(DBNull.Value))
      return Convert.ToString(defaultValue);
    else
      return Convert.ToString(value);
  }

  public static Decimal ConvertToDecimal(object value, decimal defaultValue) {
    if (value == null || value.Equals(DBNull.Value))
      return Convert.ToDecimal(defaultValue);
    else
      return Convert.ToDecimal(value);
  }

  public static bool ConvertToBoolean(object value, object defaultValue) {
    if (value == null || value.Equals(DBNull.Value))
      return Convert.ToBoolean(defaultValue);
    else
      return Convert.ToBoolean(value);
  }
}
