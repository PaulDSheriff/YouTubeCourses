﻿using CSharpSamples;

//Product entity = new(1, "Helmet") {
//  SellEndDate = DateTime.Now.AddDays(90)
//};

//Console.Write(entity.ProductId);
//Console.Write(" - ");
//Console.WriteLine(entity.Name);
//Console.WriteLine(entity.Color);
//Console.WriteLine(entity.StandardCost);
//Console.WriteLine(entity.ListPrice);
//Console.WriteLine("Profit: " + entity.Profit.ToString("c"));
//Console.WriteLine("Days to Sell: " + entity.GetNumberOfSellDays());
//Console.WriteLine(entity.CalculateProfit(30.99M, 14.36M).ToString("c"));


//* By Value & Reference *//
//Product entity = new();

//decimal price = 30.99M;
//decimal cost = 14.36M;

////Console.WriteLine(entity.CalculateProfitByVal(price, cost).ToString("c"));
//Console.WriteLine(entity.CalculateProfitByRef(ref price, ref cost).ToString("c"));

//Console.WriteLine(price);
//Console.WriteLine(cost);

//* Output Parameters *//
Product entity = new() {
  StandardCost = 10M,
  ListPrice = 100M
};

decimal price = 0M;
decimal cost = 0M;

entity.TrialIncreaseByPercentage(1.1M, out price, out cost);

Console.WriteLine(price);
Console.WriteLine(cost);
