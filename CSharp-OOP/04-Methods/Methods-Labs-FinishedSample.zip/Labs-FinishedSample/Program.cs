﻿using OOPLab;

Customer entity = new(2, 75000) {
  FirstName = "John",
  LastName = "Smith",
  CompanyName = "Smith, Inc.",
  EmailAddress = "John.Smith@smithinc.com"
};

//entity.SetCreditLimit(100000);

Console.Write(entity.CustomerId);
Console.Write(" - ");
Console.Write(entity.FirstName);
Console.Write(" ");
Console.WriteLine(entity.LastName);
Console.WriteLine(entity.CompanyName);
Console.WriteLine(entity.EmailAddress);
Console.WriteLine(entity.CreditLimit.ToString("c"));
Console.WriteLine(entity.FullName());