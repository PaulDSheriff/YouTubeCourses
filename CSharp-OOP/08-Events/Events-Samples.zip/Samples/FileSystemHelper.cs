﻿namespace CSharpSamples;

public class FileSystemHelper {
  public event EventHandler EveryTenFolders;
  public event EventHandler<FileEventArgs> DisplayFile;

  public void LoadAllFolders(string topFolder) {
    int index = 1;
    string[] folders = Directory.GetDirectories(topFolder, "*.*", SearchOption.AllDirectories);

    foreach (string name in folders) {
      if (index % 10 == 0) {
        EveryTenFolders?.Invoke(this, EventArgs.Empty);
      }

      index++;
    }
  }

  public void LoadAllFiles(string topFolder) {
    int index = 1;
    string[] files = Directory.GetFiles(topFolder, "*.docx", SearchOption.AllDirectories);

    foreach (string name in files) {
      DisplayFile?.Invoke(this, new() { FileName = name, FileNumber = index });

      index++;
    }
  }
}
