﻿namespace CSharpSamples;

public class FileEventArgs : EventArgs {
  public string FileName { get; set; }
  public int FileNumber { get; set; }
}
