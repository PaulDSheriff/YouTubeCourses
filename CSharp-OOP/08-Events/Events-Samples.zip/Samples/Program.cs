﻿using CSharpSamples;

//* Folder Event *//
//FileSystemHelper helper = new();
//helper.EveryTenFolders += Helper_EveryTenFolders;
//helper.LoadAllFolders(@"D:\Training\DotNet6");

//void Helper_EveryTenFolders(object sender, EventArgs e) {
//  Console.WriteLine("Ten Files Read");
//}

//* File Event *//
FileSystemHelper helper = new();
helper.DisplayFile += Helper_DisplayFile;
helper.LoadAllFiles(@"D:\Training\DotNet6");

void Helper_DisplayFile(object sender, FileEventArgs e) {
  Console.WriteLine($"{e.FileNumber}: {e.FileName}");
}
