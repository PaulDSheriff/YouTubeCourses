﻿namespace OOPLab;

public class CustomerEventArgs : EventArgs {
  public Customer CustomerObject { get; set; }
}
