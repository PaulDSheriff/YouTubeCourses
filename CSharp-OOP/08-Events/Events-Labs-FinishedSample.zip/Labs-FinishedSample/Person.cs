﻿namespace OOPLab;

public abstract class Person : IPerson {
  public virtual void Init() {
    FirstName = string.Empty;
    LastName = string.Empty;
  }

  public string FirstName { get; set; }
  public string LastName { get; set; }
  public int Age { get; set; }
  protected DateTime LastModified { get; set; }

  public abstract string ContactInfo();

  public virtual string GetInfo() {
    return $"{LastName}, {FirstName} Age = {Age}";
  }

  public virtual string FullName() {
    return $"{LastName}, {FirstName}";
  }

  public Person Insert(Person entity) {
    return Save(entity, true);
  }

  public Person Update(Person entity) {
    return Save(entity, false);
  }

  protected Person Save(Person entity, bool isAdding) {
    LastModified = DateTime.Now;

    if (isAdding) {
      // TODO: Write Code to Insert an Entity Here
    }
    else {
      // TODO: Write Code to Update an Entity Here
    }

    return entity;
  }

  public override string ToString() {
    return FullName();
  }
}
