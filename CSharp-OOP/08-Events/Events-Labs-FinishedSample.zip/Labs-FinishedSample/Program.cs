﻿using OOPLab;

Customer entity = new();
entity.CustomerProcessed += Entity_CustomerProcessed;

void Entity_CustomerProcessed(object sender, CustomerEventArgs e) {
  Console.WriteLine(e.CustomerObject);
}

Customer[] customers =
  entity.GetCustomers(Directory.GetCurrentDirectory()
     + "\\Customers.tsv");
