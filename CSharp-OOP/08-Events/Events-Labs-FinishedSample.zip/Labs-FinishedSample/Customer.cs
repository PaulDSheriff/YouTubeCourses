﻿using System.Collections;

namespace OOPLab;

public class Customer : Person {
  public Customer() {
    Init();
  }

  public Customer(int id, decimal limit) {
    Init();

    CustomerId = id;
    _CreditLimit = limit;
  }

  public override void Init() {
    base.Init();

    CustomerId = 1;
    CompanyName = string.Empty;
    EmailAddress = string.Empty;
    _CreditLimit = 50000;
  }

  public event EventHandler<CustomerEventArgs> CustomerProcessed;

  public int CustomerId { get; set; }

  private string _CompanyName;

  public string CompanyName
  {
    get { return _CompanyName; }
    set { _CompanyName = value; }
  }

  private string _EmailAddress;

  public string EmailAddress
  {
    get { return _EmailAddress; }
    set { _EmailAddress = value; }
  }

  private decimal _CreditLimit;

  public decimal CreditLimit
  {
    get { return _CreditLimit; }
  }

  public Customer[] GetCustomers(string fileName) {
    Customer[] ret = null;

    try {
      string[] lines = FileHelper.ReadAllLines(fileName);
      ret = ProcessCustomerLines(lines);
    }
    catch (FileNotFoundException ex) {
      Console.WriteLine(ex.ToString());
    }
    catch (Exception ex) {
      Console.WriteLine(ex.ToString());
    }

    return ret;
  }


  private Customer[] ProcessCustomerLines(string[] lines) {
    Customer[] ret;
    ArrayList customers = new();

    foreach (string item in lines) {
      string[] entity = item.Split('\t');

      Customer cust = new() {
        CustomerId = Convert.ToInt32(entity[0]),
        FirstName = entity[1],
        LastName = entity[2],
        CompanyName = entity[3]
      };
      customers.Add(cust);

      CustomerProcessed?.Invoke(this, new CustomerEventArgs() { CustomerObject = cust });
    }

    // Convert ArrayList to Array
    ret = (Customer[])customers.ToArray(typeof(Customer));

    return ret;
  }

  protected Customer Save(Customer entity, bool isAdding) {
    LastModified = DateTime.Now;

    if (isAdding) {
      // TODO: Write Code to Insert an Entity Here
    }
    else {
      // TODO: Write Code to Update an Entity Here
    }

    return entity;
  }

  public Customer Insert(Customer entity) {
    return Save(entity, true);
  }

  public Customer Update(Customer entity) {
    return Save(entity, false);
  }

  public override string FullName() {
    return $"{CompanyName}: {LastName}, {FirstName}";
  }

  public void SetCreditLimit(decimal limit) {
    _CreditLimit = limit;
  }

  public override string ContactInfo() {
    return GetInfo();
  }

  public override string GetInfo() {
    return $"Customer ID: {CustomerId}: {base.GetInfo()} - Email Address = {EmailAddress}";
  }

  public override string ToString() {
    return $"Customer ID: {CustomerId} - {FullName()}";
  }
}